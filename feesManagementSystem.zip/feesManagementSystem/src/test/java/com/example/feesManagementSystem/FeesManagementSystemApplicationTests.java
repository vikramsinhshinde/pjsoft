package com.example.feesManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeesManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
