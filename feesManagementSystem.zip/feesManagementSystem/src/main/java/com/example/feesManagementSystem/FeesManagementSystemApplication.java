package com.example.feesManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeesManagementSystemApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(FeesManagementSystemApplication.class, args);
	}

}
