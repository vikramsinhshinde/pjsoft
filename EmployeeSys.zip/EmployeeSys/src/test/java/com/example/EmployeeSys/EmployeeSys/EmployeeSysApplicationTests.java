package com.example.EmployeeSys.EmployeeSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
