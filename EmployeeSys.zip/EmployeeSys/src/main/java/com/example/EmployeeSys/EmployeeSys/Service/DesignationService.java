//package com.example.EmployeeSys.EmployeeSys.Service;
//
//import com.example.EmployeeSys.EmployeeSys.Model.Designation;
//import com.example.EmployeeSys.EmployeeSys.Repository.DesignationRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class DesignationService {
//
//    private final DesignationRepository designationRepository;
//
//    @Autowired
//    public DesignationService(DesignationRepository designationRepository) {
//        this.designationRepository = designationRepository;
//    }
//
//    public Designation saveDesignation(Designation designation) {
//        return designationRepository.save(designation);
//    }
//
//    public List<Designation> getAllDesignations() {
//        return designationRepository.findAll();
//    }
//
//    public Designation getDesignationById(Long id) {
//        return designationRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Designation not found with id: " + id));
//    }
//
//    public Designation updateDesignation(Long id, Designation updatedDesignation) {
//        Optional<Designation> existingDesignation = designationRepository.findById(id);
//        if (existingDesignation.isPresent()) {
//            updatedDesignation.setId(id);
//            return designationRepository.save(updatedDesignation);
//        } else {
//            throw new RuntimeException("Designation not found with id: " + id);
//        }
//    }
//
//    public void deleteDesignation(Long id) {
//        designationRepository.deleteById(id);
//    }
//}
