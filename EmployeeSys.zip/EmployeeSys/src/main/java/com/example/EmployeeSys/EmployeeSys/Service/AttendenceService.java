package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

public interface AttendenceService {

public List<Attendence> getAllAttendence();

    public void deleteAttendencesByEmpId(Integer empID);

    void deleteAllAttendences();

    Attendence updateLogoutTime(int empID);

    List<Attendence> getAttendenceByEmpId(Integer empID);



    void breakIn(Integer empID, LocalTime breakInTime);
    Map<String, Object> breakOut(Integer empID, LocalTime breakOutTime);
    List<Attendence> getTodaysAttendance();
    int getTotalWorkingDaysForEmployee(Integer empID);


    List<Attendence> getAttendenceByEmpIdAndDateRange(Integer empID, LocalDate fromDate, LocalDate toDate);
    List<Attendence> getPresentEmployees(LocalDate date);
    List<Employee> getAbsentEmployees(LocalDate date);
    int getPresentEmployeeCount(LocalDate date);
    int getAbsentEmployeeCount(LocalDate date);


}
