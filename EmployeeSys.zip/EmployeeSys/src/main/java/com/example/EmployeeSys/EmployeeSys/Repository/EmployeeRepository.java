package com.example.EmployeeSys.EmployeeSys.Repository;

import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee,Integer>{
    List<Employee> findByfullNameContaining(String fullName);
    Employee findByMobileNo(String mobileNo);

    Employee findByEmail(String email);
    List<Employee> findByDepartment(String department);
    List<Employee> findByStatus(String status);
    @Modifying
    @Query("DELETE FROM Employee")
    void deleteAllEmployees();

    List<Employee> findAll();

    @Query("SELECT e FROM Employee e WHERE e.shift = :shift")
    List<Employee> findByShift(@Param("shift") String shift);

    @Query("SELECT e FROM Employee e WHERE e.employeeType = :employeeType")
    List<Employee> findByEmployeeType(@Param("employeeType") String employeeType);

    @Query("SELECT e FROM Employee e WHERE e.dutyType = :dutyType")
    List<Employee> findByDutyType(@Param("dutyType") String dutyType);
    @Query("SELECT e FROM Employee e WHERE e.joiningDate BETWEEN :startDate AND :endDate")
    List<Employee> findAllByJoiningDateBetween(@Param("startDate") Date startDate, @Param("endDate") Date endDate);
}
