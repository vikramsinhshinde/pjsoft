            package com.example.EmployeeSys.EmployeeSys.Model;

            import jakarta.persistence.*;
            import lombok.*;


            import java.time.LocalDateTime;
            import java.util.Date;
            import java.util.Set;


            @Entity
            @AllArgsConstructor
            @NoArgsConstructor
            @ToString
            @Getter
            @Setter
            public class Employee {

                @Id
                @GeneratedValue(strategy = GenerationType.IDENTITY)
                private int empID;

                private String password;
                private String confirmPassword;
                private String fullName;
                private String mobileNo;
                private int otp;
                private Long parentNo;
                @Column(unique = true, nullable = false)
                private String email;
                private Date dob;
                private String currentAddress;
                private String permanentAddress;
                private long adharNo;
                private String panNo;
                private Date joiningDate;
                private String department;
                private String dutyType;
                private double salary;
                private String workDetail;
                private String bloodGroup;
                private String gender;
                private String status;
                private String employeePhoto;
                private String idProof;
                private String resume;
                private String addressProof;
                private String standard;
                private int osen;
                private String city;
                private String country;
                private String workLocation;
                private String toMail;
                private String subject;
                private String body;
                private Long esicNo;
                private String cpfNo;
                private String experienceLetter;
                private String landmark;
                private String state;
                private String employeeType;
                private Date enddate;
                private int pinCode;
                private String district;
                private String basicQualification;
                private String professionalQualification;
                private String shift;
                private String shiftStartTime;
                private String shiftEndTime;
                private Date otpExpiry;
                private String employeecategory;
                private LocalDateTime createAt;

                private int totalLeavesCount;
                private int paidleaves;
                private int unpaidleaves;
                private String medicalleave;
                private String emergency;
                private String personal;

            }
