package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Model.EmployeeCategory;
import com.example.EmployeeSys.EmployeeSys.Model.Salary;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeCategoryRepository;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeRepository;
import com.example.EmployeeSys.EmployeeSys.Repository.SalaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class SalaryService {

    @Autowired
    private SalaryRepository salaryRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeCategoryRepository employeeCategoryRepository;


    public Salary saveSalary(Salary salary, int empID) {
        Employee employee = employeeRepository.findById(empID)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        salary.setEmpID(empID);
        return salaryRepository.save(calculateSalary(salary));
    }

    public List<Salary> findSalaryAll() {
        return salaryRepository.findAll();
    }

    public Salary findSalaryById(Long id) {
        return salaryRepository.findById(id).orElseThrow(() -> new RuntimeException("Salary not found"));
    }

    public void deleteSalary(Long id) {
        salaryRepository.deleteById(id);
    }

    private BigDecimal calculateTotalSalary(List<Salary> salaries) {
        return salaries.stream()
                .map(Salary::getFinalNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Salary calculateSalary(Salary salary) {
        Employee employee = employeeRepository.findById(salary.getEmpID())
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        EmployeeCategory category = employeeCategoryRepository.findCategoryByCategoryName(employee.getEmployeecategory());

        BigDecimal basic = salary.getBasicSalary();

        // Calculate the number of days in the month
        LocalDate salaryDate = salary.getPaymentDate();
        int daysInMonth = salaryDate.lengthOfMonth();

        // Calculate per day salary
        BigDecimal perDaySalary = basic.divide(BigDecimal.valueOf(daysInMonth), BigDecimal.ROUND_HALF_UP);

        // Calculate actual salary based on working days
        BigDecimal actualBasicSalary = perDaySalary.multiply(BigDecimal.valueOf(salary.getWorkingDays()));

        // Calculate allowances based on actual basic salary
        salary.setHraAllowance(actualBasicSalary.multiply(category.getHraPercentage()));
        salary.setTaAllowance(actualBasicSalary.multiply(category.getTaPercentage()));
        salary.setIncentive(actualBasicSalary.multiply(category.getIncentivePercentage()));
        salary.setSpi(actualBasicSalary.multiply(category.getSpiPercentage()));
        salary.setMedicalAllowance(actualBasicSalary.multiply(category.getMedicalAllowancePercentage()));
        //salary.setBonuses(actualBasicSalary.multiply(category.getBonusPercentage()));

        BigDecimal totalAdditions = actualBasicSalary
                .add(salary.getHraAllowance())
                .add(salary.getTaAllowance())
                .add(salary.getIncentive())
                .add(salary.getSpi())
                .add(salary.getMedicalAllowance());
              //  .add(salary.getBonuses());

        // Calculate deductions based on actual basic salary
        salary.setPf(actualBasicSalary.multiply(category.getPfPercentage()));
        salary.setEsf(actualBasicSalary.multiply(category.getEsfPercentage()));
        BigDecimal totalDeductions = salary.getPf().add(salary.getEsf());

        BigDecimal netSalaryBeforeTaxes = totalAdditions.subtract(totalDeductions);
        salary.setNetSalaryBeforeTaxes(netSalaryBeforeTaxes);

        BigDecimal incomeTax = netSalaryBeforeTaxes.multiply(category.getIncomeTaxPercentage());
        BigDecimal professionalTax = netSalaryBeforeTaxes.multiply(category.getProfessionalTaxPercentage());

        salary.setIncomeTax(incomeTax);
        salary.setProfessionalTax(professionalTax);

        BigDecimal finalNetSalary = netSalaryBeforeTaxes.subtract(incomeTax).subtract(professionalTax);
        salary.setFinalNetSalary(finalNetSalary);
        salary.setDeductions(totalDeductions.add(incomeTax).add(professionalTax));

        return salary;
    }

    public BigDecimal calculateFinalSalary(List<Salary> salaries) {
        return salaries.stream()
                .map(Salary::getFinalNetSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    public List<Salary> getSalariesByEmployeeIdAndMonthAndYear(int empID, int month, int year) {
        return salaryRepository.findByEmployeeIdAndPaymentDateMonthAndYear(empID, month, year);
    }

    public List<Salary> getSalariesByEmployeeId(int empID) {
        return salaryRepository.findByEmpID(empID);
    }

    public List<Salary> getSalariesByCategoryName(String employeecategory) {
        return salaryRepository.findByCategoryName(employeecategory);
    }

    public List<Salary> getSalariesByMonthAndYear(int month, int year) {
        return salaryRepository.findByPaymentDateMonthAndYear(month, year);
    }

}
