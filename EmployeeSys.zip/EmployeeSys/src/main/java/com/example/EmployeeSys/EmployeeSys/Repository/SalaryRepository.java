package com.example.EmployeeSys.EmployeeSys.Repository;

import com.example.EmployeeSys.EmployeeSys.Model.Salary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SalaryRepository extends JpaRepository<Salary, Long>
{


    @Query("SELECT s FROM Salary s WHERE s.empID = :empID AND FUNCTION('MONTH', s.paymentDate) = :month AND FUNCTION('YEAR', s.paymentDate) = :year")
    List<Salary> findByEmployeeIdAndPaymentDateMonthAndYear(
            @Param("empID") Integer empID,
            @Param("month") int month,
            @Param("year") int year
    );

    @Query("SELECT s FROM Salary s WHERE s.empID = :empID")
    List<Salary> findByEmpID(@Param("empID") Integer empID);

    @Query("SELECT s FROM Salary s WHERE s.empID IN (SELECT e.empID FROM Employee e WHERE e.employeecategory = :employeecategory)")
    List<Salary> findByCategoryName(@Param("employeecategory") String employeecategory);

    @Query("SELECT s FROM Salary s WHERE FUNCTION('MONTH', s.paymentDate) = :month AND FUNCTION('YEAR', s.paymentDate) = :year")
    List<Salary> findByPaymentDateMonthAndYear(@Param("month") int month, @Param("year") int year);


}
