package com.example.EmployeeSys.EmployeeSys.Repository;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendenceRepo extends CrudRepository<Attendence, Long> {


@Query("SELECT a FROM Attendence a WHERE a.empID = :empID AND a.todaysDate = :todaysDate")
Attendence findByEmpIDAndTodaysDate(@Param("empID") Integer empID, @Param("todaysDate") LocalDate todaysDate);
    List<Attendence> findByEmpID(Integer empID);
    List<Attendence> findAllByTodaysDate(LocalDate todaysDate);
    List<Attendence> findByEmpIDAndTodaysDateBetween(Integer empID, LocalDate fromDate, LocalDate toDate);
    List<Attendence> findByTodaysDate(LocalDate todaysDate);

}
