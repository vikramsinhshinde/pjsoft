package com.example.EmployeeSys.EmployeeSys.Controller;


import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Service.EmployeeReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000/")

@Controller
public class ReportController {

    @Autowired
    EmployeeReportService employeeReportService;

    @GetMapping("/employees/last7days")
    public ResponseEntity<List<Employee>> getEmployeesLast7Days() {
        List<Employee> employees = employeeReportService.getEmployeesLast7Days();
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/employees/lastMonth")
    public ResponseEntity<List<Employee>> getEmployeesLastMonth() {
        List<Employee> employees = employeeReportService.getEmployeesLastMonth();
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/employees/lastYear")
    public ResponseEntity<List<Employee>> getEmployeesLastYear() {
        List<Employee> employees = employeeReportService.getEmployeesLastYear();
        return ResponseEntity.ok(employees);
    }
}

