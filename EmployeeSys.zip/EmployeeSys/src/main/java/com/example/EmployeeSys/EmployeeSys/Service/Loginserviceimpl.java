package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class Loginserviceimpl {

    @Autowired
    EmployeeRepository employeeRepository;


    public String employeeLogin(String email, String password){
        Optional<Employee> employee = Optional.ofNullable(employeeRepository.findByEmail(email));
        LocalDateTime expiryDate = employee.get().getCreateAt().plusDays(365);
        if (employee.isPresent()) {
            Employee employee1 = employee.get();
            if (employee1.getPassword().equals(password)) {
                if(LocalDateTime.now().isBefore(expiryDate)){
                    employee1.setStatus("Activate");
                    return "yes";
                }else{
                    employee1.setStatus("Deactivate");
                    return "no";
                }
            } else {
                return "no";
            }
        } else {
            return "Admin not found";
        }
    }

}
