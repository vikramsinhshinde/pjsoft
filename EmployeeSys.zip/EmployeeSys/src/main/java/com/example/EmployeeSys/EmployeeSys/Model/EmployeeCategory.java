package com.example.EmployeeSys.EmployeeSys.Model;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmployeeCategory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String categoryName;

    //private BigDecimal bonusPercentage;
    private BigDecimal hraPercentage;
    private BigDecimal taPercentage;
    private BigDecimal incentivePercentage;
    private BigDecimal spiPercentage;
    private BigDecimal medicalAllowancePercentage;
    private BigDecimal pfPercentage;
    private BigDecimal esfPercentage;
    private BigDecimal professionalTaxPercentage;
    private BigDecimal incomeTaxPercentage;
    private int totalPaidLeave;
    private int totalUnpaidLeave;

}