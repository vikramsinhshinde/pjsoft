package com.example.EmployeeSys.EmployeeSys.Repository;

import com.example.EmployeeSys.EmployeeSys.Model.EmployeeCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeCategoryRepository extends JpaRepository<EmployeeCategory, Long>
{@Query("SELECT e FROM EmployeeCategory e WHERE e.categoryName = :categoryName")
EmployeeCategory findCategoryByCategoryName(@Param("categoryName") String categoryName);
}