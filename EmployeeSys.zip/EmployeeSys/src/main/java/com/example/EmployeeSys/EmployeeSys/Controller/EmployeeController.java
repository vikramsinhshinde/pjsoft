package com.example.EmployeeSys.EmployeeSys.Controller;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Repository.AttendenceRepo;
import com.example.EmployeeSys.EmployeeSys.Service.EmployeeService;
import com.example.EmployeeSys.EmployeeSys.exceptions.EmployeeNotFoundException;
import jakarta.mail.MessagingException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;
import java.util.Random;


import org.springframework.validation.BindingResult;


@CrossOrigin(origins = "http://localhost:3000/")
@Controller
public class EmployeeController {



    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    AttendenceRepo attendenceRepo;


    //signup api
    @PostMapping("/signup")
    public ResponseEntity<String> signUp(@Valid @RequestBody Employee employee, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            // If there are validation errors, return a bad request response
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Validation error");
        }

        try {
            // Save the employee using the service
            employeeService.saveEmployee(employee);

            // Return a success message
            return ResponseEntity.ok("Employee signed up successfully");
        } catch (Exception e) {
            // If there's an error saving to the database, return an internal server error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error signing up employee");
        }
    }

    //signin
    @PostMapping("/signin")
    public ResponseEntity<String> signIn(@RequestParam String email, @RequestParam String password, HttpServletRequest httpServletRequest) {
        // Validate the email and password
        if (email == null || email.isEmpty() || password == null || password.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid email or password");
        }

        // Check if the email and password match an existing employee
        Employee employee = employeeService.findByEmail(email);
        if (employee == null || !employee.getPassword().equals(password)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect email or password");
        }


        Attendence attendence = new Attendence();
        attendence.setEmpID(employee.getEmpID());
        attendence.setName(employee.getFullName());
        attendence.setLoginTime(LocalTime.now());
        attendence.setLogoutTime(null);
        attendence.setTodaysDate(LocalDate.now());
        attendence.setIP(httpServletRequest.getRemoteAddr());
        attendence.setShift(employee.getShift());
        attendenceRepo.save(attendence);


        // Return a success message
        return ResponseEntity.ok("Employee signed in successfully");
    }


//    get all employess
    @GetMapping("/getAllemp")
    @ResponseBody
    public List<Employee> getAllEmployees() {
    return employeeService.getAllEmployees();
}


//    get employee by id
@GetMapping("/empById/{empById}")
@ResponseBody
public ResponseEntity<Object> getEmployeeById(@PathVariable int empById) {
    try {
        Employee employee = employeeService.getEmployeeById(empById);
        return ResponseEntity.ok(employee);
    } catch (EmployeeNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
    }
}

    //    Add employee
//    @PostMapping("/addEmp")
//    @ResponseBody
//    public Employee addEmployee(@RequestBody Employee employee) {
//        return employeeService.addEmployee(employee);
//    }

    @PostMapping("/addEmp")
    @ResponseBody
    public Employee addEmployee(@RequestBody Employee employee) {
        return employeeService.addEmployee(employee);
    }


//    Update particular employee by Id
    @PutMapping("/updateEmpByPut/{empPutId}")
    @ResponseBody
    public Employee updateEmployee(@PathVariable int empPutId, @RequestBody Employee employee) {
        return employeeService.updateEmployee(empPutId, employee);
    }


//    Update employee by patch
    @PatchMapping("/updateEmpByPatch/{empPatchId}")
    @ResponseBody
    public ResponseEntity<Employee> patchEmployee(@PathVariable int empPatchId, @RequestBody Map<String, Object> updates) {
        try {
            Employee updatedEmployee = employeeService.patchEmployee(empPatchId, updates);
            return ResponseEntity.ok(updatedEmployee);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }



//    Delete Employee BY ID
    @DeleteMapping("/empDeleteById/{empDeleteById}")
    @ResponseBody
    public void deleteEmployee(@PathVariable int empDeleteById) {
        employeeService.deleteEmployee(empDeleteById);
    }





//    Delete all Employees
    @DeleteMapping("/deleteAllEmp")
    @ResponseBody
    public void deleteAllEmployees() {
        employeeService.deleteAllEmployees();
    }




//    Search employee by Id
    @GetMapping("/empSearchById/{empSearchById}")
    @ResponseBody
    public Employee searchEmployeeById(@PathVariable int empSearchById) {
        return employeeService.searchEmployeeById(empSearchById);
    }




//    Search employee by Full Name
    @GetMapping("/searchByFullName/{searchByFullName}")
    @ResponseBody
    public List<Employee> searchEmployeeByfullName(@PathVariable String searchByFullName) {
        return employeeService.searchEmployeeByfullName(searchByFullName);
    }



//    Send otp to particular employee
    @PostMapping("/sendSmsOtp")
    @ResponseBody
    public void sendSmsOtp(@RequestParam(required=false) String mobileNo)
    {
        employeeService.sendSmsOtp(mobileNo);
    }


//    Verify the sent otp
    @PostMapping("/sendSmsOtp/verifyOtp")
    @ResponseBody
    public String verifyOtp(@RequestParam String mobileNo, @RequestParam int otp) {
        return employeeService.verifyOtp(mobileNo, otp);
    }




    @PostMapping("/{email}/uploadImage")
    @ResponseBody
    public ResponseEntity<?> uploadImage(@PathVariable("email") String email, @RequestParam("") MultipartFile file) {
        try {
            String employeePhoto = employeeService.uploadImageToCloudinary(file);
            Employee employee = employeeService.getEmployeeByEmail(email);
            if (employee == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found with email: " + email);
            }
            employee.setEmployeePhoto(employeePhoto);
            employeeService.updateEmployee(employee.getEmpID(), employee);
            return ResponseEntity.ok("Image uploaded to PJSoftTech successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload image to Cloudinary: " + e.getMessage());
        }
    }

    @PostMapping("/{email}/uploadIdProof")
    @ResponseBody
    public ResponseEntity<?> uploadIdProof(@PathVariable("email") String email, @RequestParam("idProofFile") MultipartFile file) {
        try {
            String idProof = employeeService.uploadIdProofToCloudinary(file);
            Employee employee = employeeService.getEmployeeByEmail(email);
            if (employee == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found with email: " + email);
            }
            employee.setIdProof(idProof);
            employeeService.updateEmployee(employee.getEmpID(), employee);
            return ResponseEntity.ok("ID proof uploaded to PJSoftTech successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload ID proof to Cloudinary: " + e.getMessage());
        }
    }

    @PostMapping("/{email}/uploadAddressProof")
    @ResponseBody
    public ResponseEntity<?> uploadAddressProof(@PathVariable("email") String email, @RequestParam("addressProofFile") MultipartFile file) {
        try {
            validatePdfFile(file);
            String addressProof = employeeService.uploadAddressProofToCloudinary(file);
            Employee employee = employeeService.getEmployeeByEmail(email);
            if (employee == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found with email: " + email);
            }
            employee.setAddressProof(addressProof);
            employeeService.updateEmployee(employee.getEmpID(), employee);
            return ResponseEntity.ok("Address proof uploaded to PJSoftTech successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload address proof to Cloudinary: " + e.getMessage());
        }
    }

    @PostMapping("/{email}/uploadResume")
    @ResponseBody
    public ResponseEntity<?> uploadResume(@PathVariable("email") String email, @RequestParam("resumeFile") MultipartFile file) {
        try {
            validatePdfFile(file);
            String resume = employeeService.uploadResumeToCloudinary(file);
            Employee employee = employeeService.getEmployeeByEmail(email);
            if (employee == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found with email: " + email);
            }
            employee.setResume(resume);
            employeeService.updateEmployee(employee.getEmpID(), employee);
            return ResponseEntity.ok("Resume uploaded to PJSoftTech successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload resume to Cloudinary: " + e.getMessage());
        }
    }

    @PostMapping("/{email}/uploadExperienceLetter")
    @ResponseBody
    public ResponseEntity<?> uploadExperienceLetter(@PathVariable("email") String email, @RequestParam("experienceLetterFile") MultipartFile file) {
        try {
            validatePdfFile(file);
            String experienceLetterUrl = employeeService.uploadExperienceLetterToCloudinary(file);
            Employee employee = employeeService.getEmployeeByEmail(email);
            if (employee == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found with email: " + email);
            }
            employee.setExperienceLetter(experienceLetterUrl);
            employeeService.updateEmployee(employee.getEmpID(), employee);
            return ResponseEntity.ok("Experience letter uploaded to PJSoftTech successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload experience letter to Cloudinary: " + e.getMessage());
        }
    }

    private void validatePdfFile(MultipartFile file) {
        if (!file.getContentType().equals("application/pdf")) {
            throw new RuntimeException("Invalid file type. Only PDF files are allowed.");
        }
    }


//    download csv file of the database
    @GetMapping("/download/csv")
    @ResponseBody
    public ResponseEntity<byte[]> downloadCsv() {
        String csvData = employeeService.getAllEmployeesAsCsv();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        headers.setContentDispositionFormData("filename", "employees.csv");

        return new ResponseEntity<>(csvData.getBytes(), headers, HttpStatus.OK);
    }


//    Upload external csv file
    @PostMapping("/upload/csv")
    @ResponseBody
    public ResponseEntity<String> uploadCsv(@RequestParam("file") MultipartFile file) {
        try {
            employeeService.saveCsvData(file);
            return ResponseEntity.ok("File uploaded successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to upload file: " + e.getMessage());
        }
    }


    @GetMapping("/employees/department/{department}")
    @ResponseBody
    public List<Employee> getEmployeesByDepartment(@PathVariable String department) {
        return employeeService.getEmployeesByDepartment(department);
    }

    @GetMapping("/employees/status/{status}")
    @ResponseBody
    public List<Employee> getEmployeesByStatus(@PathVariable String status) {
        return employeeService.getEmployeesByStatus(status);
    }


    @PostMapping("/sendEmailOtp")
    @ResponseBody
    public ResponseEntity<String> sendEmailOtp(@RequestParam String email) {
        try {
            employeeService.sendEmailOtp(email);
            return ResponseEntity.ok("OTP sent successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(e.getMessage());
        }
    }

    @PostMapping("/verifyEmailOtp")
    @ResponseBody
    public ResponseEntity<String> verifyEmailOtp(@RequestParam String email, @RequestParam int otp, @RequestParam String newPassword) {
        boolean isVerified = employeeService.verifyEmailOtp(email, otp, newPassword);
        if (isVerified) {
            return ResponseEntity.ok("Password updated successfully");
        } else {
            return ResponseEntity.status(400).body("Invalid OTP or OTP expired");
        }
    }


    @PostMapping("/otpVerification")
    @ResponseBody
    public ResponseEntity<String> otpVerification(@RequestParam String email, @RequestParam int otp) {
        if (employeeService.otpVerification(email, otp)) {
            return ResponseEntity.ok("OTP verified successfully");
        } else {
            return ResponseEntity.status(400).body("Invalid OTP");
        }
    }

    @GetMapping("/empSearchByEmail/{email}")
    @ResponseBody
    public Employee searchEmployeeByEmail(@PathVariable String email) {
        return employeeService.searchEmployeeByEmail(email);
    }

    @GetMapping("/search/shift")
    public ResponseEntity<List<Employee>> searchEmployeesByShift(@RequestParam String shift) {
        List<Employee> employees = employeeService.getEmployeesByShift(shift);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/search/employeeType")
    public ResponseEntity<List<Employee>> searchEmployeesByEmployeeType(@RequestParam String employeeType) {
        List<Employee> employees = employeeService.getEmployeesByEmployeeType(employeeType);
        return ResponseEntity.ok(employees);
    }

    @GetMapping("/search/dutyType")
    public ResponseEntity<List<Employee>> searchEmployeesByDutyType(@RequestParam String dutyType) {
        List<Employee> employees = employeeService.getEmployeesByDutyType(dutyType);
        return ResponseEntity.ok(employees);
    }


}



