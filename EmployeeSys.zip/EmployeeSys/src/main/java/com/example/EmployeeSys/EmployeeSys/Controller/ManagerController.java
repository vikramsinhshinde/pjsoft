package com.example.EmployeeSys.EmployeeSys.Controller;


import com.example.EmployeeSys.EmployeeSys.Model.Manager;
import com.example.EmployeeSys.EmployeeSys.Service.ManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000/")

@Controller
public class ManagerController {

    @Autowired
    private ManagerService managerService;

    @PostMapping("/saveManager")
    @ResponseBody
    public ResponseEntity<Manager> createManager(@RequestBody Manager manager) {
        Manager savedManager = managerService.saveManager(manager);
        return new ResponseEntity<>(savedManager, HttpStatus.CREATED);
    }

    @GetMapping("/getAllManager")
    @ResponseBody
    public ResponseEntity<List<Manager>> getAllManagers() {
        List<Manager> managers = managerService.getAllManagers();
        return new ResponseEntity<>(managers, HttpStatus.OK);
    }

    @GetMapping("/getManagerById/{id}")
    @ResponseBody
    public ResponseEntity<Manager> getManagerById(@PathVariable Long id) {
        Optional<Manager> manager = managerService.getManagerById(id);
        return manager.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/updateManager/{id}")
    @ResponseBody
    public Manager updateManager(@PathVariable Long id, @RequestBody Manager managerDetails) {
        return managerService.updateManager(id, managerDetails);
    }

    @DeleteMapping("/deleteManager/{id}")
    @ResponseBody
    public ResponseEntity<Void> deleteManager(@PathVariable Long id) {
        managerService.deleteManager(id);
        return ResponseEntity.noContent().build();
    }
}