package com.example.EmployeeSys.EmployeeSys.Controller;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Service.AttendenceService;
import com.example.EmployeeSys.EmployeeSys.Service.EmployeeService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "http://localhost:3000/")

@RestController
public class AttendenceController {

    @Autowired
    EmployeeService employeeService;
    @Autowired
    AttendenceService attendenceService;


        @PostMapping("/logout/{empId}")
    public ResponseEntity<Attendence> logout(@PathVariable int empId) {
        Attendence updatedAttendence = attendenceService.updateLogoutTime(empId);
        if (updatedAttendence != null) {
            return ResponseEntity.ok(updatedAttendence);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }



    @GetMapping("/getAllAttendence")

    public List<Attendence> getAllAttendence(){
        return attendenceService.getAllAttendence();
    }




    @GetMapping("/getAttendenceByEmpId/{empID}")
    public ResponseEntity<List<Attendence>> getAttendenceByEmpId(@PathVariable Integer empID) {
        List<Attendence> attendences = attendenceService.getAttendenceByEmpId(empID);
        if (!attendences.isEmpty()) {
            return ResponseEntity.ok(attendences);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/deleteByEmpId/{empID}")
    public ResponseEntity<Void> deleteAttendencesByEmpId(@PathVariable Integer empID) {
        List<Attendence> attendences = attendenceService.getAttendenceByEmpId(empID);
        if (!attendences.isEmpty()) {
            attendenceService.deleteAttendencesByEmpId(empID);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/deleteAll")
    public ResponseEntity<Void> deleteAllAttendences() {
        attendenceService.deleteAllAttendences();
        return ResponseEntity.noContent().build();
    }


    @PostMapping("/breakIn/{empID}")
    public ResponseEntity<String> breakIn(@PathVariable Integer empID) {
        attendenceService.breakIn(empID, LocalTime.now());
        return ResponseEntity.ok("Break-in time recorded.");
    }

    @PostMapping("/breakOut/{empID}")
    public ResponseEntity<Map<String, Object>> breakOut(@PathVariable Integer empID) {
        Map<String, Object> response = attendenceService.breakOut(empID, LocalTime.now());
        return ResponseEntity.ok(response);
    }

    @GetMapping("/today")
    public ResponseEntity<List<Attendence>> getTodaysAttendance() {
        List<Attendence> todaysAttendance = attendenceService.getTodaysAttendance();
        return ResponseEntity.ok(todaysAttendance);
    }
    @GetMapping("/totalWorkingDays/{empID}")
    public ResponseEntity<Integer> getTotalWorkingDaysForEmployee(@PathVariable Integer empID) {
        int totalWorkingDays = attendenceService.getTotalWorkingDaysForEmployee(empID);
        return ResponseEntity.ok(totalWorkingDays);
    }




    @GetMapping("/getAttendenceByEmpIdAndDateRange/{empID}")
    public ResponseEntity<List<Attendence>> getAttendenceByEmpIdAndDateRange(
            @PathVariable Integer empID,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fromDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate toDate) {
        List<Attendence> attendences = attendenceService.getAttendenceByEmpIdAndDateRange(empID, fromDate, toDate);
        if (!attendences.isEmpty()) {
            return ResponseEntity.ok(attendences);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/present")
    public List<Attendence> getPresentEmployees() {
        LocalDate today = LocalDate.now();
        return attendenceService.getPresentEmployees(today);
    }

    @GetMapping("/absent")
    public List<Employee> getAbsentEmployees() {
        LocalDate today = LocalDate.now();
        return attendenceService.getAbsentEmployees(today);
    }

    @GetMapping("/present/count")
    public int getPresentEmployeeCount() {
        LocalDate today = LocalDate.now();
        return attendenceService.getPresentEmployeeCount(today);
    }

    @GetMapping("/absent/count")
    public int getAbsentEmployeeCount() {
        LocalDate today = LocalDate.now();
        return attendenceService.getAbsentEmployeeCount(today);
    }

}

