package com.example.EmployeeSys.EmployeeSys.Service;


import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class EmployeeReportService {

    @Autowired
    EmployeeRepository employeeRepository;

    public List<Employee> getEmployeesByDateRange(Date startDate, Date endDate) {
        return employeeRepository.findAllByJoiningDateBetween(startDate, endDate);
    }

    // Method to get employees for the last 7 days
    public List<Employee> getEmployeesLast7Days() {
        Calendar calendar = Calendar.getInstance();
        Date endDate = calendar.getTime();
        calendar.add(Calendar.DAY_OF_YEAR, -7);
        Date startDate = calendar.getTime();
        return getEmployeesByDateRange(startDate, endDate);
    }

    // Method to get employees for the last month
    public List<Employee> getEmployeesLastMonth() {
        Calendar calendar = Calendar.getInstance();
        Date endDate = calendar.getTime();
        calendar.add(Calendar.MONTH, -1);
        Date startDate = calendar.getTime();
        return getEmployeesByDateRange(startDate, endDate);
    }

    // Method to get employees for the last year
    public List<Employee> getEmployeesLastYear() {
        Calendar calendar = Calendar.getInstance();
        Date endDate = calendar.getTime();
        calendar.add(Calendar.YEAR, -1);
        Date startDate = calendar.getTime();
        return getEmployeesByDateRange(startDate, endDate);
    }
}
