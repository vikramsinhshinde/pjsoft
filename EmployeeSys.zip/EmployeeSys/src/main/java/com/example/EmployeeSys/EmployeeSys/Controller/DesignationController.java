//package com.example.EmployeeSys.EmployeeSys.Controller;
//
//
//import com.example.EmployeeSys.EmployeeSys.Model.Designation;
//import com.example.EmployeeSys.EmployeeSys.Service.DesignationService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@CrossOrigin(origins = "http://localhost:3000/")
//
//@Controller
//public class DesignationController {
//
//    private final DesignationService designationService;
//
//    @Autowired
//    public DesignationController(DesignationService designationService) {
//        this.designationService = designationService;
//    }
//
//    @PostMapping("/saveDesignation")
//    public ResponseEntity<Designation> saveDesignation(@RequestBody Designation designation) {
//        Designation savedDesignation = designationService.saveDesignation(designation);
//        return new ResponseEntity<>(savedDesignation, HttpStatus.CREATED);
//    }
//
//    @GetMapping("/getAllDesignations")
//    public ResponseEntity<List<Designation>> getAllDesignations() {
//        List<Designation> designations = designationService.getAllDesignations();
//        return new ResponseEntity<>(designations, HttpStatus.OK);
//    }
//
//    @GetMapping("/getDesignationById/{id}")
//    public ResponseEntity<Designation> getDesignationById(@PathVariable Long id) {
//        Designation designation = designationService.getDesignationById(id);
//        return new ResponseEntity<>(designation, HttpStatus.OK);
//    }
//
//    @PutMapping("/updateDesignation/{id}")
//    public ResponseEntity<Designation> updateDesignation(@PathVariable Long id, @RequestBody Designation designation) {
//        Designation updatedDesignation = designationService.updateDesignation(id, designation);
//        return new ResponseEntity<>(updatedDesignation, HttpStatus.OK);
//    }
//
//    @DeleteMapping("/deleteDesignation/{id}")
//    public ResponseEntity<Void> deleteDesignation(@PathVariable Long id) {
//        designationService.deleteDesignation(id);
//        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//    }
//}