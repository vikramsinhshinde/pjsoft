package com.example.EmployeeSys.EmployeeSys.Model;


import jakarta.persistence.*;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Salary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int empID;
    private BigDecimal basicSalary;
    private BigDecimal hraAllowance;
    private BigDecimal taAllowance;
    private BigDecimal incentive;
    private BigDecimal spi;
    private BigDecimal medicalAllowance;
  //  private BigDecimal bonuses;
    private BigDecimal pf;
    private BigDecimal esf;
    private BigDecimal professionalTax;
    private BigDecimal incomeTax;
    private BigDecimal deductions;
    private BigDecimal netSalaryBeforeTaxes;
    private BigDecimal finalNetSalary;
    private LocalDate paymentDate;

    private int workingDays;

//    @DateTimeFormat(pattern = "yyyy-mm-dd")
//    private LocalDate salaryDate;

}

