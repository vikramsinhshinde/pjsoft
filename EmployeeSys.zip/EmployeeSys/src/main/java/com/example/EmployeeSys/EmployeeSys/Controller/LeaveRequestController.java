package com.example.EmployeeSys.EmployeeSys.Controller;


import com.example.EmployeeSys.EmployeeSys.Model.LeaveRequest;
import com.example.EmployeeSys.EmployeeSys.Service.LeaveRequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000/")

@Controller
public class LeaveRequestController {

    @Autowired
    private LeaveRequestService leaveRequestService;

    @PostMapping("/saveRequest")
    @ResponseBody
    public ResponseEntity<LeaveRequest> createLeaveRequest(@RequestBody LeaveRequest leaveRequest) {
        LeaveRequest savedLeaveRequest = leaveRequestService.saveLeaveRequest(leaveRequest);
        return new ResponseEntity<>(savedLeaveRequest, HttpStatus.CREATED);
    }

    @GetMapping("/allRequest")
    @ResponseBody
    public ResponseEntity<List<LeaveRequest>> getAllLeaveRequests() {
        List<LeaveRequest> leaveRequests = leaveRequestService.getAllLeaveRequests();
        return new ResponseEntity<>(leaveRequests, HttpStatus.OK);
    }

    @GetMapping("/getLeaveRequestById/{id}")
    @ResponseBody
    public ResponseEntity<LeaveRequest> getLeaveRequestById(@PathVariable Long id) {
        Optional<LeaveRequest> leaveRequest = leaveRequestService.getLeaveRequestById(id);
        return leaveRequest.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/getLeaveRequestsByReasonDescriptionAndEmployeeId")
    @ResponseBody
    public List<LeaveRequest> getLeaveRequestsByReasonDescriptionAndEmployeeId(
            @RequestParam String reasondescription,
            @RequestParam Integer empID) {
        return leaveRequestService.getLeaveRequestsByReasonDescriptionAndEmployeeId(reasondescription, empID);
    }

    @DeleteMapping("/deleteLeaveRequest/delete/{id}")
    @ResponseBody
    public ResponseEntity<Void> deleteLeaveRequest(@PathVariable Long id) {
        leaveRequestService.deleteLeaveRequest(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/updateLeaveRequest/{id}")
    @ResponseBody
    public LeaveRequest updateleaverequest(@PathVariable  int id,@RequestBody LeaveRequest leaveRequest){
        return leaveRequestService.updateLeaveRequestStatus((long) id, leaveRequest);
    }

    @PutMapping("/rejectLeaveRequest/{id}")
    @ResponseBody
    public LeaveRequest rejectleaverequest(@PathVariable  int id,@RequestBody LeaveRequest leaveRequest){
        return leaveRequestService.rejectStatus((long) id, leaveRequest);
    }

    @GetMapping("/leaveRequests/last7days")
    @ResponseBody
    public ResponseEntity<List<LeaveRequest>> getLeaveRequestsForLast7Days() {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestsForLast7Days();
        return new ResponseEntity<>(leaveRequests, HttpStatus.OK);
    }

    @GetMapping("/leaveRequests/lastmonth")
    @ResponseBody
    public ResponseEntity<List<LeaveRequest>> getLeaveRequestsForLastMonth() {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestsForLastMonth();
        return new ResponseEntity<>(leaveRequests, HttpStatus.OK);
    }

    @GetMapping("/leaveRequests/lastyear")
    @ResponseBody
    public ResponseEntity<List<LeaveRequest>> getLeaveRequestsForLastYear() {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestsForLastYear();
        return new ResponseEntity<>(leaveRequests, HttpStatus.OK);
    }

    @GetMapping("/leaveRequestsByStatusAndempId")
    public ResponseEntity<List<LeaveRequest>> getLeaveRequestsByStatusAndEmpID(
            @RequestParam String status,
            @RequestParam Integer empID) {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestsByStatusAndEmpID(status, empID);
        return ResponseEntity.ok(leaveRequests);
    }

    @GetMapping("/leaveRequestsByStatus")
    public ResponseEntity<List<LeaveRequest>> getLeaveRequestsByStatus(
            @RequestParam String status
           ) {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestByStatus(status);
        return ResponseEntity.ok(leaveRequests);
    }

    @GetMapping("/NumberOfleaveRequestsByStatus")
    @ResponseBody
    public int NumberOfleaveRequestsByStatus(@RequestParam String status) {
        List<LeaveRequest> leaveRequests = leaveRequestService.getLeaveRequestByStatus(status);
        int NumberOfRequest=0;
        for(LeaveRequest leaveRequest:leaveRequests){
            NumberOfRequest +=1;
        }
        return NumberOfRequest;
    }

}

