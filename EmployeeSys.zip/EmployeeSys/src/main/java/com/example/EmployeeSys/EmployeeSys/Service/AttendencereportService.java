package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;

import java.util.List;

public interface AttendencereportService {

    List<Attendence> getLast7DaysAttendenceByEmpId(Integer empID);

    List<Attendence> getLast30DaysAttendenceByEmpId(Integer empID);
    List<Attendence> getLast365DaysAttendenceByEmpId(Integer empID);

    long getLast7DaysAttendenceCountByEmpId(Integer empID);

    long getLast30DaysAttendenceCountByEmpId(Integer empID);

    long getLast365DaysAttendenceCountByEmpId(Integer empID);
}
