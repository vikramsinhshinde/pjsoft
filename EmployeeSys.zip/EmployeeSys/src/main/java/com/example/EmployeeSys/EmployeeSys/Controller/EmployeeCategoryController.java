package com.example.EmployeeSys.EmployeeSys.Controller;

import com.example.EmployeeSys.EmployeeSys.Model.EmployeeCategory;
import com.example.EmployeeSys.EmployeeSys.Service.EmployeeCategoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:3000/")

@RestController
@RequestMapping("/categories")
public class EmployeeCategoryController {

    private static final Logger logger = LoggerFactory.getLogger(EmployeeCategoryController.class);

    @Autowired
    private EmployeeCategoryService employeeCategoryService;

    @PostMapping("/addEmployeeCategory")
    public ResponseEntity<EmployeeCategory> createEmployeeCategory(@RequestBody EmployeeCategory employeeCategory) {
        EmployeeCategory savedEmployeeCategory = employeeCategoryService.save(employeeCategory);
        return ResponseEntity.ok(savedEmployeeCategory);
    }

    @GetMapping("/all")
    public ResponseEntity<List<EmployeeCategory>> getAllEmployeeCategories() {
        List<EmployeeCategory> employeeCategories = employeeCategoryService.findAll();
        return ResponseEntity.ok(employeeCategories);
    }

    @GetMapping("/getCategoryById/{id}")
    public ResponseEntity<EmployeeCategory> getEmployeeCategoryById(@PathVariable Long id) {
        Optional<EmployeeCategory> employeeCategory = employeeCategoryService.findById(id);
        return employeeCategory.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/updateCategoryById/{id}")
    public ResponseEntity<EmployeeCategory> updateEmployeeCategory(@PathVariable Long id, @RequestBody EmployeeCategory updatedEmployeeCategory) {
        try {
            EmployeeCategory updatedCategory = employeeCategoryService.updateEmployeeCategory(id, updatedEmployeeCategory);
            return ResponseEntity.ok(updatedCategory);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/delete/employeecategory/{id}")
    public ResponseEntity<Void> deleteEmployeeCategory(@PathVariable("id") Long id) {
        logger.info("Received request to delete EmployeeCategory with id: {}", id);
        employeeCategoryService.deleteEmployeeCategory(id);
        return ResponseEntity.noContent().build();
    }

}


