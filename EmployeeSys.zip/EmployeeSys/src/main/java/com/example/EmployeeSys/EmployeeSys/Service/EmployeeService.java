package com.example.EmployeeSys.EmployeeSys.Service;

import com.cloudinary.Cloudinary;
import com.cloudinary.utils.ObjectUtils;
//import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeRepository;

import com.example.EmployeeSys.EmployeeSys.exceptions.EmployeeNotFoundException;
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
//import jakarta.mail.MessagingException;
//import jakarta.mail.internet.MimeMessage;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
//import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.*;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;


@Service
@Transactional
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private EmailService emailService;
    private Cloudinary cloudinary;

    @PersistenceContext
    private EntityManager entityManager;




    @Value("${twilio.accountSid}")
    private String ACCOUNT_SID;

    @Value("${twilio.authToken}")
    private String AUTH_TOKEN;

    @Value("${twilio.phoneNumber}")
    private String TWILIO_PHONE_NUMBER;





    @Value("${cloudinary.cloudName}")
    private String cloudName;

    @Value("${cloudinary.apiKey}")
    private String apiKey;

    @Value("${cloudinary.apiSecret}")
    private String apiSecret;

    @Value("${cloudinary.apiEnvironmentVariable}")
    private String apiEnvironmentVariable;




    private int storedOtp;



    public void saveEmployee(Employee employee) {
        employeeRepository.save(employee);
    }

    public Employee findByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    //    get all employess
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }



    //    get employee by id
    public Employee getEmployeeById(int empById) {
        return employeeRepository.findById(empById)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
    }



    //    Add employee
    public Employee addEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }


    //    Update particular employee by Id by PUT
    public Employee updateEmployee(int empId, Employee updatedEmployee) {
        Employee employee = employeeRepository.findById(empId)
                .orElseThrow(() -> new RuntimeException("Employee not found with id " + empId));

        employee.setPassword(updatedEmployee.getPassword());
        employee.setConfirmPassword(updatedEmployee.getConfirmPassword());
        employee.setFullName(updatedEmployee.getFullName());
        employee.setMobileNo(updatedEmployee.getMobileNo());
        employee.setParentNo(updatedEmployee.getParentNo());
        employee.setEmail(updatedEmployee.getEmail());
        employee.setDob(updatedEmployee.getDob());
        employee.setCurrentAddress(updatedEmployee.getCurrentAddress());
        employee.setPermanentAddress(updatedEmployee.getPermanentAddress());
        employee.setAdharNo(updatedEmployee.getAdharNo());
        employee.setPanNo(updatedEmployee.getPanNo());
        employee.setJoiningDate(updatedEmployee.getJoiningDate());
        employee.setDepartment(updatedEmployee.getDepartment());
        employee.setDutyType(updatedEmployee.getDutyType());
        employee.setSalary(updatedEmployee.getSalary());
        employee.setWorkDetail(updatedEmployee.getWorkDetail());
        employee.setBloodGroup(updatedEmployee.getBloodGroup());
        employee.setGender(updatedEmployee.getGender());
        employee.setStatus(updatedEmployee.getStatus());
        employee.setEmployeePhoto(updatedEmployee.getEmployeePhoto());
        employee.setIdProof(updatedEmployee.getIdProof());
        employee.setResume(updatedEmployee.getResume());
        employee.setAddressProof(updatedEmployee.getAddressProof());
        employee.setStandard(updatedEmployee.getStandard());
        employee.setOsen(updatedEmployee.getOsen());
        employee.setCity(updatedEmployee.getCity());
        employee.setCountry(updatedEmployee.getCountry());
        employee.setWorkLocation(updatedEmployee.getWorkLocation());
        employee.setEsicNo(updatedEmployee.getEsicNo());
        employee.setCpfNo(updatedEmployee.getCpfNo());
        employee.setExperienceLetter(updatedEmployee.getExperienceLetter());
        employee.setLandmark(updatedEmployee.getLandmark());
        employee.setState(updatedEmployee.getState());
        employee.setEmployeeType(updatedEmployee.getEmployeeType());
        employee.setEnddate(updatedEmployee.getEnddate());
        employee.setPinCode(updatedEmployee.getPinCode());
        employee.setDistrict(updatedEmployee.getDistrict());
        employee.setBasicQualification(updatedEmployee.getBasicQualification());
        employee.setProfessionalQualification(updatedEmployee.getProfessionalQualification());
        employee.setShift(updatedEmployee.getShift());
        employee.setShiftStartTime(updatedEmployee.getShiftStartTime());
        employee.setShiftEndTime(updatedEmployee.getShiftEndTime());
        employee.setCreateAt(updatedEmployee.getCreateAt());
        employee.setEmployeecategory(updatedEmployee.getEmployeecategory());
        return employeeRepository.save(employee);
    }
    
    

    //    Update employee by patch
    public Employee patchEmployee(int empId, Map<String, Object> updates) {
        Employee employee = employeeRepository.findById(empId)
                .orElseThrow(() -> new RuntimeException("Employee not found with id " + empId));

        for (Map.Entry<String, Object> entry : updates.entrySet()) {
            String fieldName = entry.getKey();
            Object value = entry.getValue();

            try {
                Field field = Employee.class.getDeclaredField(fieldName);
                field.setAccessible(true);
                field.set(employee, value);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                throw new RuntimeException("Failed to update employee: " + e.getMessage());
            }
        }

        return employeeRepository.save(employee);
    }



    //    Delete Employee BY ID
    public void deleteEmployee(int empId) {
        employeeRepository.deleteById(empId);
    }



    //    Delete all Employees
    @Transactional
    public void deleteAllEmployees() {
        employeeRepository.deleteAllEmployees();
    }



    //    Search employee by Id
    public Employee searchEmployeeById(int empId) {
        return employeeRepository.findById(empId)
                .orElseThrow(() -> new RuntimeException("Employee not found with id " + empId));
    }




    //    Search employee by Full Name
    public List<Employee> searchEmployeeByfullName(String fullName) {
        return employeeRepository.findByfullNameContaining(fullName);
    }





    //    Send otp to particular employee
    public void sendSmsOtp(String mobileNo) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        int otp = generateOtp();

        // Find employee by mobile number
        Employee employee = employeeRepository.findByMobileNo(mobileNo);

        // Check if employee is found
        if (employee != null) {
            // Save the OTP in the database
            employee.setOtp(otp);
            employeeRepository.save(employee);

            Message.creator(
                    new PhoneNumber("+91 " + mobileNo),
                    new PhoneNumber(TWILIO_PHONE_NUMBER),
                    "Your OTP is: " + otp
            ).create();
        } else {
            // Handle case where employee is not found
            System.out.println("Employee not found for mobile number: " + mobileNo);
        }
    }




    //    Verify the sent otp
    public String verifyOtp(String mobileNo, int otp) {
        Employee employee = employeeRepository.findByMobileNo(mobileNo);

        // Verify OTP
        if (employee != null && otp == employee.getOtp()) {
            return "OTP verified for " + mobileNo;
        } else {
            return "OTP verification failed";
        }
    }


    // Generate a random 6-digit OTP
    private int generateOtp() {
        return (int) ((Math.random() * 900000) + 100000);
    }



    
    public Employee getEmployeeByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }


    public String uploadImageToCloudinary(MultipartFile file) {
        try {
            Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
                    "cloud_name", cloudName,
                    "api_key", apiKey,
                    "api_secret", apiSecret,
                    "api_environment_variable", apiEnvironmentVariable
            ));

            Map uploadResult = cloudinary.uploader().upload(file.getBytes(), ObjectUtils.emptyMap());
            return (String) uploadResult.get("secure_url");
        } catch (IOException e) {
            throw new RuntimeException("Failed to upload image to Cloudinary: " + e.getMessage());
        }
    }

    public String uploadIdProofToCloudinary(MultipartFile file) {
        try {
            Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
                    "cloud_name", cloudName,
                    "api_key", apiKey,
                    "api_secret", apiSecret,
                    "api_environment_variable", apiEnvironmentVariable
            ));

            Map uploadResult = cloudinary.uploader().upload(file.getBytes(), ObjectUtils.emptyMap());
            return (String) uploadResult.get("secure_url");
        } catch (IOException e) {
            throw new RuntimeException("Failed to upload ID proof to Cloudinary: " + e.getMessage());
        }
    }

    public String uploadAddressProofToCloudinary(MultipartFile file) {
        try {
            Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
                    "cloud_name", cloudName,
                    "api_key", apiKey,
                    "api_secret", apiSecret,
                    "api_environment_variable", apiEnvironmentVariable
            ));

            Map uploadResult = cloudinary.uploader().upload(file.getBytes(), ObjectUtils.emptyMap());
            return (String) uploadResult.get("secure_url");
        } catch (IOException e) {
            throw new RuntimeException("Failed to upload address proof to Cloudinary: " + e.getMessage());
        }
    }

    public String uploadResumeToCloudinary(MultipartFile file) {
        try {
            Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
                    "cloud_name", cloudName,
                    "api_key", apiKey,
                    "api_secret", apiSecret,
                    "api_environment_variable", apiEnvironmentVariable
            ));

            Map uploadResult = cloudinary.uploader().upload(file.getBytes(), ObjectUtils.emptyMap());
            return (String) uploadResult.get("secure_url");
        } catch (IOException e) {
            throw new RuntimeException("Failed to upload resume to Cloudinary: " + e.getMessage());
        }
    }

    public String uploadExperienceLetterToCloudinary(MultipartFile file) {
        try {
            Cloudinary cloudinary = new Cloudinary(ObjectUtils.asMap(
                    "cloud_name", cloudName,
                    "api_key", apiKey,
                    "api_secret", apiSecret,
                    "api_environment_variable", apiEnvironmentVariable
            ));

            Map uploadResult = cloudinary.uploader().upload(file.getBytes(), ObjectUtils.emptyMap());
            return (String) uploadResult.get("secure_url");
        } catch (IOException e) {
            throw new RuntimeException("Failed to upload experience letter to Cloudinary: " + e.getMessage());
        }
    }


    //    download csv file of the database
    public String getAllEmployeesAsCsv() {
        List<Employee> employees = employeeRepository.findAll();

        try (StringWriter writer = new StringWriter();
             CSVWriter csvWriter = new CSVWriter(writer, CSVWriter.DEFAULT_SEPARATOR, CSVWriter.NO_QUOTE_CHARACTER, CSVWriter.NO_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END)) {

            // Write CSV header
            String[] headerRecord = {
                    "empID", "password", "confirmPassword", "fullName", "mobileNo",
                    "otp", "parentNo", "email", "dob", "currentAddress", "permanentAddress",
                    "adharNo", "panNo", "joiningDate", "department", "dutyType", "salary",
                    "workDetail", "bloodGroup", "gender", "status", "employeePhoto",
                    "idProof", "resume", "addressProof", "standard", "OSEN", "City", "Country",
                    "WorkLocation", "ToMail", "subject", "body"
            };
            csvWriter.writeNext(headerRecord);

            // Write CSV data
            for (Employee employee : employees) {
                String[] dataRecord = {
                        String.valueOf(employee.getEmpID()), employee.getPassword(), employee.getConfirmPassword(), employee.getFullName(), employee.getMobileNo(),
                        String.valueOf(employee.getOtp()), String.valueOf(employee.getParentNo()), employee.getEmail(), employee.getDob().toString(), employee.getCurrentAddress(), employee.getPermanentAddress(),
                        String.valueOf(employee.getAdharNo()), String.valueOf(employee.getPanNo()), employee.getJoiningDate().toString(), employee.getDepartment(), employee.getDutyType(), String.valueOf(employee.getSalary()),
                        employee.getWorkDetail(), employee.getBloodGroup(), employee.getGender(), String.valueOf(employee.getStatus()), employee.getEmployeePhoto(),
                        employee.getIdProof(), employee.getResume(), employee.getAddressProof(), String.valueOf(employee.getStandard()), String.valueOf(employee.getOsen()), employee.getCity(), employee.getCountry(),
                        employee.getWorkLocation(), employee.getToMail(), employee.getSubject(), employee.getBody()
                };
                csvWriter.writeNext(dataRecord);
            }

            return writer.toString();
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert data to CSV: " + e.getMessage());
        }
    }


    

    //    Upload external csv file
    public void saveCsvData(MultipartFile file) {
        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            CSVReader csvReader = new CSVReader(fileReader);
            String[] nextRecord;
            csvReader.readNext(); // Skip header row
            while ((nextRecord = csvReader.readNext()) != null) {
                Employee entity = new Employee();
                entity.setFullName(nextRecord[0]); // Assuming 'fullName' is the first column in the CSV
                // Set other fields as needed
                employeeRepository.save(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException("Failed to process CSV file: " + e.getMessage());
        }
    }



    public List<Employee> getEmployeesByDepartment(String department) {
        return employeeRepository.findByDepartment(department);
    }

    public List<Employee> getEmployeesByStatus(String status) {
        return employeeRepository.findByStatus(status);
    }


    private static final int OTP_VALID_DURATION = 5 * 60 * 1000; // 5 minutes

    public void sendEmailOtp(String email) {
        Employee employee = employeeRepository.findByEmail(email);
        if (employee == null) {
            throw new RuntimeException("Employee not found");
        }

        int otp = generateOtp();
        employee.setOtp(otp);
        employee.setOtpExpiry(new Date(System.currentTimeMillis() + OTP_VALID_DURATION));
        employeeRepository.save(employee);

        String subject = employee.getSubject();
        String body = "Your OTP code is " + otp;
        emailService.sendEmail(email, subject, body);
    }

    public boolean verifyEmailOtp(String email, int otp, String newPassword) {
        Employee employee = employeeRepository.findByEmail(email);
        if (employee == null || employee.getOtp() != otp || employee.getOtpExpiry().before(new Date())) {
            return false;
        }

        employee.setPassword(newPassword);
        employee.setConfirmPassword(newPassword);
        employee.setOtp(0); // reset OTP
        employee.setOtpExpiry(null); // reset OTP expiry
        employeeRepository.save(employee);

        return true;
    }

    private int generateEmailOtp() {
        return new Random().nextInt(900000) + 100000; // generate 6-digit OTP
    }
        public boolean otpVerification(String email, int otp) {
            Employee employee = employeeRepository.findByEmail(email);
            if (employee == null || employee.getOtp() != otp || employee.getOtpExpiry().before(new Date())) {
                return false;
            }

            employee.setOtp(0); // reset OTP
            employee.setOtpExpiry(null); // reset OTP expiry
            employeeRepository.save(employee);

            return true;
        }

    public Employee searchEmployeeByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }
    public List<Employee> getEmployeesByShift(String shift) {
        return employeeRepository.findByShift(shift);
    }

    public List<Employee> getEmployeesByEmployeeType(String employeeType) {
        return employeeRepository.findByEmployeeType(employeeType);
    }

    public List<Employee> getEmployeesByDutyType(String dutyType) {
        return employeeRepository.findByDutyType(dutyType);
    }
}
