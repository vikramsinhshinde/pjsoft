package com.example.EmployeeSys.EmployeeSys.Service;


import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Model.EmployeeCategory;
import com.example.EmployeeSys.EmployeeSys.Model.LeaveRequest;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeCategoryRepository;
import com.example.EmployeeSys.EmployeeSys.Repository.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

@Service
public class LeaveRequestService {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    @Autowired
    private EmployeeCategoryRepository employeeCategoryRepository;

    public LeaveRequest saveLeaveRequest(LeaveRequest leaveRequest) {

        EmployeeCategory employeeCategory = employeeCategoryRepository.findCategoryByCategoryName(leaveRequest.getCategoryName());
        Employee employee = employeeService.getEmployeeById(leaveRequest.getEmpID());

        int totalleaveCounttemp = 0;

        // Calculate total leave count if both dates are present
        if (leaveRequest.getFromDate() != null && leaveRequest.getToDate() != null) {
            totalleaveCounttemp = (int) (ChronoUnit.DAYS.between(leaveRequest.getFromDate(), leaveRequest.getToDate()) + 1);
            leaveRequest.setTotalleavecount((long) totalleaveCounttemp);
        }

        if(totalleaveCounttemp+employee.getPaidleaves()<employeeCategory.getTotalPaidLeave()){
            leaveRequest.setPaidleave(totalleaveCounttemp);
        }else{
            leaveRequest.setUnpaidleave(totalleaveCounttemp-employeeCategory.getTotalPaidLeave());
        }

//        while ((totalleaveCounttemp+employee.getPaidleaves())>designation.getTotalPaidLeave()){
//            leaveRequest.setPaidleave(totalleaveCounttemp);
//        }

        leaveRequest.setStatus("Pending");

        return leaveRequestRepository.save(leaveRequest);
    }

    public List<LeaveRequest> getAllLeaveRequests() {
        return leaveRequestRepository.findAll();
    }

    public Optional<LeaveRequest> getLeaveRequestById(Long id) {
        return leaveRequestRepository.findById(id);
    }

    public void deleteLeaveRequest(Long id) {
        leaveRequestRepository.deleteById(id);
    }

    public LeaveRequest updateLeaveRequestStatus(Long id, LeaveRequest leaveRequest) {
        LeaveRequest existingLeaveRequest = leaveRequestRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Leave request not found"));

        if (Boolean.TRUE.equals(leaveRequest.getStatus())) {
            Long empid= Long.valueOf(leaveRequest.getEmpID());

            Long paidleavesCount= (long) leaveRequest.getPaidleave();
            Employee employee= employeeService.getEmployeeById(leaveRequest.getEmpID());
            employee.setPaidleaves(Math.toIntExact(paidleavesCount)+employee.getPaidleaves());

            employee.setUnpaidleaves(leaveRequest.getUnpaidleave()+employee.getUnpaidleaves());
        }
        existingLeaveRequest.setStatus("Approved");
        return leaveRequestRepository.save(existingLeaveRequest);
    }

    public LeaveRequest rejectStatus(Long id, LeaveRequest leaveRequest) {
        LeaveRequest existingLeaveRequest = leaveRequestRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Leave request not found"));

        if (Boolean.TRUE.equals(leaveRequest.getStatus())) {
            Long empid= Long.valueOf(leaveRequest.getEmpID());

            Long paidleavesCount= (long) leaveRequest.getPaidleave();
            Employee employee= employeeService.getEmployeeById(leaveRequest.getEmpID());
            employee.setPaidleaves(Math.toIntExact(paidleavesCount)+employee.getPaidleaves());

            employee.setUnpaidleaves(leaveRequest.getUnpaidleave()+employee.getUnpaidleaves());
        }
        existingLeaveRequest.setStatus("Rejected");
        return leaveRequestRepository.save(existingLeaveRequest);
    }

    public List<LeaveRequest> getLeaveRequestsByReasonDescriptionAndEmployeeId(String reasondescription, Integer empID)
    {
        return leaveRequestRepository.findByReasonDescriptionAndEmployeeId(reasondescription, empID);
    }

    public List<LeaveRequest> getLeaveRequestsForLast7Days() {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusDays(7);
        return leaveRequestRepository.findLeaveRequestsByDateRange(startDate, endDate);
    }

    public List<LeaveRequest> getLeaveRequestsForLastMonth() {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusMonths(1);
        return leaveRequestRepository.findLeaveRequestsByDateRange(startDate, endDate);
    }

    public List<LeaveRequest> getLeaveRequestsForLastYear() {
        LocalDate endDate = LocalDate.now();
        LocalDate startDate = endDate.minusYears(1);
        return leaveRequestRepository.findLeaveRequestsByDateRange(startDate, endDate);
    }

    public List<LeaveRequest> getLeaveRequestsByStatusAndEmpID(String status, Integer empID) {
        return leaveRequestRepository.findByStatusAndEmpID(status, empID);
    }

    public List<LeaveRequest> getLeaveRequestByStatus(String status){
        return leaveRequestRepository.findLeaveRequestsByStatus(status);
    }
}

