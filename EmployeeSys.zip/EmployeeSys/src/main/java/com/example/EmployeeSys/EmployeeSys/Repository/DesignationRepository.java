//package com.example.EmployeeSys.EmployeeSys.Repository;
//
//import com.example.EmployeeSys.EmployeeSys.Model.Designation;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//
//import java.util.Optional;
//
//@Repository
//public interface DesignationRepository extends JpaRepository<Designation, Long> {
//
//    // You can add custom query methods if needed
//    @Query("SELECT d FROM Designation d WHERE d.designationname = :designationname")
//    Designation findByDesignationName(@Param("designationname") String designationname);
//}
