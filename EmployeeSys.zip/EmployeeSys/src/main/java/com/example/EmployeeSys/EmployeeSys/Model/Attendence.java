package com.example.EmployeeSys.EmployeeSys.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Attendence {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    private int empID;
    private LocalDate todaysDate;
    private String name;
    private LocalTime LoginTime;
    private LocalTime LogoutTime;
    private Long minutes;
    private String status;
    private String IP;
    private String shift;
    private LocalTime breakIn;
    private LocalTime breakOut;
    private Long breakMinutes;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmpID() {
        return empID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public LocalDate getTodaysDate() {
        return todaysDate;
    }

    public void setTodaysDate(LocalDate todaysDate) {
        this.todaysDate = todaysDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalTime getLoginTime() {
        return LoginTime;
    }

    public void setLoginTime(LocalTime loginTime) {
        LoginTime = loginTime;
    }

    public LocalTime getLogoutTime() {
        return LogoutTime;
    }

    public void setLogoutTime(LocalTime logoutTime) {
        LogoutTime = logoutTime;
    }

    public Long getMinutes() {
        return minutes;
    }

    public void setMinutes(Long minutes) {
        this.minutes = minutes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public LocalTime getBreakIn() {
        return breakIn;
    }

    public void setBreakIn(LocalTime breakIn) {
        this.breakIn = breakIn;
    }

    public LocalTime getBreakOut() {
        return breakOut;
    }

    public void setBreakOut(LocalTime breakOut) {
        this.breakOut = breakOut;
    }

    public Long getBreakMinutes() {
        return breakMinutes;
    }

    public void setBreakMinutes(Long breakMinutes) {
        this.breakMinutes = breakMinutes;
    }


    @Override
    public String toString() {
        return "Attendence{" +
                "id=" + id +
                ", empID=" + empID +
                ", todaysDate=" + todaysDate +
                ", name='" + name + '\'' +
                ", LoginTime=" + LoginTime +
                ", LogoutTime=" + LogoutTime +
                ", minutes=" + minutes +
                ", status='" + status + '\'' +
                ", IP='" + IP + '\'' +
                ", shift='" + shift + '\'' +
                ", breakIn=" + breakIn +
                ", breakOut=" + breakOut +
                ", breakMinutes=" + breakMinutes +
                '}';
    }

    public Attendence(int id, int empID, LocalDate todaysDate, String name, LocalTime loginTime, LocalTime logoutTime, Long minutes, String status, String IP, String shift, LocalTime breakIn, LocalTime breakOut, Long breakMinutes) {
        this.id = id;
        this.empID = empID;
        this.todaysDate = todaysDate;
        this.name = name;
        LoginTime = loginTime;
        LogoutTime = logoutTime;
        this.minutes = minutes;
        this.status = status;
        this.IP = IP;
        this.shift = shift;
        this.breakIn = breakIn;
        this.breakOut = breakOut;
        this.breakMinutes = breakMinutes;
    }

    public Attendence(){
        super();
    }
}
