package com.example.EmployeeSys.EmployeeSys.Repository;

import com.example.EmployeeSys.EmployeeSys.Model.LeaveRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface
LeaveRequestRepository extends JpaRepository<LeaveRequest, Long>
{
    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.reasondescription = :reasondescription AND lr.empID = :empID")
    List<LeaveRequest> findByReasonDescriptionAndEmployeeId(@Param("reasondescription") String reasondescription, @Param("empID") Integer empID);
    //List<LeaveRequest> findByReasonDescriptionAndEmployeeId(String reasonDescription, Integer employeeId);

    //@Query("SELECT lr FROM LeaveRequest lr WHERE lr.empID = :empID AND lr.fromDate >= :startDate AND lr.toDate <= :endDate")
    //List<LeaveRequest> findLeaveRequestsByDateRange(@Param("empID") Integer empID, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);


 //   @Query("SELECT lr FROM LeaveRequest lr WHERE lr.empID = :empID AND lr.fromDate >= :startDate AND lr.toDate <= :endDate")
   // List<LeaveRequest> findLeaveRequestsByDateRange(@Param("empID") Integer empID, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.fromDate >= :startDate AND lr.toDate <= :endDate")
    List<LeaveRequest> findLeaveRequestsByDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.status = :status")
    List<LeaveRequest> findLeaveRequestsByStatus(@Param("status") String status);

    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.status = :status AND lr.empID = :empID")
    List<LeaveRequest> findByStatusAndEmpID(@Param("status") String status, @Param("empID") Integer empID);

}

