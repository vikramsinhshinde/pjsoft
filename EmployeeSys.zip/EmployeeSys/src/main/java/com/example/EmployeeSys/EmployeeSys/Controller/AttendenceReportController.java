package com.example.EmployeeSys.EmployeeSys.Controller;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Service.AttendencereportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000/")

@Controller
public class AttendenceReportController {

    @Autowired
    AttendencereportService attendencereportService;

    @GetMapping("/getLast7DaysAttendenceByEmpId/{empID}")
    public ResponseEntity<List<Attendence>> getLast7DaysAttendenceByEmpId(@PathVariable Integer empID) {
        List<Attendence> attendences = attendencereportService.getLast7DaysAttendenceByEmpId(empID);
        if (!attendences.isEmpty()) {
            return ResponseEntity.ok(attendences);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/getLast30DaysAttendenceByEmpId/{empID}")
    public ResponseEntity<List<Attendence>> getLast30DaysAttendenceByEmpId(@PathVariable Integer empID) {
        List<Attendence> attendences = attendencereportService.getLast30DaysAttendenceByEmpId(empID);
        if (!attendences.isEmpty()) {
            return ResponseEntity.ok(attendences);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/getLast365DaysAttendenceByEmpId/{empID}")
    public ResponseEntity<List<Attendence>> getLast365DaysAttendenceByEmpId(@PathVariable Integer empID) {
        List<Attendence> attendences = attendencereportService.getLast365DaysAttendenceByEmpId(empID);
        if (!attendences.isEmpty()) {
            return ResponseEntity.ok(attendences);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/getLast7DaysAttendenceCountByEmpId/{empID}")
    public ResponseEntity<Long> getLast7DaysAttendenceCountByEmpId(@PathVariable Integer empID) {
        long count = attendencereportService.getLast7DaysAttendenceCountByEmpId(empID);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/getLast30DaysAttendenceCountByEmpId/{empID}")
    public ResponseEntity<Long> getLast30DaysAttendenceCountByEmpId(@PathVariable Integer empID) {
        long count = attendencereportService.getLast30DaysAttendenceCountByEmpId(empID);
        return ResponseEntity.ok(count);
    }

    @GetMapping("/getLast365DaysAttendenceCountByEmpId/{empID}")
    public ResponseEntity<Long> getLast365DaysAttendenceCountByEmpId(@PathVariable Integer empID) {
        long count = attendencereportService.getLast365DaysAttendenceCountByEmpId(empID);
        return ResponseEntity.ok(count);
    }


}
