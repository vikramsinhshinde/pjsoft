package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.EmployeeCategory;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeCategoryService {

    private static final Logger logger = LoggerFactory.getLogger(EmployeeCategoryService.class);


    @Autowired
    private EmployeeCategoryRepository employeeCategoryRepository;

    // Save a new Employee Category
    public EmployeeCategory save(EmployeeCategory employeeCategory) {
        return employeeCategoryRepository.save(employeeCategory);
    }

    // Find all Employee Categories
    public List<EmployeeCategory> findAll() {
        return employeeCategoryRepository.findAll();
    }

    // Find Employee Category by ID
    public Optional<EmployeeCategory> findById(Long id) {
        return employeeCategoryRepository.findById(id);
    }

    public void deleteEmployeeCategory(Long id) {
        logger.info("Attempting to delete EmployeeCategory with id: {}", id);
        if (employeeCategoryRepository.existsById(id)) {
            employeeCategoryRepository.deleteById(id);
            logger.info("Successfully deleted EmployeeCategory with id: {}", id);
        } else {
            logger.error("EmployeeCategory not found with id: {}", id);
            throw new IllegalArgumentException("Employee category not found with id: " + id);
        }
    }

    // Update an existing Employee Category
    public EmployeeCategory updateEmployeeCategory(Long id, EmployeeCategory updatedEmployeeCategory) {
        Optional<EmployeeCategory> existingEmployeeCategoryOptional = employeeCategoryRepository.findById(id);
        if (existingEmployeeCategoryOptional.isPresent()) {
            EmployeeCategory existingEmployeeCategory = existingEmployeeCategoryOptional.get();
            existingEmployeeCategory.setCategoryName(updatedEmployeeCategory.getCategoryName());
            //existingEmployeeCategory.setBonusPercentage(updatedEmployeeCategory.getBonusPercentage());
            existingEmployeeCategory.setHraPercentage(updatedEmployeeCategory.getHraPercentage());
            existingEmployeeCategory.setTaPercentage(updatedEmployeeCategory.getTaPercentage());
            existingEmployeeCategory.setIncentivePercentage(updatedEmployeeCategory.getIncentivePercentage());
            existingEmployeeCategory.setSpiPercentage(updatedEmployeeCategory.getSpiPercentage());
            existingEmployeeCategory.setMedicalAllowancePercentage(updatedEmployeeCategory.getMedicalAllowancePercentage());
            existingEmployeeCategory.setPfPercentage(updatedEmployeeCategory.getPfPercentage());
            existingEmployeeCategory.setEsfPercentage(updatedEmployeeCategory.getEsfPercentage());
            existingEmployeeCategory.setProfessionalTaxPercentage(updatedEmployeeCategory.getProfessionalTaxPercentage());
            existingEmployeeCategory.setIncomeTaxPercentage(updatedEmployeeCategory.getIncomeTaxPercentage());
            existingEmployeeCategory.setCategoryName(updatedEmployeeCategory.getCategoryName());
            return employeeCategoryRepository.save(existingEmployeeCategory);
        } else {
            throw new RuntimeException("Employee Category not found");
        }
    }


}

