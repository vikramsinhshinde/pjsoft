package com.example.EmployeeSys.EmployeeSys.Service;
import com.example.EmployeeSys.EmployeeSys.Model.Manager;
import com.example.EmployeeSys.EmployeeSys.Repository.ManagerRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ManagerService {

    @Autowired
    private ManagerRepository managerRepository;

    public Manager saveManager(Manager manager) {
        if (!manager.getPassword().equals(manager.getConfirmPassword())) {
            throw new IllegalArgumentException("Passwords do not match");
        }
        return managerRepository.save(manager);
    }

    public List<Manager> getAllManagers() {
        return managerRepository.findAll();
    }

    public Optional<Manager> getManagerById(Long id) {
        return managerRepository.findById(id);
    }

    public Manager updateManager(Long id, Manager managerDetails) {
        Manager manager = managerRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Manager not found"));
        manager.setName(managerDetails.getName());
        manager.setPassword(managerDetails.getPassword());
        manager.setConfirmPassword(managerDetails.getConfirmPassword());
        manager.setEmail(managerDetails.getEmail());
        return managerRepository.save(manager);
    }

    public void deleteManager(Long id) {
        managerRepository.deleteById(id);
    }
}
