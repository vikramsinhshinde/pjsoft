package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Repository.AttendenceRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AttendenceReportimpl implements AttendencereportService {

    @Autowired
    AttendenceRepo attendenceRepo;

    @Override
    public List<Attendence> getLast7DaysAttendenceByEmpId(Integer empID) {
        LocalDate sevenDaysAgo = LocalDate.now().minusDays(7);
        List<Attendence> allAttendences = attendenceRepo.findByEmpID(empID);
        return allAttendences.stream()
                .filter(attendence -> !attendence.getTodaysDate().isBefore(sevenDaysAgo))
                .collect(Collectors.toList());
    }

    @Override
    public List<Attendence> getLast30DaysAttendenceByEmpId(Integer empID) {
        LocalDate thirtyDaysAgo = LocalDate.now().minusDays(30);
        List<Attendence> allAttendences = attendenceRepo.findByEmpID(empID);
        return allAttendences.stream()
                .filter(attendence -> !attendence.getTodaysDate().isBefore(thirtyDaysAgo))
                .collect(Collectors.toList());
    }

    @Override
    public List<Attendence> getLast365DaysAttendenceByEmpId(Integer empID) {
        LocalDate oneYearAgo = LocalDate.now().minusDays(365);
        List<Attendence> allAttendences = attendenceRepo.findByEmpID(empID);
        return allAttendences.stream()
                .filter(attendence -> !attendence.getTodaysDate().isBefore(oneYearAgo))
                .collect(Collectors.toList());
    }

    @Override
    public long getLast7DaysAttendenceCountByEmpId(Integer empID) {
        LocalDate sevenDaysAgo = LocalDate.now().minusDays(7);
        List<Attendence> allAttendences = attendenceRepo.findByEmpID(empID);
        return allAttendences.stream()
                .filter(attendence -> !attendence.getTodaysDate().isBefore(sevenDaysAgo))
                .count();
    }

    @Override
    public long getLast30DaysAttendenceCountByEmpId(Integer empID) {
        LocalDate thirtyDaysAgo = LocalDate.now().minusDays(30);
        List<Attendence> allAttendences = attendenceRepo.findByEmpID(empID);
        return allAttendences.stream()
                .filter(attendence -> !attendence.getTodaysDate().isBefore(thirtyDaysAgo))
                .count();
    }

    @Override
    public long getLast365DaysAttendenceCountByEmpId(Integer empID) {
        LocalDate oneYearAgo = LocalDate.now().minusDays(365);
        List<Attendence> allAttendences = attendenceRepo.findByEmpID(empID);
        return allAttendences.stream()
                .filter(attendence -> !attendence.getTodaysDate().isBefore(oneYearAgo))
                .count();
    }

}
