package com.example.EmployeeSys.EmployeeSys.Service;

import com.example.EmployeeSys.EmployeeSys.Model.Attendence;
import com.example.EmployeeSys.EmployeeSys.Model.Employee;
import com.example.EmployeeSys.EmployeeSys.Repository.AttendenceRepo;
import com.example.EmployeeSys.EmployeeSys.Repository.EmployeeRepository;
import com.example.EmployeeSys.EmployeeSys.exceptions.ResourceNotFoundException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Service
public class AttendenceServiceimpl implements AttendenceService {

    @Autowired
    AttendenceRepo attendenceRepo;

    @Autowired
    EmployeeRepository employeeRepository;


    @Autowired
    EmployeeService employeeService;


    @Override
    public Attendence updateLogoutTime(int empID) {
        Employee employee = employeeService.getEmployeeById(empID);

        List<Attendence> attendences = attendenceRepo.findByEmpID(empID);
        if (attendences == null || attendences.isEmpty()) {
            System.out.println("Attendance record not found for Employee ID: " + empID);
            return null;
        }

        Attendence latestAttendence = attendences.stream()
                .max((a1, a2) -> a1.getTodaysDate().compareTo(a2.getTodaysDate()))
                .orElse(null);

        if (latestAttendence == null) {
            System.out.println("No attendance record found for Employee ID: " + empID);
            return null;
        }

        if (latestAttendence.getLogoutTime() != null) {
            System.out.println("Logout time already set for Employee ID: " + empID);
            return latestAttendence; // Return the existing attendance object
        }

        // Calculate break minutes
        long breakMinutes = 0;
        if (latestAttendence.getBreakIn() != null && latestAttendence.getBreakOut() != null) {
            breakMinutes = Duration.between(latestAttendence.getBreakIn(), latestAttendence.getBreakOut()).toMinutes();
        }

        latestAttendence.setLogoutTime(LocalTime.now());
        Duration duration = Duration.between(latestAttendence.getLoginTime(), latestAttendence.getLogoutTime());
        long totalMinutes = duration.toMinutes() - breakMinutes;
        latestAttendence.setMinutes(totalMinutes);

        // Check shift timings
        LocalTime shiftInTime = LocalTime.parse(employee.getShiftStartTime());
//        LocalTime shiftEndTime = LocalTime.parse(employee.getShiftEndTime());
        if (latestAttendence.getLoginTime().isAfter(shiftInTime)) {
            latestAttendence.setStatus("Late");
        } else {
            latestAttendence.setStatus("On time");
        }


        return attendenceRepo.save(latestAttendence);
    }






    @Override
    public List<Attendence> getAllAttendence() {
        return (List<Attendence>) attendenceRepo.findAll();
    }




    @Override
    public void deleteAllAttendences() {
        attendenceRepo.deleteAll();
    }


    @Override
    public void deleteAttendencesByEmpId(Integer empID) {
        List<Attendence> attendences = getAttendenceByEmpId(empID);
        for (Attendence attendence : attendences) {
            attendenceRepo.deleteById(Long.valueOf(attendence.getId()));
        }
    }



    @Override
    public List<Attendence> getAttendenceByEmpId(Integer empID) {
        List<Attendence> allAttendences = getAllAttendence();
        List<Attendence> filteredAttendences = new ArrayList<>();
        for (Attendence attendence : allAttendences) {
            if (attendence.getEmpID() == empID) { // Compare primitive int with Integer
                filteredAttendences.add(attendence);
            }
        }
        return filteredAttendences;
    }



    @Override
    public void breakIn(Integer empID, LocalTime breakInTime) {
        Attendence attendence = attendenceRepo.findByEmpIDAndTodaysDate(empID, LocalDate.now());
        if (attendence == null) {
            throw new ResourceNotFoundException("Attendence not found for empID: " + empID);
        }
        attendence.setBreakIn(breakInTime);
        attendenceRepo.save(attendence);
    }

    @Override
    public Map<String, Object> breakOut(Integer empID, LocalTime breakOutTime) {
        Attendence attendence = attendenceRepo.findByEmpIDAndTodaysDate(empID, LocalDate.now());
        if (attendence == null) {
            throw new ResourceNotFoundException("Attendence not found for empID: " + empID);
        }
        attendence.setBreakOut(breakOutTime);
        long minutes = Duration.between(attendence.getBreakIn(), breakOutTime).toMinutes();
        attendence.setBreakMinutes(minutes);
        attendenceRepo.save(attendence);

        Map<String, Object> response = new HashMap<>();
        response.put("message", "Break-out time recorded.");
        response.put("breakMinutes", minutes);
        return response;
    }

    @Override
    public List<Attendence> getTodaysAttendance() {
        LocalDate today = LocalDate.now();
        return attendenceRepo.findAllByTodaysDate(today);
    }

    @Override
    public int getTotalWorkingDaysForEmployee(Integer empID) {
        List<Attendence> attendances = attendenceRepo.findByEmpID(empID);
        Set<LocalDate> workingDays = new HashSet<>();

        for (Attendence attendance : attendances) {
            LocalDateTime loginDateTime = attendance.getLoginTime().atDate(attendance.getTodaysDate());
            LocalDate loginDate = loginDateTime.toLocalDate();
            workingDays.add(loginDate);
        }

        return workingDays.size();
    }



    @Override
    public List<Attendence> getAttendenceByEmpIdAndDateRange(Integer empID, LocalDate fromDate, LocalDate toDate) {
        return attendenceRepo.findByEmpIDAndTodaysDateBetween(empID, fromDate, toDate);
    }
    @Override
    public List<Attendence> getPresentEmployees(LocalDate date) {
        return attendenceRepo.findByTodaysDate(date);
    }

    @Override
    public List<Employee> getAbsentEmployees(LocalDate date) {
        // Fetch all employees
        List<Employee> allEmployees = employeeRepository.findAll();

        // Fetch all present employee IDs from today's date in the attendence table
        List<Integer> presentEmployeeIds = attendenceRepo.findByTodaysDate(date)
                .stream()
                .map(Attendence::getEmpID)
                .collect(Collectors.toList());

        // Return employees whose empID is not in the presentEmployeeIds list
        return allEmployees.stream()
                .filter(employee -> !presentEmployeeIds.contains(employee.getEmpID()))
                .collect(Collectors.toList());
    }
    @Override
    public int getPresentEmployeeCount(LocalDate date) {
        List<Attendence> presentEmployees = attendenceRepo.findByTodaysDate(date);
        return presentEmployees.size();
    }

    @Override
    public int getAbsentEmployeeCount(LocalDate date) {
        List<Employee> allEmployees = employeeRepository.findAll();
        List<Integer> presentEmployeeIds = attendenceRepo.findByTodaysDate(date)
                .stream()
                .map(Attendence::getEmpID)
                .collect(Collectors.toList());

        long absentEmployeeCount = allEmployees.stream()
                .filter(employee -> !presentEmployeeIds.contains(employee.getEmpID()))
                .count();

        return (int) absentEmployeeCount;
    }
}



