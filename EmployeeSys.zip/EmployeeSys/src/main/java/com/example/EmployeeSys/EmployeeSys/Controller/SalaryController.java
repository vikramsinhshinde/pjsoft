package com.example.EmployeeSys.EmployeeSys.Controller;

import com.example.EmployeeSys.EmployeeSys.Model.Salary;
import com.example.EmployeeSys.EmployeeSys.Service.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000/")


@RestController
@RequestMapping("/salaries")
public class SalaryController {

    @Autowired
    private SalaryService salaryService;

    @PostMapping("/add")
    public ResponseEntity<Salary> createSalary(@RequestBody Salary salary) {
        Salary savedSalary = salaryService.saveSalary(salary, salary.getEmpID());
        return ResponseEntity.ok(savedSalary);
    }

    @GetMapping("/all")
    public List<Salary> findSalaryAll() {
    return salaryService.findSalaryAll();
    }

    @GetMapping("/getSalaryById/{id}")
    public Salary getSalaryById(@PathVariable Long id) {
        return salaryService.findSalaryById(id);
    }

    @DeleteMapping("/deletesalary/{id}")
    public void deleteSalary(@PathVariable Long id) {
        salaryService.deleteSalary(id);
    }

    @GetMapping("/byEmployeeIdAndMonthAndYear")
    public List<Salary> getSalariesByEmployeeIdAndMonthAndYear(
            @RequestParam int empID,
            @RequestParam int month,
            @RequestParam int year) {
        return salaryService.getSalariesByEmployeeIdAndMonthAndYear(empID, month, year);
    }

    @GetMapping("/byEmployeeId/{empID}")
    public ResponseEntity<List<Salary>> getSalariesByEmployeeId(@PathVariable int empID) {
        List<Salary> salaries = salaryService.getSalariesByEmployeeId(empID);
        return ResponseEntity.ok(salaries);
    }

    @GetMapping("/byCategoryName/{employeecategory}")
    public ResponseEntity<List<Salary>> getSalariesByCategoryName(@PathVariable String employeecategory) {
        List<Salary> salaries = salaryService.getSalariesByCategoryName(employeecategory);
        return ResponseEntity.ok(salaries);
    }

    @GetMapping("/byMonthAndYear")
    public ResponseEntity<List<Salary>> getSalariesByMonthAndYear(@RequestParam int month, @RequestParam int year) {
        List<Salary> salaries = salaryService.getSalariesByMonthAndYear(month, year);
        return ResponseEntity.ok(salaries);
    }
}
