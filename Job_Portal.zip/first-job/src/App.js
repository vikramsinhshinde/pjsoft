// // src/App.js
// import React from 'react';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import './App.css';
// import JobApplicationForm from './Component/JobApplicationForm';
// import JobRecord from './Component/JobRecord';
// import SideBar from './Component/SideBar';
// import NavBar from './Component/NavBar';

// function App() {
//   return (
//     <Router>
//               <SideBar/>
//               <NavBar/>
//       <div className="App">
//         {/* Define routes */}
//         <Routes>
//           <Route path="/" element={<Home />} />
//           <Route path="/JobApplicationForm" element={<JobApplicationForm />} />
//           <Route path="/JobRecord" element={<JobRecord />} />
//         </Routes>
//       </div>
//     </Router>
//   );
// }

// // Home component to be displayed at the root path
// const Home = () => (
//   <div>
//     <h2>Welcome to Home Page</h2>
//   </div>
// );

// export default App;




// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import JobApplicationForm from './Component/JobApplicationForm';
import JobRecord from './Component/JobRecord';
import SideBar from './Component/SideBar';
import NavBar from './Component/NavBar';
import Dashboard from './Component/Dashboard'; // Import Dashboard component

function App() {
  return (
    <Router>
      <SideBar />
      <NavBar />
      <div className="App">
        <Routes>
          <Route path="/" element={<Dashboard />} /> {/* Use Dashboard as the home component */}
          <Route path="/JobApplicationForm" element={<JobApplicationForm />} />
          <Route path="/JobRecord" element={<JobRecord />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
