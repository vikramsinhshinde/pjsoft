// import React from 'react';
// import { 
//     Container, 
//     Grid, 
//     TextField, 
//     FormControl, 
//     MenuItem, 
//     Typography,
// } from '@mui/material';

// const skills = [
//     'JavaScript','Photoshop','Project Management','Content Writing','Sales','Human Resources', 'Python', 'Java'
// ];

// function JobDetails({ formData, handleChange, handleArrayChange, handleFileChange }) {
//   return (
//     <>
//       <Typography variant="h4" gutterBottom>Job Details</Typography>
//       <Container className="mb-4">
//         <Grid container spacing={3}>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Job Location"
//               name="jobLocation"
//               value={formData.jobLocation}
//               onChange={handleChange}
//               
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select
//               label="Position Applied"
//                 name="positionApplied"
//                 value={formData.positionApplied}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select a position</MenuItem>
//                 <MenuItem value="Developer">Developer</MenuItem>
//                 <MenuItem value="Designer">Designer</MenuItem>
//                 <MenuItem value="Manager">Manager</MenuItem>
//                 <MenuItem value="Analyst">Analyst</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select
//               label="How Did You Hear About Us?"
//                 name="heardAboutUs"
//                 value={formData.heardAboutUs}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select an option</MenuItem>
//                 <MenuItem value="LinkedIn">LinkedIn</MenuItem>
//                 <MenuItem value="Indeed">Indeed</MenuItem>
//                 <MenuItem value="Company Website">Company Website</MenuItem>
//                 <MenuItem value="Referral">Referral</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select
//               label="Skills"
//                 name="skill"
//                 value={formData.skill}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select an option</MenuItem>
//                 {skills.map((skill, idx) => (
//                   <MenuItem key={idx} value={skill}>{skill}</MenuItem>
//                 ))}
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select 
//               label="Shift Type"
//                 name="shiftType"
//                 value={formData.shiftType}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select shift type</MenuItem>
//                 <MenuItem value="Day">Day</MenuItem>
//                 <MenuItem value="Night">Night</MenuItem>
//                 <MenuItem value="Rotational">Rotational</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select
//               label="Workplace"
//                 name="workPlace"
//                 value={formData.workPlace}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select workplace</MenuItem>
//                 <MenuItem value="On-site">On-site</MenuItem>
//                 <MenuItem value="Remote">Remote</MenuItem>
//                 <MenuItem value="Hybrid">Hybrid</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select 
//               label="Employment Type"
//                 name="employmentType"
//                 value={formData.employmentType}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select employment type</MenuItem>
//                 <MenuItem value="Full-time">Full-time</MenuItem>
//                 <MenuItem value="Part-time">Part-time</MenuItem>
//                 <MenuItem value="Contract">Contract</MenuItem>
//                 <MenuItem value="Temporary">Temporary</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//         </Grid>
// <br />
//       <Typography variant="h5" gutterBottom>Employment History</Typography>
//           <Grid container spacing={3} className="mb-4">
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Company Name"
//                 name="companyName"
//                 value={formData.companyName}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Job Role"
//                 name="jobRole"
//                 value={formData.jobRole}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Reason for Leaving"
//                 name="reasonForLeaving"
//                 value={formData.reasonForLeaving}
//                 onChange={handleArrayChange}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Start Date"
//                 type="date"
//                 name="startDate"
//                 value={formData.startDate}
//                 onChange={handleArrayChange}
//                 
//                 InputLabelProps={{ shrink: true }}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="End Date"
//                 type="date"
//                 name="endDate"
//                 value={formData.endDate}
//                 onChange={handleArrayChange}
//                 InputLabelProps={{ shrink: true }}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Primary Duties"
//                 name="duties"
//                 value={formData.duties}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//           </Grid>

// <Typography variant="h5" gutterBottom>Reference</Typography>

//           <Grid container spacing={3} className="mb-4">
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Name"
//                 name="name"
//                 value={formData.name}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Relationship"
//                 name="relationship"
//                 value={formData.relationship}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Mobile"
//                 name="mobile"
//                 value={formData.mobile}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Email"
//                 type="email"
//                 name="referenceEmail"
//                 value={formData.referenceEmail}
//                 onChange={handleArrayChange}
//                 
//               />
//             </Grid>
//           </Grid>

        // <Typography variant="h5" gutterBottom>Upload Documents</Typography>


        // <Grid container spacing={3} className="mb-4">
        // <Grid item xs={12} md={4}>
        //     <TextField
        //       
        //       type="file"
        //       accept=".pdf"
        //       name="profilePicture"
        //       onChange={handleFileChange}
        //       helperText="Profile Picture (JPG, max 1MB)"
        //     />
        //   </Grid>
        //   <Grid item xs={12} md={4}>
        //     <TextField
        //       
        //       type="file"
        //       accept=".pdf"
        //       name="resume"
        //       onChange={handleFileChange}
        //       helperText="Resume (PDF, max 1MB)"
        //     />
        //   </Grid>
        //   <Grid item xs={12} md={4}>
        //     <TextField
        //       
        //       type="file"
        //       accept=".pdf"
        //       name="experienceLetter"
        //       onChange={handleFileChange}
        //       helperText="Experience Letter (PDF, max 1MB)"
        //     />
        //   </Grid>
        // </Grid>
//       </Container>
//     </>
//   );
// }

// export default JobDetails;

import React from 'react';
import { 
    Container, 
    Grid, 
    TextField, 
    FormControl, 
    MenuItem, 
    Typography,
    RadioGroup,
    FormControlLabel,
    Radio,
    Box,
    Checkbox,
    Autocomplete
} from '@mui/material';

const skills = [
    'JavaScript', 'Photoshop','Project Management','Content Writing','Sales','Human Resources', 'Python', 'Java'
];

const jobLocations = [
  'Kolhapur', 'Solapur', 'Nashik', 'Pune', 'Thane', 'Mumbai'
];

function JobDetails({ formData, handleChange,  handleFileChange, setFormData }) {
  const handleSkillsChange = (event, value) => {
    setFormData({ ...formData, skills: value });
  };
  const handleLocationsChange = (event, value) => {
    setFormData({ ...formData, jobLocations: value });
  };
  return (
    <>
      <Container className="mb-4">
        <br />
        <Typography variant="h4" gutterBottom>Job Details</Typography>
        <br />

        {/* Rest of the Form */}
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth >
              <Autocomplete
                multiple 
                options={jobLocations}
                disableCloseOnSelect
                getOptionLabel={(option) => option}
                value={formData.jobLocations || []}
                onChange={handleLocationsChange}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField {...params} label="Job Location" placeholder="Select Job Location" />
                )}
              />
              {/* <Autocomplete
                multiple
                options={skills}
                disableCloseOnSelect
                getOptionLabel={(option) => option}
                value={formData.skills || []}
                onChange={handleSkillsChange}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField {...params} label="Skills" placeholder="Select skills" />
                )}
              /> */}
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth >
              <TextField
                select
                label="Position Applied"
                name="positionApplied"
                value={formData.positionApplied}
                onChange={handleChange}
              >
                <MenuItem value="">Select a position</MenuItem>
                <MenuItem value="Plumber">Plumber</MenuItem>
                <MenuItem value="Electrician">Electrician</MenuItem>
                <MenuItem value="Manager">Manager</MenuItem>
                <MenuItem value="Helper">Helper</MenuItem>
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth >
              <Autocomplete
                multiple
                options={skills}
                disableCloseOnSelect
                getOptionLabel={(option) => option}
                value={formData.skills || []}
                onChange={handleSkillsChange}
                renderOption={(props, option, { selected }) => (
                  <li {...props}>
                    <Checkbox
                      style={{ marginRight: 8 }}
                      checked={selected}
                    />
                    {option}
                  </li>
                )}
                renderInput={(params) => (
                  <TextField {...params} label="Skills" placeholder="Select skills" />
                )}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth >
              <TextField
                select 
                label="Shift Type"
                name="shiftType"
                value={formData.shiftType}
                onChange={handleChange}
              >
                <MenuItem value="">Select shift type</MenuItem>
                <MenuItem value="Day">Day</MenuItem>
                <MenuItem value="Night">Night</MenuItem>
                <MenuItem value="Rotational">Rotational</MenuItem>
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth >
              <TextField
                select
                label="Workplace"
                name="workPlace"
                value={formData.workPlace}
                onChange={handleChange}
              >
                <MenuItem value="">Select workplace</MenuItem>
                <MenuItem value="On-site">On-site</MenuItem>
                <MenuItem value="Remote">Remote</MenuItem>
                <MenuItem value="Hybrid">Hybrid</MenuItem>
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth >
              <TextField
                select 
                label="Employment Type"
                name="employmentType"
                value={formData.employmentType}
                onChange={handleChange}
              >
                <MenuItem value="">Select employment type</MenuItem>
                <MenuItem value="Full-time">Full-time</MenuItem>
                <MenuItem value="Part-time">Part-time</MenuItem>
                <MenuItem value="Contract">Contract</MenuItem>
                <MenuItem value="Temporary">Temporary</MenuItem>
              </TextField>
            </FormControl>
          </Grid>
        </Grid>
        <br />

         {/* Work Experience Section */}
         <Container>
        <Grid container spacing={3}>
          <Grid item xs={12} md={4}>
            <FormControl component="fieldset" fullWidth>
              <Typography>Do you have work experience?</Typography>
              <RadioGroup style={{marginLeft:'71px'}}
                row
                name="hasWorkExperience"
                value={formData.hasWorkExperience ? 'yes' : 'no'}
                onChange={(e) => setFormData({ ...formData, hasWorkExperience: e.target.value === 'yes' })}
              >
                <FormControlLabel value="yes" control={<Radio />} label="Yes" />
                <FormControlLabel value="no" control={<Radio />} label="No" />
              </RadioGroup>
            </FormControl>
          </Grid>

          {formData.hasWorkExperience && (
            <>
              <Grid item xs={12} md={4}>
                <Box display="flex" alignItems="center" gap="16px" mb={2}>
                  <TextField
                    label="Years"
                    name="yearsOfExperience"
                    value={formData.yearsOfExperience}
                    onChange={handleChange}
                    type="number"
                    InputProps={{ inputProps: { min: 0 } }}
                    sx={{ width: '100px' }}
                  />
                  <span>Years</span>
                  <TextField
                    label="Months (Optional)"
                    name="monthsOfExperience"
                    value={formData.monthsOfExperience}
                    onChange={handleChange}
                    type="number"
                    InputProps={{ inputProps: { min: 0, max: 11 } }}
                    sx={{ width: '100px' }}
                  />
                  <span>Months</span>
                </Box>
                <br />
                <Typography variant="h5" gutterBottom>Employment History</Typography>
              </Grid>
              
              {/* Employment History Section */}
              <Grid container spacing={3} className="mb-4">
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="Company Name"
                    name="companyName"
                    value={formData.companyName}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="Job Role"
                    name="jobRole"
                    value={formData.jobRole}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="Reason for Leaving"
                    name="reasonForLeaving"
                    value={formData.reasonForLeaving}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="Start Date"
                    type="date"
                    name="startDate"
                    value={formData.startDate}
                    onChange={handleChange}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="End Date"
                    type="date"
                    name="endDate"
                    value={formData.endDate}
                    onChange={handleChange}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    label="Primary Duties"
                    name="duties"
                    value={formData.duties}
                    onChange={handleChange}
                  />
                </Grid>
              </Grid>
            </>
          )}
        </Grid>
        </Container>
        <br />

        <Typography variant="h5" gutterBottom>Reference</Typography>
        <Grid container spacing={3} className="mb-4">
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <TextField
                select
                label="How Did You Hear About Us?"
                name="heardAboutUs"
                value={formData.heardAboutUs}
                onChange={handleChange}
              >
                <MenuItem value="">Select an option</MenuItem>
                <MenuItem value="LinkedIn">LinkedIn</MenuItem>
                <MenuItem value="Indeed">Indeed</MenuItem>
                <MenuItem value="Company Website">Company Website</MenuItem>
                <MenuItem value="Referral">Referral</MenuItem>
              </TextField>
            </FormControl>
          </Grid>

          {formData.heardAboutUs === 'Referral' && (
            <>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Name"
                  name="referenceName"
                  value={formData.referenceName || ''}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Relationship"
                  name="relationship"
                  value={formData.relationship || ''}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Mobile Number"
                  name="referenceMobile"
                  value={formData.referenceMobile || ''}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Email"
                  name="referenceEmail"
                  value={formData.referenceEmail || ''}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Company"
                  name="referenceCompany"
                  value={formData.referenceCompany || ''}
                  onChange={handleChange}
                />
              </Grid>
            </>
          )}
        </Grid>
        <Typography variant="h5" gutterBottom>Upload Documents</Typography>


<Grid container spacing={3} className="mb-4">
<Grid item xs={12} md={3}>
    <TextField
      
      type="file"
      accept=".jpg"
      name="profilePicture"
      onChange={handleFileChange}
      helperText="Profile Picture (JPG, max 1MB)"
    />
  </Grid>
  <Grid item xs={12} md={3}>
    <TextField
      
      type="file"
      accept=".jpg"
      name="signature"
      onChange={handleFileChange}
      helperText="Signature (JPG, max 1MB)"
    />
  </Grid>
  <Grid item xs={12} md={3}>
    <TextField
      
      type="file"
      accept=".pdf"
      name="resume"
      onChange={handleFileChange}
      helperText="Resume (PDF, max 1MB)"
    />
  </Grid>
  <Grid item xs={12} md={3}>
    <TextField
      
      type="file"
      accept=".pdf"
      name="experienceLetter"
      onChange={handleFileChange}
      helperText="Experience Letter (PDF, max 1MB)"
    />
  </Grid>
</Grid>
      </Container>
    </>
  );
}

export default JobDetails;
