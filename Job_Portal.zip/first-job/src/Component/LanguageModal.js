import React, { useState, useEffect } from 'react';
import { Modal, Button, Form, Row, Col } from 'react-bootstrap';

const languages = ['Hindi', 'Italian', 'Marathi', 'French', 'German', 'Spanish', 'Japanese', 'Mandarin'];

function LanguageModal({ show, onHide, formData, setFormData }) {
  const [selectedLanguages, setSelectedLanguages] = useState(formData.languages || []);
  const [englishProficiency, setEnglishProficiency] = useState(formData.englishProficiency || '');

  useEffect(() => {
    setSelectedLanguages(formData.languages || []);
    setEnglishProficiency(formData.englishProficiency || '');
  }, [formData.preferredLanguage]);

  const handleLanguageChange = (language) => {
    setSelectedLanguages((prevSelected) =>
      prevSelected.includes(language)
        ? prevSelected.filter((lang) => lang !== language)
        : [...prevSelected, language]
    );
  };
  

  const handleSave = () => {
    console.log('Selected Languages:', selectedLanguages); // Check selected languages
    setFormData({
      ...formData,
      preferredLanguage: selectedLanguages,
      englishProficiency: englishProficiency,
    });
    onHide();
  };
  

  return (
    <Modal style={{ marginTop: '40px' }} show={show} onHide={onHide}>
      <Modal.Header closeButton>
        <Modal.Title>Preferred Language</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form>
          <Form.Group as={Row}>
            <Form.Label as="legend" column sm={12}>
              English
            </Form.Label>
            <Col sm={12}>
              <Form.Check
                type="radio"
                label="No English"
                name="englishProficiency"
                value="No English"
                checked={englishProficiency === 'No English'}
                onChange={(e) => setEnglishProficiency(e.target.value)}
              />
              <Form.Check
                type="radio"
                label="Basic"
                name="englishProficiency"
                value="Basic"
                checked={englishProficiency === 'Basic'}
                onChange={(e) => setEnglishProficiency(e.target.value)}
              />
              <Form.Check
                type="radio"
                label="Intermediate"
                name="englishProficiency"
                value="Intermediate"
                checked={englishProficiency === 'Intermediate'}
                onChange={(e) => setEnglishProficiency(e.target.value)}
              />
              <Form.Check
                type="radio"
                label="Advanced"
                name="englishProficiency"
                value="Advanced"
                checked={englishProficiency === 'Advanced'}
                onChange={(e) => setEnglishProficiency(e.target.value)}
              />
            </Col>
          </Form.Group>

          <hr />

          <Form.Group>
            <Form.Label>Add other languages you can speak (Optional)</Form.Label>
            <div className="language-buttons " style={{justifyContent:'center' ,alignItems:'center',textAlign :'center'}}>
              {languages.map((language) => (
                <Button
                  key={language}
                  variant={selectedLanguages.includes(language) ? 'primary' : 'outline-primary'}
                  onClick={() => handleLanguageChange(language)}
                  className="m-1" style={{height:'35px'}}
                >
                  {language}
                </Button>
              ))}
            </div>
          </Form.Group>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button style={{ height: '35px' }} variant="secondary" onClick={onHide}>
          Cancel
        </Button>
        <Button style={{ height: '35px' }} variant="primary" onClick={handleSave}>
          Save
        </Button>
      </Modal.Footer>
    </Modal>
  );
}

export default LanguageModal;
