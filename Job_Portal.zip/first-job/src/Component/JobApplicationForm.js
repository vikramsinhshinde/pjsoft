// import React, { useState } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import { Form, Button } from 'react-bootstrap';
// import PersonalInformation from './PersonalInformation';
// import JobDetails from './JobDetails';
// import '../CSS/JobApplicationForm.css';

// function JobApplicationForm() {
//   const [formData, setFormData] = useState({
// fullName: '',
// birthDate: '',
// gender: '',
// age: '',
// streetAddress: '',
// streetAddress2: '',
// state: '',
// postalCode: '',
// sameAsCurrent: false,
// permanentStreetAddress: '',
// permanentStreetAddress2: '',
// permanentState: '',
// permanentPostalCode: '',
// email: '',
// phoneNumber: '',
// preferredLanguage:'',
// jobLocation:'',
// linkedin: '',
// positionApplied: '',
// heardAboutUs: '',
// skill:'',
// shiftType:'',
// workPlace:'',
// employmentType:'',
// profilePicture: null,
// resume: null,
// companyName: '',
// jobRole: '',
// employmentStartDate: '',
// employmentEndDate: '',
// duties: '',
// reasonForLeaving: '',
// collegeName: '',
// degree: '',
// specialization: '',
// graduationMonth: '',
// graduationYear: '',
// referenceName: '',
// relationship: '',
// referenceMobile: '',
// referenceEmail: '',
// experienceLetter: null,
//   });

//   const [page, setPage] = useState(1);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleArrayChange = (e, index, field) => {
//     const { name, value } = e.target;
//     const updatedArray = formData[field].map((item, i) =>
//       i === index ? { ...item, [name]: value } : item
//     );
//     setFormData({
//       ...formData,
//       [field]: updatedArray,
//     });
//   };

//   const handleFileChange = (e) => {
//     const { name, files } = e.target;
//     setFormData({
//       ...formData,
//       [name]: files[0],
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log('Form submitted:', formData);
//     // Implement form submission logic
//   };

//   const calculateAge = (birthDate) => {
//     const today = new Date();
//     const birthDateObj = new Date(birthDate);
//     let age = today.getFullYear() - birthDateObj.getFullYear();
//     const monthDiff = today.getMonth() - birthDateObj.getMonth();
//     if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDateObj.getDate())) {
//       age--;
//     }
//     return age;
//   };

//   const handleBirthDateChange = (e) => {
//     const birthDate = e.target.value;
//     setFormData({
//       ...formData,
//       birthDate: birthDate,
//       age: calculateAge(birthDate),
//     });
//   };

//   const handleAddressCheckboxChange = (e) => {
//     const { checked } = e.target;
//     setFormData({
//       ...formData,
//       sameAsCurrent: checked,
//       permanentStreetAddress: checked ? formData.streetAddress : '',
//       permanentStreetAddress2: checked ? formData.streetAddress2 : '',
//       permanentState: checked ? formData.state : '',
//       permanentPostalCode: checked ? formData.postalCode : ''
//     });
//   };

//   const nextPage = () => setPage(page + 1);
//   const prevPage = () => setPage(page - 1);

//   return (
//     <div style={{ width: '1200px', borderRadius: '10px', backgroundColor: '#f8f9fa', marginLeft: '260px' }}>
//       <Form onSubmit={handleSubmit} className="mt-2">
//         <h2 className="title mb-4">Job Application Form</h2>
//         <hr />
//         {page === 1 && (
//           <>
//             <PersonalInformation
//               formData={formData}
//               handleChange={handleChange}
//               handleBirthDateChange={handleBirthDateChange}
//               handleAddressCheckboxChange={handleAddressCheckboxChange}
//             />
//             <div className="button">
//               <Button className='next' variant="primary" onClick={nextPage}>
//                 Next
//               </Button>
//             </div>
//           </>
//         )}
//         {page === 2 && (
//           <>
//             <JobDetails
//               formData={formData}
//               handleChange={handleChange}
//               handleArrayChange={handleArrayChange}
//               handleFileChange={handleFileChange}
//             />
//             <div className="previousbutton align-items-center">
//               <Button className='previous' variant="secondary" onClick={prevPage}>
//                 Previous
//               </Button>
//               <Button className='apply' variant="primary" type="submit">
//                 Apply
//               </Button>
//             </div>
//           </>
//         )}
//       </Form>
//     </div>
//   );
// }

// export default JobApplicationForm;

import React, { useState } from "react";
import { Container, Grid, Button, Typography, Paper } from "@mui/material";
import PersonalInformation from "./PersonalInformation";
import JobDetails from "./JobDetails";
import LanguageModal from "./LanguageModal";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function JobApplicationForm() {
  const [formData, setFormData] = useState({
    fullName: "",
    birthDate: "",
    gender: "",
    age: "",
    streetAddress: "",
    streetAddress2: "",
    city: "",
    state: "",
    postalCode: "",
    sameAsCurrent: false,
    permanentStreetAddress: "",
    permanentStreetAddress2: "",
    permanentCity: "",
    permanentState: "",
    permanentPostalCode: "",
    email: "",
    phoneNumber: "",
    aadharNo: "",
    preferredLanguage: [],
    jobLocation: "",
    linkedin: "",
    positionApplied: "",
    hasWorkExperience: false,
    yearsOfExperience: "",
    monthsOfExperience: "",
    heardAboutUs: "",
    skill: "",
    shiftType: "",
    workPlace: "",
    employmentType: "",
    profilePicture: null,
    signature: null,
    resume: null,
    companyName: "",
    jobRole: "",
    employmentStartDate: "",
    employmentEndDate: "",
    duties: "",
    reasonForLeaving: "",
    collegeName: "",
    degree: "",
    specialization: "",
    graduationMonth: "",
    graduationYear: "",
    referenceName: "",
    relationship: "",
    referenceMobile: "",
    referenceEmail: "",
    referenceCompany: "",
    experienceLetter: null,
  });

  const [page, setPage] = useState(1);
  const [showLanguageModal, setShowLanguageModal] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleArrayChange = (e, index, field) => {
    const { name, value } = e.target;
    const updatedArray = formData[field].map((item, i) =>
      i === index ? { ...item, [name]: value } : item
    );
    setFormData({
      ...formData,
      [field]: updatedArray,
    });
  };

  const handleFileChange = (e) => {
    const { name, files } = e.target;
    setFormData({
      ...formData,
      [name]: files[0],
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted:", formData);
    toast.success("Your application has been submitted successfully!");
    console.log("Form Data:", formData); // Check if preferredLanguage is updated
  };

  const calculateAge = (birthDate) => {
    const today = new Date();
    const birthDateObj = new Date(birthDate);
    let age = today.getFullYear() - birthDateObj.getFullYear();
    const monthDiff = today.getMonth() - birthDateObj.getMonth();
    if (
      monthDiff < 0 ||
      (monthDiff === 0 && today.getDate() < birthDateObj.getDate())
    ) {
      age--;
    }
    return age;
  };

  const handleBirthDateChange = (e) => {
    const birthDate = e.target.value;
    setFormData({
      ...formData,
      birthDate: birthDate,
      age: calculateAge(birthDate),
    });
  };

  const handleAddressCheckboxChange = (e) => {
    const { checked } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      sameAsCurrent: checked,
      permanentStreetAddress: checked
        ? prevData.streetAddress
        : prevData.permanentStreetAddress,
      permanentStreetAddress2: checked
        ? prevData.streetAddress2
        : prevData.permanentStreetAddress2,
      permanentCity: checked ? prevData.city : prevData.permanentCity,
      permanentState: checked ? prevData.state : prevData.permanentState,
      permanentPostalCode: checked
        ? prevData.postalCode
        : prevData.permanentPostalCode,
    }));
  };
  const handleLanguageChange = (updatedLanguages) => {
    setFormData({
      ...formData,
      preferredLanguage: updatedLanguages,
    });
  };

  const nextPage = () => setPage(page + 1);
  const prevPage = () => setPage(page - 1);

  return (
    <Paper
      sx={{
        padding: "20px",
        marginTop: "80px",
        maxWidth: "1100px",
        width: "100%",
        marginLeft: "330px",
        marginBottom: "20px",
        boxShadow: 3,
      }}
    >
      <Container>
        <form onSubmit={handleSubmit}>
          <Typography variant="h4" gutterBottom>
            Job Application Form
          </Typography>
          <hr />
          <Grid container spacing={3}>
            {page === 1 && (
              <>
                <PersonalInformation
                  formData={formData}
                  handleChange={handleChange}
                  handleBirthDateChange={handleBirthDateChange}
                  handleAddressCheckboxChange={handleAddressCheckboxChange}
                  setShowLanguageModal={setShowLanguageModal}
                />
                <Grid item xs={12} sx={{ textAlign: "center" }}>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={nextPage}
                  >
                    Next
                  </Button>
                </Grid>
              </>
            )}
            {page === 2 && (
              <>
                <JobDetails
                  formData={formData}
                  setFormData={setFormData}
                  handleChange={handleChange}
                  handleArrayChange={handleArrayChange}
                  handleFileChange={handleFileChange}
                />
                <Grid item xs={12} sx={{ textAlign: "center" }}>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={prevPage}
                    style={{ marginRight: "20px" }}
                  >
                    Previous
                  </Button>
                  <Button variant="contained" color="primary" type="submit">
                    Apply
                  </Button>
                </Grid>
              </>
            )}
          </Grid>
        </form>
        <ToastContainer />
        <LanguageModal
          show={showLanguageModal}
          onHide={() => setShowLanguageModal(false)}
          formData={formData}
          setFormData={(updatedData) => setFormData(updatedData)}
        />
      </Container>
    </Paper>
  );
}

export default JobApplicationForm;
