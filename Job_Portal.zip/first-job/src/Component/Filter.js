import React from 'react';
import { Col, Form, Button, OverlayTrigger, Tooltip } from 'react-bootstrap';

const Filter = ({
  searchText,
  setSearchText,
  jobTypes,
  setJobTypes,
  radius,
  setRadius,
  salaryRange,
  setSalaryRange,
  handleSearchChange,
  handleJobTypeChange,
  handleRadiusChange,
  handleSalaryChange
}) => (
  <Col md={12}>
    <div className="right-section">
      <h4>Keywords</h4>
      <Form.Control
        type="text"
        placeholder="Job Keywords..."
        value={searchText}
        onChange={handleSearchChange}
      />
      <h4 className="mt-4">Search By Radius</h4>
      <OverlayTrigger
        placement="top"
        overlay={<Tooltip>{radius}</Tooltip>}
      >
        <Form.Range className="custom-range" value={radius} onChange={handleRadiusChange} />
      </OverlayTrigger>
      <h4 className="mt-4">Job Type</h4>
      <Form.Check
        type="checkbox"
        label="Freelance"
        name="freelance"
        checked={jobTypes.freelance}
        onChange={handleJobTypeChange}
        className="custom-checkbox"
      />
      <Form.Check
        type="checkbox"
        label="Full Time"
        name="fullTime"
        checked={jobTypes.fullTime}
        onChange={handleJobTypeChange}
        className="custom-checkbox"
      />
      <Form.Check
        type="checkbox"
        label="Part Time"
        name="partTime"
        checked={jobTypes.partTime}
        onChange={handleJobTypeChange}
        className="custom-checkbox"
      />
      <Form.Check
        type="checkbox"
        label="Internship"
        name="internship"
        checked={jobTypes.internship}
        onChange={handleJobTypeChange}
        className="custom-checkbox"
      />
      <h4 className="mt-4">Categories</h4>
      <Form.Control as="select">
        <option>All category</option>
        <option>Health Care</option>
        <option>Management</option>
        <option>UI/UX Developer</option>
        <option>Graphic Designer</option>
      </Form.Control>
      <h4 className="mt-4">Filter By Salary</h4>
      <div className="d-flex justify-content-between">
        <span>${salaryRange[0]}</span>
        <span>${salaryRange[1]}</span>
      </div>
      <Form.Range
        value={salaryRange[0]}
        onChange={(e) => handleSalaryChange(0, Number(e.target.value))}
        min={0}
        max={20000}
        step={100}
        className="salary-range-slider custom-range"
      />
      <Form.Range
        value={salaryRange[1]}
        onChange={(e) => handleSalaryChange(1, Number(e.target.value))}
        min={0}
        max={20000}
        step={100}
        className="salary-range-slider custom-range"
      />
      <h4 className="mt-4">Filter By Tag:</h4>
      <div className="d-flex flex-wrap">
        {['Development', 'UI/UX', 'Devops', 'Design', 'Mobile App', 'Programming', 'HTML', 'C++'].map((tag, index) => (
          <Button key={index} variant="light" size="sm" className="me-2 mb-2 custom-tag">
            {tag}
          </Button>
        ))}
      </div>
    </div>
  </Col>
);

export default Filter;
