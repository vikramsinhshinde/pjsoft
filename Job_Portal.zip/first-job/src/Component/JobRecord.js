// import React, { useState } from 'react';
// import {
//   Box,
//   TextField,
//   Button,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   Paper,
//   Modal,
//   Typography,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
//   Grid,
// } from '@mui/material';

// function JobRecord() {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [showModal, setShowModal] = useState(false);
//   const [positionFilter, setPositionFilter] = useState('');
//   const [jobRecords, setJobRecords] = useState([
//     // Static data for job records
//     {
//       fullName: 'John',
//       middleName: 'A',
//       lastName: 'Doe',
//       birthDate: '1990-01-01',
//       streetAddress: '123 Main St',
//       streetAddress2: '',
//       state: 'California',
//       postalCode: '90001',
//       email: 'john.doe@example.com',
//       phoneNumber: '123-456-7890',
//       linkedin: 'https://linkedin.com/in/johndoe',
//       positionApplied: 'Developer',
//       heardAboutUs: 'LinkedIn',
//       startDate: '2024-08-01',
//       resume: null,
//       coverLetter: '',
//     },
//     // Add more static data entries as needed
//   ]);

//   const [editingIndex, setEditingIndex] = useState(null);
//   const [formData, setFormData] = useState({
//     fullName: '',
//     middleName: '',
//     lastName: '',
//     birthDate: '',
//     streetAddress: '',
//     streetAddress2: '',
//     state: '',
//     postalCode: '',
//     email: '',
//     phoneNumber: '',
//     linkedin: '',
//     positionApplied: '',
//     heardAboutUs: '',
//     startDate: '',
//     resume: null,
//     companyName: '',
//     jobTitle: '',
//     jobStartDate: '',
//     jobEndDate: '',
//     jobDuties: '',
//     reasonForLeaving: '',
//     schoolName: '',
//     degree: '',
//     major: '',
//     graduationDate: '',
//     referenceName: '',
//     referenceRelationship: '',
//     mobile: '',
//     referenceEmail: '',
//   });

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (editingIndex !== null) {
//       const updatedRecords = jobRecords.map((record, index) =>
//         index === editingIndex ? formData : record
//       );
//       setJobRecords(updatedRecords);
//       setEditingIndex(null);
//     } else {
//       setJobRecords([...jobRecords, formData]);
//     }
//     setShowModal(false);
//     setFormData({
//       fullName: '',
//       middleName: '',
//       lastName: '',
//       birthDate: '',
//       streetAddress: '',
//       streetAddress2: '',
//       state: '',
//       postalCode: '',
//       email: '',
//       phoneNumber: '',
//       linkedin: '',
//       positionApplied: '',
//       heardAboutUs: '',
//       startDate: '',
//       resume: null,
//       companyName: '',
//       jobTitle: '',
//       jobStartDate: '',
//       jobEndDate: '',
//       jobDuties: '',
//       reasonForLeaving: '',
//       schoolName: '',
//       degree: '',
//       major: '',
//       graduationDate: '',
//       referenceName: '',
//       referenceRelationship: '',
//       mobile: '',
//       referenceEmail: '',
//     });
//   };

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData({
//       ...formData,
//       [name]: value,
//     });
//   };

//   const handleFileChange = (e) => {
//     const { name, files } = e.target;
//     setFormData({
//       ...formData,
//       [name]: files[0],
//     });
//   };

//   const handleSearchChange = (e) => {
//     setSearchTerm(e.target.value);
//   };

//   const handlePositionFilterChange = (e) => {
//     setPositionFilter(e.target.value);
//   };

//   const handleDelete = (index) => {
//     const updatedRecords = jobRecords.filter((_, i) => i !== index);
//     setJobRecords(updatedRecords);
//   };

//   const handleEdit = (index) => {
//     setEditingIndex(index);
//     setFormData(jobRecords[index]);
//     setShowModal(true); 
//   };

//   const filteredRecords = jobRecords.filter((record) => {
//     const matchesSearch = Object.values(record).some((value) =>
//       value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
//     );
//     const matchesPosition = positionFilter
//       ? record.positionApplied.toLowerCase() === positionFilter.toLowerCase()
//       : true;
//     return matchesSearch && matchesPosition;
//   });

//   return (
//     <Box sx={{ mt: 4, ml: 16, backgroundColor: '#fff', p: 4 }}>
//       <Typography variant="h4" gutterBottom>
//         Job Records
//       </Typography>
//       <hr />
//       <Grid container spacing={2} sx={{ mb: 3 }}>
//         <Grid item xs={12} sm={6} md={4}>
//           <TextField
//             fullWidth
//             label="Search job records"
//             value={searchTerm}
//             onChange={handleSearchChange}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <FormControl fullWidth>
//             <InputLabel>Position</InputLabel>
//             <Select
//               value={positionFilter}
//               onChange={handlePositionFilterChange}
//             >
//               <MenuItem value="">All Positions</MenuItem>
//               {[...new Set(jobRecords.map(record => record.positionApplied))].map((position, index) => (
//                 <MenuItem key={index} value={position}>{position}</MenuItem>
//               ))}
//             </Select>
//           </FormControl>
//         </Grid>
//       </Grid>

//       <TableContainer component={Paper}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Sr. No.</TableCell>
//               <TableCell>Full Name</TableCell>
//               <TableCell>Email</TableCell>
//               <TableCell>Phone Number</TableCell>
//               <TableCell>Position Applied</TableCell>
//               <TableCell>Last Name</TableCell>
//               <TableCell>Start Date</TableCell>
//               <TableCell>Actions</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {filteredRecords.map((record, index) => (
//               <TableRow key={index}>
//                 <TableCell>{index + 1}</TableCell>
//                 <TableCell>{record.fullName}</TableCell>
//                 <TableCell>{record.email}</TableCell>
//                 <TableCell>{record.phoneNumber}</TableCell>
//                 <TableCell>{record.positionApplied}</TableCell>
//                 <TableCell>{record.lastName}</TableCell>
//                 <TableCell>{record.startDate}</TableCell>
//                 <TableCell>
//                   <Button
//                     variant="contained"
//                     color="primary"
//                     size="small"
//                     onClick={() => handleEdit(index)}
//                   >
//                     Edit
//                   </Button>{' '}
//                   <Button
//                     variant="contained"
//                     color="error"
//                     size="small"
//                     onClick={() => handleDelete(index)}
//                   >
//                     Delete
//                   </Button>
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>

//       <Modal
//         open={showModal}
//         onClose={() => setShowModal(false)}
//         aria-labelledby="modal-title"
//         aria-describedby="modal-description"
//       >
//         <Box
//           sx={{
//             position: 'absolute',
//             top: '50%',
//             left: '50%',
//             transform: 'translate(-50%, -50%)',
//             width: 400,
//             bgcolor: 'background.paper',
//             boxShadow: 24,
//             p: 4,
//             borderRadius: 2,
//           }}
//         >
//           <Typography variant="h6" id="modal-title">
//             {editingIndex !== null ? 'Edit Job Record' : 'Add Job Record'}
//           </Typography>
//           <Box
//             component="form"
//             onSubmit={handleSubmit}
//             sx={{ mt: 2 }}
//           >
//             <Grid container spacing={2}>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="First Name"
//                   name="fullName"
//                   value={formData.fullName}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Middle Name"
//                   name="middleName"
//                   value={formData.middleName}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Last Name"
//                   name="lastName"
//                   value={formData.lastName}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Birth Date"
//                   type="date"
//                   name="birthDate"
//                   value={formData.birthDate}
//                   onChange={handleChange}
//                   InputLabelProps={{ shrink: true }}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Street Address"
//                   name="streetAddress"
//                   value={formData.streetAddress}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Street Address 2"
//                   name="streetAddress2"
//                   value={formData.streetAddress2}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="State"
//                   name="state"
//                   value={formData.state}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Postal Code"
//                   name="postalCode"
//                   value={formData.postalCode}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Email"
//                   name="email"
//                   type="email"
//                   value={formData.email}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Phone Number"
//                   name="phoneNumber"
//                   value={formData.phoneNumber}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="LinkedIn"
//                   name="linkedin"
//                   value={formData.linkedin}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Position Applied"
//                   name="positionApplied"
//                   value={formData.positionApplied}
//                   onChange={handleChange}
//                   required
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Heard About Us From"
//                   name="heardAboutUs"
//                   value={formData.heardAboutUs}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={6}>
//                 <TextField
//                   fullWidth
//                   label="Start Date"
//                   type="date"
//                   name="startDate"
//                   value={formData.startDate}
//                   onChange={handleChange}
//                   InputLabelProps={{ shrink: true }}
//                 />
//               </Grid>
//               <Grid item xs={12}>
//                 <Button
//                   variant="contained"
//                   component="label"
//                 >
//                   Upload Resume
//                   <input
//                     type="file"
//                     hidden
//                     name="resume"
//                     onChange={handleFileChange}
//                   />
//                 </Button>
//               </Grid>
//             </Grid>
//             <Button
//               type="submit"
//               variant="contained"
//               color="primary"
//               sx={{ mt: 3 }}
//             >
//               {editingIndex !== null ? 'Update Record' : 'Add Record'}
//             </Button>
//           </Box>
//         </Box>
//       </Modal>
//     </Box>
//   );
// }

// export default JobRecord;

// import React, { useState } from 'react';
// import { Box, Typography, Grid, TextField, FormControl, MenuItem, Modal } from '@mui/material';
// import JobTable from './JobTable';
// import JobEditForm from './JobEditForm';

// function JobRecord() {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [showModal, setShowModal] = useState(false);
//   const [positionFilter, setPositionFilter] = useState('');
//   const [skillFilter, setSkillFilter] = useState('');
//   const [jobRecords, setJobRecords] = useState([
//     // Add more static data entries here
  //   {
  //     fullName: 'John Doe',
  //     birthDate: '1990-01-01',
  //     gender: 'Male',
  //     age: '34',
  //     streetAddress: '123 Main St',
  //     streetAddress2: '',
  //     state: 'California',
  //     postalCode: '90001',
  //     permanentStreetAddress: '456 Secondary St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'California',
  //     permanentPostalCode: '90002',
  //     email: 'john.doe@example.com',
  //     phoneNumber: '123-456-7890',
  //     preferredLanguage: 'English',
  //     jobLocation: 'San Francisco',
  //     linkedin: 'https://linkedin.com/in/johndoe',
  //     positionApplied: 'Developer',
  //     heardAboutUs: 'LinkedIn',
  //     skill: 'JavaScript',
  //     shiftType: 'Full-time',
  //     workPlace: 'Office',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Tech Co',
  //     jobRole: 'Developer',
  //     employmentStartDate: '2015-06-01',
  //     employmentEndDate: '2020-08-01',
  //     duties: 'Developing applications',
  //     reasonForLeaving: 'Career growth',
  //     collegeName: 'State University',
  //     degree: 'BSc Computer Science',
  //     specialization: 'Software Engineering',
  //     graduationMonth: 'May',
  //     graduationYear: '2014',
  //     referenceName: 'Jane Smith',
  //     relationship: 'Former Manager',
  //     referenceMobile: '987-654-3210',
  //     referenceEmail: 'jane.smith@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Jane Roe',
  //     birthDate: '1985-03-12',
  //     gender: 'Female',
  //     age: '39',
  //     streetAddress: '789 Maple Ave',
  //     streetAddress2: 'Apt 4B',
  //     state: 'New York',
  //     postalCode: '10001',
  //     permanentStreetAddress: '101 Oak St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'New York',
  //     permanentPostalCode: '10002',
  //     email: 'jane.roe@example.com',
  //     phoneNumber: '234-567-8901',
  //     preferredLanguage: 'English',
  //     jobLocation: 'New York City',
  //     linkedin: 'https://linkedin.com/in/janeroe',
  //     positionApplied: 'Project Manager',
  //     heardAboutUs: 'Indeed',
  //     skill: 'Project Management',
  //     shiftType: 'Part-time',
  //     workPlace: 'Remote',
  //     employmentType: 'Contract',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Business Inc.',
  //     jobRole: 'Project Manager',
  //     employmentStartDate: '2016-09-15',
  //     employmentEndDate: '2021-03-10',
  //     duties: 'Managing projects and teams',
  //     reasonForLeaving: 'Contract ended',
  //     collegeName: 'City College',
  //     degree: 'MBA',
  //     specialization: 'Management',
  //     graduationMonth: 'June',
  //     graduationYear: '2010',
  //     referenceName: 'John Smith',
  //     relationship: 'Former Colleague',
  //     referenceMobile: '876-543-2109',
  //     referenceEmail: 'john.smith@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Alice Johnson',
  //     birthDate: '1992-08-25',
  //     gender: 'Female',
  //     age: '31',
  //     streetAddress: '456 Elm St',
  //     streetAddress2: '',
  //     state: 'Texas',
  //     postalCode: '75001',
  //     permanentStreetAddress: '789 Pine St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Texas',
  //     permanentPostalCode: '75002',
  //     email: 'alice.johnson@example.com',
  //     phoneNumber: '345-678-9012',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Dallas',
  //     linkedin: 'https://linkedin.com/in/alicejohnson',
  //     positionApplied: 'Data Analyst',
  //     heardAboutUs: 'Referral',
  //     skill: 'Data Analysis',
  //     shiftType: 'Full-time',
  //     workPlace: 'Hybrid',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Data Corp',
  //     jobRole: 'Data Analyst',
  //     employmentStartDate: '2017-11-20',
  //     employmentEndDate: '2022-02-28',
  //     duties: 'Analyzing data sets and generating reports',
  //     reasonForLeaving: 'Personal reasons',
  //     collegeName: 'Tech University',
  //     degree: 'MS Data Science',
  //     specialization: 'Data Analytics',
  //     graduationMonth: 'August',
  //     graduationYear: '2015',
  //     referenceName: 'Tom Baker',
  //     relationship: 'Former Supervisor',
  //     referenceMobile: '765-432-1098',
  //     referenceEmail: 'tom.baker@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Bob Williams',
  //     birthDate: '1988-11-15',
  //     gender: 'Male',
  //     age: '35',
  //     streetAddress: '123 Birch St',
  //     streetAddress2: 'Suite 5',
  //     state: 'Florida',
  //     postalCode: '33101',
  //     permanentStreetAddress: '456 Cedar St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Florida',
  //     permanentPostalCode: '33102',
  //     email: 'bob.williams@example.com',
  //     phoneNumber: '456-789-0123',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Miami',
  //     linkedin: 'https://linkedin.com/in/bobwilliams',
  //     positionApplied: 'Software Engineer',
  //     heardAboutUs: 'Glassdoor',
  //     skill: 'Python',
  //     shiftType: 'Full-time',
  //     workPlace: 'Office',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Software Solutions',
  //     jobRole: 'Software Engineer',
  //     employmentStartDate: '2014-04-01',
  //     employmentEndDate: '2021-09-30',
  //     duties: 'Developing software solutions',
  //     reasonForLeaving: 'Company restructuring',
  //     collegeName: 'University of Florida',
  //     degree: 'BSc Computer Engineering',
  //     specialization: 'Software Development',
  //     graduationMonth: 'December',
  //     graduationYear: '2013',
  //     referenceName: 'Sara White',
  //     relationship: 'Former Team Lead',
  //     referenceMobile: '654-321-0987',
  //     referenceEmail: 'sara.white@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Charlie Brown',
  //     birthDate: '1995-05-10',
  //     gender: 'Male',
  //     age: '29',
  //     streetAddress: '789 Oak St',
  //     streetAddress2: '',
  //     state: 'Illinois',
  //     postalCode: '60601',
  //     permanentStreetAddress: '101 Pine St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Illinois',
  //     permanentPostalCode: '60602',
  //     email: 'charlie.brown@example.com',
  //     phoneNumber: '567-890-1234',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Chicago',
  //     linkedin: 'https://linkedin.com/in/charliebrown',
  //     positionApplied: 'UX Designer',
  //     heardAboutUs: 'Company Website',
  //     skill: 'UI/UX Design',
  //     shiftType: 'Part-time',
  //     workPlace: 'Remote',
  //     employmentType: 'Contract',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Creative Agency',
  //     jobRole: 'UX Designer',
  //     employmentStartDate: '2018-07-01',
  //     employmentEndDate: '2023-05-31',
  //     duties: 'Designing user interfaces and experiences',
  //     reasonForLeaving: 'Seeking new challenges',
  //     collegeName: 'Art Institute',
  //     degree: 'BA Graphic Design',
  //     specialization: 'User Experience',
  //     graduationMonth: 'April',
  //     graduationYear: '2017',
  //     referenceName: 'Lisa Green',
  //     relationship: 'Former Art Director',
  //     referenceMobile: '543-210-9876',
  //     referenceEmail: 'lisa.green@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Diana Prince',
  //     birthDate: '1991-12-25',
  //     gender: 'Female',
  //     age: '32',
  //     streetAddress: '456 Cedar St',
  //     streetAddress2: 'Apt 2C',
  //     state: 'Washington',
  //     postalCode: '98101',
  //     permanentStreetAddress: '789 Elm St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Washington',
  //     permanentPostalCode: '98102',
  //     email: 'diana.prince@example.com',
  //     phoneNumber: '678-901-2345',
  //     preferredLanguage: 'French',
  //     jobLocation: 'Seattle',
  //     linkedin: 'https://linkedin.com/in/dianaprince',
  //     positionApplied: 'Marketing Specialist',
  //     heardAboutUs: 'LinkedIn',
  //     skill: 'Digital Marketing',
  //     shiftType: 'Full-time',
  //     workPlace: 'Hybrid',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Marketing Pro',
  //     jobRole: 'Marketing Specialist',
  //     employmentStartDate: '2013-10-01',
  //     employmentEndDate: '2020-11-30',
  //     duties: 'Managing digital marketing campaigns',
  //     reasonForLeaving: 'Relocation',
  //     collegeName: 'Business School',
  //     degree: 'BBA Marketing',
  //     specialization: 'Digital Marketing',
  //     graduationMonth: 'July',
  //     graduationYear: '2012',
  //     referenceName: 'Bruce Wayne',
  //     relationship: 'Former Director',
  //     referenceMobile: '432-109-8765',
  //     referenceEmail: 'bruce.wayne@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Eve Adams',
  //     birthDate: '1987-07-20',
  //     gender: 'Female',
  //     age: '37',
  //     streetAddress: '123 Spruce St',
  //     streetAddress2: '',
  //     state: 'Oregon',
  //     postalCode: '97001',
  //     permanentStreetAddress: '456 Willow St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Oregon',
  //     permanentPostalCode: '97002',
  //     email: 'eve.adams@example.com',
  //     phoneNumber: '789-012-3456',
  //     preferredLanguage: 'German',
  //     jobLocation: 'Portland',
  //     linkedin: 'https://linkedin.com/in/veadams',
  //     positionApplied: 'Operations Manager',
  //     heardAboutUs: 'Career Fair',
  //     skill: 'Operations Management',
  //     shiftType: 'Full-time',
  //     workPlace: 'Office',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Logistics Co',
  //     jobRole: 'Operations Manager',
  //     employmentStartDate: '2012-01-15',
  //     employmentEndDate: '2018-09-15',
  //     duties: 'Overseeing daily operations',
  //     reasonForLeaving: 'Pursuing new opportunities',
  //     collegeName: 'State University',
  //     degree: 'MBA',
  //     specialization: 'Operations',
  //     graduationMonth: 'June',
  //     graduationYear: '2011',
  //     referenceName: 'Clark Kent',
  //     relationship: 'Former Boss',
  //     referenceMobile: '321-098-7654',
  //     referenceEmail: 'clark.kent@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Frank Castle',
  //     birthDate: '1993-02-18',
  //     gender: 'Male',
  //     age: '31',
  //     streetAddress: '789 Ash St',
  //     streetAddress2: '',
  //     state: 'Virginia',
  //     postalCode: '22001',
  //     permanentStreetAddress: '101 Elm St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Virginia',
  //     permanentPostalCode: '22002',
  //     email: 'frank.castle@example.com',
  //     phoneNumber: '890-123-4567',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Richmond',
  //     linkedin: 'https://linkedin.com/in/frankcastle',
  //     positionApplied: 'Network Engineer',
  //     heardAboutUs: 'Referral',
  //     skill: 'Networking',
  //     shiftType: 'Full-time',
  //     workPlace: 'Remote',
  //     employmentType: 'Contract',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Net Solutions',
  //     jobRole: 'Network Engineer',
  //     employmentStartDate: '2016-02-01',
  //     employmentEndDate: '2021-06-30',
  //     duties: 'Managing network infrastructure',
  //     reasonForLeaving: 'Freelancing',
  //     collegeName: 'Tech Institute',
  //     degree: 'BSc Networking',
  //     specialization: 'Network Security',
  //     graduationMonth: 'November',
  //     graduationYear: '2015',
  //     referenceName: 'Matt Murdock',
  //     relationship: 'Former Client',
  //     referenceMobile: '210-987-6543',
  //     referenceEmail: 'matt.murdock@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Grace Lee',
  //     birthDate: '1994-04-05',
  //     gender: 'Female',
  //     age: '30',
  //     streetAddress: '456 Redwood St',
  //     streetAddress2: '',
  //     state: 'Colorado',
  //     postalCode: '80201',
  //     permanentStreetAddress: '789 Maple St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Colorado',
  //     permanentPostalCode: '80202',
  //     email: 'grace.lee@example.com',
  //     phoneNumber: '901-234-5678',
  //     preferredLanguage: 'Mandarin',
  //     jobLocation: 'Denver',
  //     linkedin: 'https://linkedin.com/in/gracelee',
  //     positionApplied: 'HR Manager',
  //     heardAboutUs: 'Job Fair',
  //     skill: 'Human Resources',
  //     shiftType: 'Full-time',
  //     workPlace: 'Office',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'HR Solutions',
  //     jobRole: 'HR Manager',
  //     employmentStartDate: '2017-05-10',
  //     employmentEndDate: '2022-03-15',
  //     duties: 'Managing HR processes',
  //     reasonForLeaving: 'Company downsizing',
  //     collegeName: 'Business College',
  //     degree: 'BBA Human Resources',
  //     specialization: 'HR Management',
  //     graduationMonth: 'October',
  //     graduationYear: '2016',
  //     referenceName: 'Peter Parker',
  //     relationship: 'Former HR Director',
  //     referenceMobile: '109-876-5432',
  //     referenceEmail: 'peter.parker@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Hank Pym',
  //     birthDate: '1989-09-30',
  //     gender: 'Male',
  //     age: '34',
  //     streetAddress: '123 Cedar St',
  //     streetAddress2: '',
  //     state: 'Arizona',
  //     postalCode: '85001',
  //     permanentStreetAddress: '456 Oak St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Arizona',
  //     permanentPostalCode: '85002',
  //     email: 'hank.pym@example.com',
  //     phoneNumber: '012-345-6789',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Phoenix',
  //     linkedin: 'https://linkedin.com/in/hankpym',
  //     positionApplied: 'Research Scientist',
  //     heardAboutUs: 'University Career Center',
  //     skill: 'Biotechnology',
  //     shiftType: 'Full-time',
  //     workPlace: 'Office',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'BioTech Corp',
  //     jobRole: 'Research Scientist',
  //     employmentStartDate: '2012-07-01',
  //     employmentEndDate: '2020-11-30',
  //     duties: 'Conducting biotech research',
  //     reasonForLeaving: 'Career change',
  //     collegeName: 'Tech University',
  //     degree: 'PhD Biotechnology',
  //     specialization: 'Molecular Biology',
  //     graduationMonth: 'May',
  //     graduationYear: '2011',
  //     referenceName: 'Scott Lang',
  //     relationship: 'Former Colleague',
  //     referenceMobile: '098-765-4321',
  //     referenceEmail: 'scott.lang@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Ivy Carter',
  //     birthDate: '1996-06-15',
  //     gender: 'Female',
  //     age: '28',
  //     streetAddress: '789 Pine St',
  //     streetAddress2: '',
  //     state: 'Georgia',
  //     postalCode: '30301',
  //     permanentStreetAddress: '101 Oak St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Georgia',
  //     permanentPostalCode: '30302',
  //     email: 'ivy.carter@example.com',
  //     phoneNumber: '123-456-7890',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Atlanta',
  //     linkedin: 'https://linkedin.com/in/ivycarter',
  //     positionApplied: 'Graphic Designer',
  //     heardAboutUs: 'Social Media',
  //     skill: 'Graphic Design',
  //     shiftType: 'Part-time',
  //     workPlace: 'Remote',
  //     employmentType: 'Contract',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Design Studio',
  //     jobRole: 'Graphic Designer',
  //     employmentStartDate: '2019-02-01',
  //     employmentEndDate: '2023-01-31',
  //     duties: 'Creating visual content',
  //     reasonForLeaving: 'Seeking full-time role',
  //     collegeName: 'Art Institute',
  //     degree: 'BA Graphic Design',
  //     specialization: 'Visual Communication',
  //     graduationMonth: 'June',
  //     graduationYear: '2018',
  //     referenceName: 'Selina Kyle',
  //     relationship: 'Former Art Director',
  //     referenceMobile: '432-109-8765',
  //     referenceEmail: 'selina.kyle@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Jack Harper',
  //     birthDate: '1991-11-22',
  //     gender: 'Male',
  //     age: '32',
  //     streetAddress: '123 Birch St',
  //     streetAddress2: '',
  //     state: 'Nevada',
  //     postalCode: '89001',
  //     permanentStreetAddress: '456 Redwood St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Nevada',
  //     permanentPostalCode: '89002',
  //     email: 'jack.harper@example.com',
  //     phoneNumber: '234-567-8901',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Las Vegas',
  //     linkedin: 'https://linkedin.com/in/jackharper',
  //     positionApplied: 'Cybersecurity Analyst',
  //     heardAboutUs: 'Company Website',
  //     skill: 'Cybersecurity',
  //     shiftType: 'Full-time',
  //     workPlace: 'Hybrid',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Security Inc',
  //     jobRole: 'Cybersecurity Analyst',
  //     employmentStartDate: '2014-09-01',
  //     employmentEndDate: '2023-07-31',
  //     duties: 'Implementing security measures',
  //     reasonForLeaving: 'Relocating',
  //     collegeName: 'Tech University',
  //     degree: 'BSc Computer Science',
  //     specialization: 'Cybersecurity',
  //     graduationMonth: 'July',
  //     graduationYear: '2013',
  //     referenceName: 'John Constantine',
  //     relationship: 'Former Manager',
  //     referenceMobile: '543-210-9876',
  //     referenceEmail: 'john.constantine@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Kara Danvers',
  //     birthDate: '1992-12-18',
  //     gender: 'Female',
  //     age: '31',
  //     streetAddress: '456 Elm St',
  //     streetAddress2: '',
  //     state: 'Missouri',
  //     postalCode: '63001',
  //     permanentStreetAddress: '789 Cedar St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'Missouri',
  //     permanentPostalCode: '63002',
  //     email: 'kara.danvers@example.com',
  //     phoneNumber: '345-678-9012',
  //     preferredLanguage: 'English',
  //     jobLocation: 'Kansas City',
  //     linkedin: 'https://linkedin.com/in/karadanvers',
  //     positionApplied: 'Software Developer',
  //     heardAboutUs: 'Referral',
  //     skill: 'Software Development',
  //     shiftType: 'Full-time',
  //     workPlace: 'Office',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     companyName: 'Tech Solutions',
  //     jobRole: 'Software Developer',
  //     employmentStartDate: '2017-06-01',
  //     employmentEndDate: '2023-06-30',
  //     duties: 'Developing web applications',
  //     reasonForLeaving: 'Career advancement',
  //     collegeName: 'State University',
  //     degree: 'MSc Computer Science',
  //     specialization: 'Software Engineering',
  //     graduationMonth: 'August',
  //     graduationYear: '2016',
  //     referenceName: 'James Olsen',
  //     relationship: 'Former Team Lead',
  //     referenceMobile: '654-321-0987',
  //     referenceEmail: 'james.olsen@example.com',
  //     experienceLetter: null,
  //   },
  //   {
  //     fullName: 'Luke Cage',
  //     birthDate: '1988-10-15',
  //     startDate:'2012-10-15',
  //     endDate:'2025-11-25',
  //     gender: 'Male',
  //     age: '35',
  //     streetAddress: '789 Willow St',
  //     streetAddress2: '',
  //     state: 'New York',
  //     postalCode: '10001',
  //     permanentStreetAddress: '101 Ash St',
  //     permanentStreetAddress2: '',
  //     permanentState: 'New York',
  //     permanentPostalCode: '10002',
  //     email: 'luke.cage@example.com',
  //     phoneNumber: '456-789-0123',
  //     preferredLanguage: 'English',
  //     jobLocation: 'New York City',
  //     linkedin: 'https://linkedin.com/in/lukecage',
  //     positionApplied: 'Construction Manager',
  //     heardAboutUs: 'Career Fair',
  //     skill: 'Construction Management',
  //     shiftType: 'Full-time',
  //     workPlace: 'On-site',
  //     employmentType: 'Permanent',
  //     profilePicture: null,
  //     resume: null,
  //     name:'Ajay',
  //     mobile:'1234567809',
  //     companyName: 'Build It Co',
  //     jobRole: 'Construction Manager',
  //     employmentStartDate: '2015-03-01',
  //     employmentEndDate: '2023-03-31',
  //     duties: 'Managing construction projects',
  //     reasonForLeaving: 'Pursuing new challenges',
  //     collegeName: 'Engineering School',
  //     degree: 'BSc Civil Engineering',
  //     specialization: 'Construction Management',
  //     graduationMonth: 'December',
  //     graduationYear: '2014',
  //     referenceName: 'Jessica Jones',
  //     relationship: 'Former Project Lead',
  //     referenceMobile: '765-432-1098',
  //     referenceEmail: 'jessica.jones@example.com',
  //     experienceLetter: null,
  //   },
  // ]);

//   const [editingIndex, setEditingIndex] = useState(null);

//   const handleSearchChange = (e) => setSearchTerm(e.target.value);
//   const handlePositionFilterChange = (e) => setPositionFilter(e.target.value);
//   const handleSkillFilterChange = (e) => setSkillFilter(e.target.value);
//   const handleDelete = (index) => setJobRecords(jobRecords.filter((_, i) => i !== index));
//   const handleEdit = (index) => {
//     setEditingIndex(index);
//     setShowModal(true);
//   };

//   const handleFormSubmit = (formData) => {
//     if (editingIndex !== null) {
//       const updatedRecords = jobRecords.map((record, index) =>
//         index === editingIndex ? formData : record
//       );
//       setJobRecords(updatedRecords);
//     } else {
//       setJobRecords([...jobRecords, formData]);
//     }
//     setShowModal(false);
//     setEditingIndex(null);
//   };

//   const filteredRecords = jobRecords.filter((record) => {
//     const matchesSearch = Object.values(record).some((value) =>
//       value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
//     );
//     const matchesPosition = positionFilter
//       ? record.positionApplied.toLowerCase() === positionFilter.toLowerCase()
//       : true;
//     const matchesSkill = skillFilter
//       ? record.skill.toLowerCase() === skillFilter.toLowerCase()
//       : true;
//     return matchesSearch && matchesPosition && matchesSkill;
//   });

//   return (
//     <Box sx={{maxWidth:'1200px',width:'100%', marginLeft:'275px', mt: 7,backgroundColor: '#fff', p: 4, borderRadius:'10px' }}>
//       <Typography variant="h4" gutterBottom>
//         Job Records
//       </Typography>
//       <hr />
//       <Grid container spacing={2} sx={{ mb: 3 }}>
//         <Grid item xs={12} sm={6} md={4}>
//           <TextField
//             fullWidth
//             label="Search job records"
//             value={searchTerm}
//             onChange={handleSearchChange}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <FormControl fullWidth>
//             <TextField
//             select 
//             label="Position"
//               value={positionFilter}
//               onChange={handlePositionFilterChange}
//             >
//               <MenuItem value="">All Positions</MenuItem>
//               {[...new Set(jobRecords.map(record => record.positionApplied))].map((position, index) => (
//                 <MenuItem key={index} value={position}>{position}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <FormControl fullWidth>
//             <TextField
//             select 
//             label="Skill"
//               value={skillFilter}
//               onChange={handleSkillFilterChange}
//             >
//               <MenuItem value="">All Skills</MenuItem>
//               {[...new Set(jobRecords.map(record => record.skill))].map((skill, index) => (
//                 <MenuItem key={index} value={skill}>{skill}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//       </Grid>

//       <JobTable
//         records={filteredRecords}
//         onDelete={handleDelete}
//         onEdit={handleEdit}
//       />

//       <Modal
//         open={showModal}
//         onClose={() => setShowModal(false)}
//         aria-labelledby="modal-title"
//         aria-describedby="modal-description"
//       >
//         <JobEditForm
//           editingIndex={editingIndex}
//           initialFormData={editingIndex !== null ? jobRecords[editingIndex] : null}
//           onSubmit={handleFormSubmit}
//           onClose={() => setShowModal(false)}
//         />
//       </Modal>
//     </Box>
//   );
// }

// export default JobRecord;
// import React, { useState } from 'react';
// import { Box, Typography, Grid, TextField, FormControl, MenuItem, Slider  } from '@mui/material';
// import JobTable from './JobTable';
// import ViewDetails from './ViewDetails';

// function JobRecord() {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [positionFilter, setPositionFilter] = useState('');
//   const [skillFilter, setSkillFilter] = useState('');
//   const [experienceRange, setExperienceRange] = useState([0, 50]);
//   const [selectedRecord, setSelectedRecord] = useState(null);
//   const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
//   const [jobRecords, setJobRecords] = useState([
//     // Static data entries (keep your static data here)
    // {
    //   fullName: 'Luke Cage',
    //   birthDate: '1988-10-15',
    //   gender: 'Male',
    //   age: '35',
    //   streetAddress: '789 Willow St',
    //   streetAddress2: '',
    //   city: 'New York',
    //   state: 'New York',
    //   postalCode: '10001',
    //   sameAsCurrent: false,
    //   permanentStreetAddress: '101 Ash St',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'New York',
    //   permanentState: 'New York',
    //   permanentPostalCode: '10002',
    //   email: 'luke.cage@example.com',
    //   phoneNumber: '456-789-0123',
    //   aadharNo: '1234-5678-9012',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'New York City',
    //   linkedin: 'https://linkedin.com/in/lukecage',
    //   positionApplied: 'Construction Manager',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '10',
    //   monthsOfExperience: '2',
    //   heardAboutUs: 'Career Fair',
    //   skill: 'Construction Management',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Build It Co',
    //   jobRole: 'Construction Manager',
    //   employmentStartDate: '2015-03-01',
    //   employmentEndDate: '2023-03-31',
    //   duties: 'Managing construction projects',
    //   reasonForLeaving: 'Pursuing new challenges',
    //   collegeName: 'Engineering School',
    //   degree: 'BSc Civil Engineering',
    //   specialization: 'Construction Management',
    //   graduationMonth: 'December',
    //   graduationYear: '2014',
    //   referenceName: 'Jessica Jones',
    //   relationship: 'Former Project Lead',
    //   referenceMobile: '765-432-1098',
    //   referenceEmail: 'jessica.jones@example.com',
    //   referenceCompany: 'Alias Investigations',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Jessica Jones',
    //   birthDate: '1986-04-20',
    //   gender: 'Female',
    //   age: '38',
    //   streetAddress: '123 Elm St',
    //   streetAddress2: 'Apt 5B',
    //   city: 'New York',
    //   state: 'New York',
    //   postalCode: '10003',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '123 Elm St',
    //   permanentStreetAddress2: 'Apt 5B',
    //   permanentCity: 'New York',
    //   permanentState: 'New York',
    //   permanentPostalCode: '10003',
    //   email: 'jessica.jones@example.com',
    //   phoneNumber: '321-654-9870',
    //   aadharNo: '2345-6789-0123',
    //   preferredLanguage: ['English', 'Spanish'],
    //   jobLocation: 'New York City',
    //   linkedin: 'https://linkedin.com/in/jessicajones',
    //   positionApplied: 'Private Investigator',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '12',
    //   monthsOfExperience: '5',
    //   heardAboutUs: 'Online Job Board',
    //   skill: 'Investigative Work',
    //   shiftType: 'Flexible',
    //   workPlace: 'Remote',
    //   employmentType: 'Freelance',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Alias Investigations',
    //   jobRole: 'Lead Investigator',
    //   employmentStartDate: '2010-01-15',
    //   employmentEndDate: '2023-07-30',
    //   duties: 'Conducting private investigations',
    //   reasonForLeaving: 'Starting own business',
    //   collegeName: 'State University',
    //   degree: 'BA Criminal Justice',
    //   specialization: 'Criminology',
    //   graduationMonth: 'May',
    //   graduationYear: '2008',
    //   referenceName: 'Trish Walker',
    //   relationship: 'Friend & Colleague',
    //   referenceMobile: '987-654-3210',
    //   referenceEmail: 'trish.walker@example.com',
    //   referenceCompany: 'New York Media',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Matt Murdock',
    //   birthDate: '1985-12-15',
    //   gender: 'Male',
    //   age: '39',
    //   streetAddress: '321 Maple St',
    //   streetAddress2: '',
    //   city: 'New York',
    //   state: 'New York',
    //   postalCode: '10004',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '321 Maple St',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'New York',
    //   permanentState: 'New York',
    //   permanentPostalCode: '10004',
    //   email: 'matt.murdock@example.com',
    //   phoneNumber: '789-012-3456',
    //   aadharNo: '3456-7890-1234',
    //   preferredLanguage: ['English', 'Italian'],
    //   jobLocation: 'New York City',
    //   linkedin: 'https://linkedin.com/in/mattmurdock',
    //   positionApplied: 'Attorney',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '15',
    //   monthsOfExperience: '6',
    //   heardAboutUs: 'Referral',
    //   skill: 'Legal Services',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Nelson & Murdock',
    //   jobRole: 'Senior Partner',
    //   employmentStartDate: '2008-09-01',
    //   employmentEndDate: '2023-08-15',
    //   duties: 'Providing legal counsel',
    //   reasonForLeaving: 'Seeking new opportunities',
    //   collegeName: 'Harvard Law School',
    //   degree: 'JD Law',
    //   specialization: 'Criminal Law',
    //   graduationMonth: 'June',
    //   graduationYear: '2007',
    //   referenceName: 'Foggy Nelson',
    //   relationship: 'Business Partner',
    //   referenceMobile: '876-543-2109',
    //   referenceEmail: 'foggy.nelson@example.com',
    //   referenceCompany: 'Nelson & Murdock',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Peter Parker',
    //   birthDate: '1995-08-10',
    //   gender: 'Male',
    //   age: '29',
    //   streetAddress: '456 Oak St',
    //   streetAddress2: 'Apt 3A',
    //   city: 'Queens',
    //   state: 'New York',
    //   postalCode: '11375',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '456 Oak St',
    //   permanentStreetAddress2: 'Apt 3A',
    //   permanentCity: 'Queens',
    //   permanentState: 'New York',
    //   permanentPostalCode: '11375',
    //   email: 'peter.parker@example.com',
    //   phoneNumber: '012-345-6789',
    //   aadharNo: '4567-8901-2345',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'New York City',
    //   linkedin: 'https://linkedin.com/in/peterparker',
    //   positionApplied: 'Photographer',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '5',
    //   monthsOfExperience: '10',
    //   heardAboutUs: 'Newspaper Ad',
    //   skill: 'Photography',
    //   shiftType: 'Part-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Contract',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Daily Bugle',
    //   jobRole: 'Freelance Photographer',
    //   employmentStartDate: '2018-06-01',
    //   employmentEndDate: '2023-06-01',
    //   duties: 'Capturing news photos',
    //   reasonForLeaving: 'Contract ended',
    //   collegeName: 'Empire State University',
    //   degree: 'BA Journalism',
    //   specialization: 'Photojournalism',
    //   graduationMonth: 'May',
    //   graduationYear: '2017',
    //   referenceName: 'J. Jonah Jameson',
    //   relationship: 'Former Employer',
    //   referenceMobile: '345-678-9012',
    //   referenceEmail: 'jjj@example.com',
    //   referenceCompany: 'Daily Bugle',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Natasha Romanoff',
    //   birthDate: '1984-11-22',
    //   gender: 'Female',
    //   age: '39',
    //   streetAddress: '112 Black Widow Lane',
    //   streetAddress2: '',
    //   city: 'St. Petersburg',
    //   state: 'Florida',
    //   postalCode: '33701',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '112 Black Widow Lane',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'St. Petersburg',
    //   permanentState: 'Florida',
    //   permanentPostalCode: '33701',
    //   email: 'natasha.romanoff@example.com',
    //   phoneNumber: '555-444-3333',
    //   aadharNo: '8901-2345-6789',
    //   preferredLanguage: ['English', 'Russian'],
    //   jobLocation: 'St. Petersburg',
    //   linkedin: 'https://linkedin.com/in/natasha-romanoff',
    //   positionApplied: 'Spy',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '18',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'Agency Recruitment',
    //   skill: 'Espionage',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'SHIELD',
    //   jobRole: 'Spy',
    //   employmentStartDate: '2006-01-01',
    //   employmentEndDate: '2024-01-01',
    //   duties: 'Intelligence gathering and field operations',
    //   reasonForLeaving: 'Transitioning to a new role',
    //   collegeName: 'KGB Training Facility',
    //   degree: 'Master of Espionage',
    //   specialization: 'Counter-Intelligence',
    //   graduationMonth: 'November',
    //   graduationYear: '2004',
    //   referenceName: 'Clint Barton',
    //   relationship: 'Former Partner',
    //   referenceMobile: '555-333-4444',
    //   referenceEmail: 'clint.barton@example.com',
    //   referenceCompany: 'SHIELD',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Bruce Banner',
    //   birthDate: '1969-12-18',
    //   gender: 'Male',
    //   age: '54',
    //   streetAddress: '123 Science Rd',
    //   streetAddress2: '',
    //   city: 'Harlem',
    //   state: 'New York',
    //   postalCode: '10027',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '123 Science Rd',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'Harlem',
    //   permanentState: 'New York',
    //   permanentPostalCode: '10027',
    //   email: 'bruce.banner@example.com',
    //   phoneNumber: '555-123-4567',
    //   aadharNo: '7890-1234-5678',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'Harlem',
    //   linkedin: 'https://linkedin.com/in/brucebanner',
    //   positionApplied: 'Scientist',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '30',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'University Job Board',
    //   skill: 'Nuclear Physics',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Stark Industries',
    //   jobRole: 'Scientist',
    //   employmentStartDate: '1994-02-01',
    //   employmentEndDate: '2024-02-01',
    //   duties: 'Research and development in nuclear physics',
    //   reasonForLeaving: 'Pursuing personal research',
    //   collegeName: 'Caltech',
    //   degree: 'PhD in Nuclear Physics',
    //   specialization: 'Gamma Radiation',
    //   graduationMonth: 'December',
    //   graduationYear: '1993',
    //   referenceName: 'Tony Stark',
    //   relationship: 'Colleague',
    //   referenceMobile: '555-555-5555',
    //   referenceEmail: 'tony.stark@example.com',
    //   referenceCompany: 'Stark Industries',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Carol Danvers',
    //   birthDate: '1989-03-07',
    //   gender: 'Female',
    //   age: '35',
    //   streetAddress: '55 Heroes Way',
    //   streetAddress2: '',
    //   city: 'San Francisco',
    //   state: 'California',
    //   postalCode: '94105',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '55 Heroes Way',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'San Francisco',
    //   permanentState: 'California',
    //   permanentPostalCode: '94105',
    //   email: 'carol.danvers@example.com',
    //   phoneNumber: '555-777-8888',
    //   aadharNo: '5678-1234-5678',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'San Francisco',
    //   linkedin: 'https://linkedin.com/in/caroldanvers',
    //   positionApplied: 'Pilot',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '16',
    //   monthsOfExperience: '3',
    //   heardAboutUs: 'Military Referral',
    //   skill: 'Aviation',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Air Force',
    //   jobRole: 'Pilot',
    //   employmentStartDate: '2007-05-01',
    //   employmentEndDate: '2023-08-01',
    //   duties: 'Aerial operations',
    //   reasonForLeaving: 'Pursuing new opportunities',
    //   collegeName: 'Air Force Academy',
    //   degree: 'Bachelor of Aviation',
    //   specialization: 'Pilot Training',
    //   graduationMonth: 'May',
    //   graduationYear: '2007',
    //   referenceName: 'Nick Fury',
    //   relationship: 'Supervisor',
    //   referenceMobile: '666-888-9999',
    //   referenceEmail: 'nick.fury@example.com',
    //   referenceCompany: 'Air Force',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Thor Odinson',
    //   birthDate: '1985-07-08',
    //   gender: 'Male',
    //   age: '39',
    //   streetAddress: 'Asgard',
    //   streetAddress2: '',
    //   city: 'Asgard',
    //   state: 'Asgard',
    //   postalCode: '00001',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: 'Asgard',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'Asgard',
    //   permanentState: 'Asgard',
    //   permanentPostalCode: '00001',
    //   email: 'thor.odinson@example.com',
    //   phoneNumber: '111-222-3333',
    //   aadharNo: '1234-5678-9101',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'Asgard',
    //   linkedin: 'https://linkedin.com/in/thorodinson',
    //   positionApplied: 'God of Thunder',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '20',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'Divine Providence',
    //   skill: 'Thunder Control',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Asgard',
    //   jobRole: 'God of Thunder',
    //   employmentStartDate: '0001-01-01',
    //   employmentEndDate: '2024-12-31',
    //   duties: 'Protecting realms and wielding Mjolnir',
    //   reasonForLeaving: 'N/A',
    //   collegeName: 'Asgardian Academy',
    //   degree: 'Master of Thunder',
    //   specialization: 'Lightning',
    //   graduationMonth: 'July',
    //   graduationYear: '0001',
    //   referenceName: 'Odin',
    //   relationship: 'Father',
    //   referenceMobile: '999-000-1111',
    //   referenceEmail: 'odin@example.com',
    //   referenceCompany: 'Asgard',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Peter Parker',
    //   birthDate: '1996-08-10',
    //   gender: 'Male',
    //   age: '28',
    //   streetAddress: '20 Ingram St',
    //   streetAddress2: '',
    //   city: 'New York',
    //   state: 'New York',
    //   postalCode: '10002',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '20 Ingram St',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'New York',
    //   permanentState: 'New York',
    //   permanentPostalCode: '10002',
    //   email: 'peter.parker@example.com',
    //   phoneNumber: '555-999-1111',
    //   aadharNo: '2345-6789-1234',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'New York City',
    //   linkedin: 'https://linkedin.com/in/peterparker',
    //   positionApplied: 'Photographer',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '8',
    //   monthsOfExperience: '2',
    //   heardAboutUs: 'Social Media',
    //   skill: 'Photography',
    //   shiftType: 'Part-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Freelance',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Freelance',
    //   jobRole: 'Photographer',
    //   employmentStartDate: '2015-06-01',
    //   employmentEndDate: '2024-06-01',
    //   duties: 'Taking photographs and editing',
    //   reasonForLeaving: 'Pursuing other interests',
    //   collegeName: 'Empire State University',
    //   degree: 'Bachelor of Arts in Photography',
    //   specialization: 'Digital Photography',
    //   graduationMonth: 'May',
    //   graduationYear: '2014',
    //   referenceName: 'Mary Jane Watson',
    //   relationship: 'Friend',
    //   referenceMobile: '555-666-7777',
    //   referenceEmail: 'mary.jane@example.com',
    //   referenceCompany: 'Freelance',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Wanda Maximoff',
    //   birthDate: '1989-07-25',
    //   gender: 'Female',
    //   age: '35',
    //   streetAddress: '1600 Westwood Blvd',
    //   streetAddress2: '',
    //   city: 'Los Angeles',
    //   state: 'California',
    //   postalCode: '90024',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '1600 Westwood Blvd',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'Los Angeles',
    //   permanentState: 'California',
    //   permanentPostalCode: '90024',
    //   email: 'wanda.maximoff@example.com',
    //   phoneNumber: '555-222-3333',
    //   aadharNo: '3456-7890-1234',
    //   preferredLanguage: ['English', 'Russian'],
    //   jobLocation: 'Los Angeles',
    //   linkedin: 'https://linkedin.com/in/wandamaximoff',
    //   positionApplied: 'Sorceress',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '10',
    //   monthsOfExperience: '6',
    //   heardAboutUs: 'Mystic Referrals',
    //   skill: 'Reality Manipulation',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Wizards Inc.',
    //   jobRole: 'Sorceress',
    //   employmentStartDate: '2013-01-01',
    //   employmentEndDate: '2024-01-01',
    //   duties: 'Manipulating reality and magic',
    //   reasonForLeaving: 'Exploring new magical realms',
    //   collegeName: 'Wakanda Academy of Magic',
    //   degree: 'Master of Mysticism',
    //   specialization: 'Reality Manipulation',
    //   graduationMonth: 'July',
    //   graduationYear: '2012',
    //   referenceName: 'Doctor Strange',
    //   relationship: 'Colleague',
    //   referenceMobile: '555-444-5555',
    //   referenceEmail: 'strange@example.com',
    //   referenceCompany: 'Wizards Inc.',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'T’Challa',
    //   birthDate: '1982-05-11',
    //   gender: 'Male',
    //   age: '42',
    //   streetAddress: '123 Wakanda Rd',
    //   streetAddress2: '',
    //   city: 'Wakanda',
    //   state: 'Wakanda',
    //   postalCode: '00001',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '123 Wakanda Rd',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'Wakanda',
    //   permanentState: 'Wakanda',
    //   permanentPostalCode: '00001',
    //   email: 'tchalla@example.com',
    //   phoneNumber: '555-111-2222',
    //   aadharNo: '4567-8901-2345',
    //   preferredLanguage: ['Xhosa', 'English'],
    //   jobLocation: 'Wakanda',
    //   linkedin: 'https://linkedin.com/in/tchalla',
    //   positionApplied: 'King',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '20',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'Royal Decree',
    //   skill: 'Leadership',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Wakanda',
    //   jobRole: 'King',
    //   employmentStartDate: '2004-01-01',
    //   employmentEndDate: '2024-01-01',
    //   duties: 'Leading Wakanda and maintaining peace',
    //   reasonForLeaving: 'Retirement',
    //   collegeName: 'Wakandan University',
    //   degree: 'Bachelor of Leadership',
    //   specialization: 'Monarchical Governance',
    //   graduationMonth: 'May',
    //   graduationYear: '2003',
    //   referenceName: 'Shuri',
    //   relationship: 'Sister',
    //   referenceMobile: '555-666-7777',
    //   referenceEmail: 'shuri@example.com',
    //   referenceCompany: 'Wakanda',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Stephen Strange',
    //   birthDate: '1970-11-18',
    //   gender: 'Male',
    //   age: '53',
    //   streetAddress: '177A Bleecker St',
    //   streetAddress2: '',
    //   city: 'New York',
    //   state: 'New York',
    //   postalCode: '10012',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '177A Bleecker St',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'New York',
    //   permanentState: 'New York',
    //   permanentPostalCode: '10012',
    //   email: 'stephen.strange@example.com',
    //   phoneNumber: '555-999-0000',
    //   aadharNo: '6789-2345-6789',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'New York City',
    //   linkedin: 'https://linkedin.com/in/stephenstrange',
    //   positionApplied: 'Sorcerer Supreme',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '20',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'Mystic Referral',
    //   skill: 'Magic',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Sanctum Sanctorum',
    //   jobRole: 'Sorcerer Supreme',
    //   employmentStartDate: '2004-11-01',
    //   employmentEndDate: '2024-11-01',
    //   duties: 'Protecting Earth from mystical threats',
    //   reasonForLeaving: 'N/A',
    //   collegeName: 'Kamar-Taj',
    //   degree: 'Master of Mystic Arts',
    //   specialization: 'Defensive Magic',
    //   graduationMonth: 'November',
    //   graduationYear: '2003',
    //   referenceName: 'Wanda Maximoff',
    //   relationship: 'Colleague',
    //   referenceMobile: '555-222-3333',
    //   referenceEmail: 'wanda.maximoff@example.com',
    //   referenceCompany: 'Sanctum Sanctorum',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Janet Van Dyne',
    //   birthDate: '1968-07-25',
    //   gender: 'Female',
    //   age: '56',
    //   streetAddress: '456 Quantum Ave',
    //   streetAddress2: '',
    //   city: 'San Francisco',
    //   state: 'California',
    //   postalCode: '94109',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '456 Quantum Ave',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'San Francisco',
    //   permanentState: 'California',
    //   permanentPostalCode: '94109',
    //   email: 'janet.vandyne@example.com',
    //   phoneNumber: '555-888-9999',
    //   aadharNo: '2345-6789-0123',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'San Francisco',
    //   linkedin: 'https://linkedin.com/in/janetvandyne',
    //   positionApplied: 'Entomologist',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '30',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'University Alumni',
    //   skill: 'Entomology',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Pym Technologies',
    //   jobRole: 'Entomologist',
    //   employmentStartDate: '1994-09-01',
    //   employmentEndDate: '2024-09-01',
    //   duties: 'Researching quantum biology and insects',
    //   reasonForLeaving: 'Retirement',
    //   collegeName: 'California State University',
    //   degree: 'PhD in Entomology',
    //   specialization: 'Quantum Biology',
    //   graduationMonth: 'July',
    //   graduationYear: '1993',
    //   referenceName: 'Hank Pym',
    //   relationship: 'Colleague',
    //   referenceMobile: '555-444-6666',
    //   referenceEmail: 'hank.pym@example.com',
    //   referenceCompany: 'Pym Technologies',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Clint Barton',
    //   birthDate: '1981-06-07',
    //   gender: 'Male',
    //   age: '43',
    //   streetAddress: '789 Arrow St',
    //   streetAddress2: '',
    //   city: 'Rochester',
    //   state: 'New York',
    //   postalCode: '14607',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '789 Arrow St',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'Rochester',
    //   permanentState: 'New York',
    //   permanentPostalCode: '14607',
    //   email: 'clint.barton@example.com',
    //   phoneNumber: '555-333-4444',
    //   aadharNo: '5678-9012-3456',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'Rochester',
    //   linkedin: 'https://linkedin.com/in/clintbarton',
    //   positionApplied: 'Archer',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '20',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'Military Service',
    //   skill: 'Archery',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'SHIELD',
    //   jobRole: 'Archer',
    //   employmentStartDate: '2004-05-01',
    //   employmentEndDate: '2024-05-01',
    //   duties: 'Archery training and missions',
    //   reasonForLeaving: 'Transitioning to a new role',
    //   collegeName: 'Military Academy',
    //   degree: 'Bachelor of Arms',
    //   specialization: 'Archery',
    //   graduationMonth: 'June',
    //   graduationYear: '2002',
    //   referenceName: 'Natasha Romanoff',
    //   relationship: 'Colleague',
    //   referenceMobile: '555-444-3333',
    //   referenceEmail: 'natasha.romanoff@example.com',
    //   referenceCompany: 'SHIELD',
    //   experienceLetter: null,
    // },
    // {
    //   fullName: 'Gamora',
    //   birthDate: '1984-11-19',
    //   gender: 'Female',
    //   age: '39',
    //   streetAddress: '22 Nebula Way',
    //   streetAddress2: '',
    //   city: 'Galaxy',
    //   state: 'Space',
    //   postalCode: '12345',
    //   sameAsCurrent: true,
    //   permanentStreetAddress: '22 Nebula Way',
    //   permanentStreetAddress2: '',
    //   permanentCity: 'Galaxy',
    //   permanentState: 'Space',
    //   permanentPostalCode: '12345',
    //   email: 'gamora@example.com',
    //   phoneNumber: '555-000-1111',
    //   aadharNo: '6789-0123-4567',
    //   preferredLanguage: ['English'],
    //   jobLocation: 'Galaxy',
    //   linkedin: 'https://linkedin.com/in/gamora',
    //   positionApplied: 'Warrior',
    //   hasWorkExperience: true,
    //   yearsOfExperience: '15',
    //   monthsOfExperience: '0',
    //   heardAboutUs: 'Intergalactic Recruitment',
    //   skill: 'Combat',
    //   shiftType: 'Full-time',
    //   workPlace: 'On-site',
    //   employmentType: 'Permanent',
    //   profilePicture: null,
    //   signature: null,
    //   resume: null,
    //   companyName: 'Guardians of the Galaxy',
    //   jobRole: 'Warrior',
    //   employmentStartDate: '2009-01-01',
    //   employmentEndDate: '2024-01-01',
    //   duties: 'Combat and protection of the galaxy',
    //   reasonForLeaving: 'Exploring new challenges',
    //   collegeName: 'Zenn-La Academy',
    //   degree: 'Master of Combat',
    //   specialization: 'Intergalactic Warfare',
    //   graduationMonth: 'November',
    //   graduationYear: '2008',
    //   referenceName: 'Star-Lord',
    //   relationship: 'Colleague',
    //   referenceMobile: '555-333-7777',
    //   referenceEmail: 'star-lord@example.com',
    //   referenceCompany: 'Guardians of the Galaxy',
    //   experienceLetter: null,
    // },
//   ]);

//   const handleSearchChange = (e) => setSearchTerm(e.target.value);
//   const handlePositionFilterChange = (e) => setPositionFilter(e.target.value);
//   const handleSkillFilterChange = (e) => setSkillFilter(e.target.value);
//   const handleExperienceChange = (e, newValue) => setExperienceRange(newValue);
//   const handleDelete = (index) => setJobRecords(jobRecords.filter((_, i) => i !== index));
//   const handleAddNew = (formData) => setJobRecords([...jobRecords, formData]);

//   const handleViewDetails = (record) => {
//     setSelectedRecord(record);
//     setIsViewDetailsOpen(true);
//   };

//   const handleCloseDetails = () => {
//     setIsViewDetailsOpen(false);
//     setSelectedRecord(null);
//   };

//   const filteredRecords = jobRecords.filter((record) => {
//     const matchesSearch = Object.values(record).some((value) =>
//       value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
//     );
//     const matchesPosition = positionFilter
//       ? record.positionApplied.toLowerCase() === positionFilter.toLowerCase()
//       : true;
//     const matchesSkill = skillFilter
//       ? record.skill.toLowerCase() === skillFilter.toLowerCase()
//       : true;
//     return matchesSearch && matchesPosition && matchesSkill;

//     const matchesExperience = record.yearsOfExperience >= experienceRange[0] && record.yearsOfExperience <= experienceRange[1];
//     return matchesSearch && matchesPosition && matchesSkill && matchesExperience;
//   });

//   return (
//     <Box sx={{ maxWidth: '1200px', width: '100%', marginLeft: '275px', mt: 7, backgroundColor: '#fff', p: 4, borderRadius: '10px' }}>
//       <Typography variant="h4" gutterBottom>
//         Job Records
//       </Typography>
//       <hr />
//       <Grid container spacing={2} sx={{ mb: 3 }}>
//         <Grid item xs={12} sm={6} md={4}>
//           <TextField
//             fullWidth
//             label="Search job records"
//             value={searchTerm}
//             onChange={handleSearchChange}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <FormControl fullWidth>
//             <TextField
//               select
//               label="Position"
//               value={positionFilter}
//               onChange={handlePositionFilterChange}
//             >
//               <MenuItem value="">All Positions</MenuItem>
//               {[...new Set(jobRecords.map(record => record.positionApplied))].map((position, index) => (
//                 <MenuItem key={index} value={position}>{position}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <FormControl fullWidth>
//             <TextField
//               select
//               label="Skill"
//               value={skillFilter}
//               onChange={handleSkillFilterChange}
//             >
//               <MenuItem value="">All Skills</MenuItem>
//               {[...new Set(jobRecords.map(record => record.skill))].map((skill, index) => (
//                 <MenuItem key={index} value={skill}>{skill}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <Typography gutterBottom>Experience Range (years)</Typography>
//           <Slider
//             value={experienceRange}
//             onChange={handleExperienceChange}
//             valueLabelDisplay="auto"
//             min={0}
//             max={50}
//             step={1}
//           />
//         </Grid>
//       </Grid>
//       <JobTable records={filteredRecords} onDelete={handleDelete} onViewDetails={handleViewDetails} />
//       {selectedRecord && (
//         <ViewDetails
//           record={selectedRecord}
//           open={isViewDetailsOpen}
//           onClose={handleCloseDetails}
//         />
//       )}
//     </Box>
//   );
// }

// export default JobRecord;


// import React, { useState } from 'react';
// import { Box, Typography, Grid, TextField, FormControl, MenuItem, Slider } from '@mui/material';
// import JobTable from './JobTable';
// import ViewDetails from './ViewDetails';

// function JobRecord() {
//   const [searchTerm, setSearchTerm] = useState('');
//   const [positionFilter, setPositionFilter] = useState('');
//   const [skillFilter, setSkillFilter] = useState('');
//   const [degreeFilter, setDegreeFilter] = useState('');
//   const [experienceRange, setExperienceRange] = useState([0, 50]);
//   const [selectedRecord, setSelectedRecord] = useState(null);
//   const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
//   const [jobRecords, setJobRecords] = useState([
//     // Static data entries
    // {
    //   "fullName": "Rajesh Kumar",
    //   "birthDate": "1985-09-15",
    //   "gender": "Male",
    //   "age": "38",
    //   "streetAddress": "123 MG Road",
    //   "streetAddress2": "Apt 101",
    //   "city": "Bangalore",
    //   "state": "Karnataka",
    //   "postalCode": "560001",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "123 MG Road",
    //   "permanentStreetAddress2": "Apt 101",
    //   "permanentCity": "Bangalore",
    //   "permanentState": "Karnataka",
    //   "permanentPostalCode": "560001",
    //   "email": "rajesh.kumar@example.com",
    //   "phoneNumber": "080-12345678",
    //   "aadharNo": "1234-5678-9101",
    //   "preferredLanguage": ["Hindi", "English"],
    //   "jobLocation": "Bangalore",
    //   "linkedin": "https://linkedin.com/in/rajeshkumar",
    //   "positionApplied": "Software Engineer",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "12",
    //   "monthsOfExperience": "4",
    //   "heardAboutUs": "LinkedIn",
    //   "skill": "Software Development",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Tech Solutions Pvt Ltd",
    //   "jobRole": "Senior Developer",
    //   "employmentStartDate": "2010-06-01",
    //   "employmentEndDate": "2022-06-30",
    //   "duties": "Developing and maintaining software applications",
    //   "reasonForLeaving": "Seeking new opportunities",
    //   "collegeName": "Indian Institute of Technology",
    //   "degree": "B.Tech in Computer Science",
    //   "specialization": "Software Engineering",
    //   "graduationMonth": "May",
    //   "graduationYear": "2008",
    //   "referenceName": "Amit Sharma",
    //   "relationship": "Former Manager",
    //   "referenceMobile": "987-654-3210",
    //   "referenceEmail": "amit.sharma@example.com",
    //   "referenceCompany": "Tech Solutions Pvt Ltd",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Sonia Patel",
    //   "birthDate": "1990-11-20",
    //   "gender": "Female",
    //   "age": "33",
    //   "streetAddress": "456 Park Lane",
    //   "streetAddress2": "Flat 202",
    //   "city": "Mumbai",
    //   "state": "Maharashtra",
    //   "postalCode": "400002",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "456 Park Lane",
    //   "permanentStreetAddress2": "Flat 202",
    //   "permanentCity": "Mumbai",
    //   "permanentState": "Maharashtra",
    //   "permanentPostalCode": "400002",
    //   "email": "sonia.patel@example.com",
    //   "phoneNumber": "022-87654321",
    //   "aadharNo": "2345-6789-0123",
    //   "preferredLanguage": ["Marathi", "English"],
    //   "jobLocation": "Mumbai",
    //   "linkedin": "https://linkedin.com/in/soniapatel",
    //   "positionApplied": "Marketing Manager",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "8",
    //   "monthsOfExperience": "6",
    //   "heardAboutUs": "Employee Referral",
    //   "skill": "Marketing Strategy",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Marketing Insights Pvt Ltd",
    //   "jobRole": "Marketing Head",
    //   "employmentStartDate": "2014-01-01",
    //   "employmentEndDate": "2022-07-31",
    //   "duties": "Developing and implementing marketing strategies",
    //   "reasonForLeaving": "Exploring new challenges",
    //   "collegeName": "Mumbai University",
    //   "degree": "MBA in Marketing",
    //   "specialization": "Marketing Management",
    //   "graduationMonth": "July",
    //   "graduationYear": "2013",
    //   "referenceName": "Ravi Desai",
    //   "relationship": "Former Supervisor",
    //   "referenceMobile": "998-877-6655",
    //   "referenceEmail": "ravi.desai@example.com",
    //   "referenceCompany": "Marketing Insights Pvt Ltd",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Amit Singh",
    //   "birthDate": "1983-06-05",
    //   "gender": "Male",
    //   "age": "41",
    //   "streetAddress": "789 Greenfield Road",
    //   "streetAddress2": "",
    //   "city": "Delhi",
    //   "state": "Delhi",
    //   "postalCode": "110001",
    //   "sameAsCurrent": false,
    //   "permanentStreetAddress": "789 Greenfield Road",
    //   "permanentStreetAddress2": "",
    //   "permanentCity": "Delhi",
    //   "permanentState": "Delhi",
    //   "permanentPostalCode": "110001",
    //   "email": "amit.singh@example.com",
    //   "phoneNumber": "011-23456789",
    //   "aadharNo": "3456-7890-1234",
    //   "preferredLanguage": ["Hindi", "English"],
    //   "jobLocation": "Delhi",
    //   "linkedin": "https://linkedin.com/in/amitsingh",
    //   "positionApplied": "Project Manager",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "15",
    //   "monthsOfExperience": "8",
    //   "heardAboutUs": "Job Portal",
    //   "skill": "Project Management",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Innovate Solutions",
    //   "jobRole": "Senior Project Manager",
    //   "employmentStartDate": "2008-09-01",
    //   "employmentEndDate": "2023-05-31",
    //   "duties": "Overseeing project execution and team management",
    //   "reasonForLeaving": "Looking for new opportunities",
    //   "collegeName": "Delhi College of Engineering",
    //   "degree": "B.Tech in Civil Engineering",
    //   "specialization": "Construction Management",
    //   "graduationMonth": "June",
    //   "graduationYear": "2006",
    //   "referenceName": "Pooja Mehta",
    //   "relationship": "Former Colleague",
    //   "referenceMobile": "981-234-5678",
    //   "referenceEmail": "pooja.mehta@example.com",
    //   "referenceCompany": "Innovate Solutions",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Neha Sharma",
    //   "birthDate": "1989-02-22",
    //   "gender": "Female",
    //   "age": "35",
    //   "streetAddress": "321 Bluebell Street",
    //   "streetAddress2": "",
    //   "city": "Hyderabad",
    //   "state": "Telangana",
    //   "postalCode": "500001",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "321 Bluebell Street",
    //   "permanentStreetAddress2": "",
    //   "permanentCity": "Hyderabad",
    //   "permanentState": "Telangana",
    //   "permanentPostalCode": "500001",
    //   "email": "neha.sharma@example.com",
    //   "phoneNumber": "040-12345678",
    //   "aadharNo": "4567-8901-2345",
    //   "preferredLanguage": ["Telugu", "English"],
    //   "jobLocation": "Hyderabad",
    //   "linkedin": "https://linkedin.com/in/nehasharma",
    //   "positionApplied": "HR Executive",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "7",
    //   "monthsOfExperience": "2",
    //   "heardAboutUs": "Company Website",
    //   "skill": "Human Resources",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "People First HR Solutions",
    //   "jobRole": "HR Manager",
    //   "employmentStartDate": "2015-04-01",
    //   "employmentEndDate": "2022-06-30",
    //   "duties": "Managing HR functions and recruitment",
    //   "reasonForLeaving": "Pursuing further education",
    //   "collegeName": "University of Hyderabad",
    //   "degree": "MBA in HR",
    //   "specialization": "Human Resources Management",
    //   "graduationMonth": "June",
    //   "graduationYear": "2014",
    //   "referenceName": "Ramesh Reddy",
    //   "relationship": "Former Supervisor",
    //   "referenceMobile": "944-556-7890",
    //   "referenceEmail": "ramesh.reddy@example.com",
    //   "referenceCompany": "People First HR Solutions",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Kiran Reddy",
    //   "birthDate": "1991-10-10",
    //   "gender": "Male",
    //   "age": "32",
    //   "streetAddress": "654 Orchid Lane",
    //   "streetAddress2": "Flat 303",
    //   "city": "Chennai",
    //   "state": "Tamil Nadu",
    //   "postalCode": "600003",
    //   "sameAsCurrent": false,
    //   "permanentStreetAddress": "654 Orchid Lane",
    //   "permanentStreetAddress2": "Flat 303",
    //   "permanentCity": "Chennai",
    //   "permanentState": "Tamil Nadu",
    //   "permanentPostalCode": "600003",
    //   "email": "kiran.reddy@example.com",
    //   "phoneNumber": "044-56789012",
    //   "aadharNo": "5678-9012-3456",
    //   "preferredLanguage": ["Tamil", "English"],
    //   "jobLocation": "Chennai",
    //   "linkedin": "https://linkedin.com/in/kiranreddy",
    //   "positionApplied": "Financial Analyst",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "6",
    //   "monthsOfExperience": "0",
    //   "heardAboutUs": "Job Fair",
    //   "skill": "Financial Analysis",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "FinServe Solutions",
    //   "jobRole": "Finance Manager",
    //   "employmentStartDate": "2016-07-01",
    //   "employmentEndDate": "2022-07-31",
    //   "duties": "Analyzing financial data and preparing reports",
    //   "reasonForLeaving": "Seeking growth opportunities",
    //   "collegeName": "Madras University",
    //   "degree": "M.Com",
    //   "specialization": "Financial Management",
    //   "graduationMonth": "July",
    //   "graduationYear": "2015",
    //   "referenceName": "Suman Raj",
    //   "relationship": "Former Manager",
    //   "referenceMobile": "960-234-5678",
    //   "referenceEmail": "suman.raj@example.com",
    //   "referenceCompany": "FinServe Solutions",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Anita Desai",
    //   "birthDate": "1987-07-30",
    //   "gender": "Female",
    //   "age": "37",
    //   "streetAddress": "987 Sunset Boulevard",
    //   "streetAddress2": "Block B",
    //   "city": "Pune",
    //   "state": "Maharashtra",
    //   "postalCode": "411007",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "987 Sunset Boulevard",
    //   "permanentStreetAddress2": "Block B",
    //   "permanentCity": "Pune",
    //   "permanentState": "Maharashtra",
    //   "permanentPostalCode": "411007",
    //   "email": "anita.desai@example.com",
    //   "phoneNumber": "020-12345678",
    //   "aadharNo": "6789-0123-4567",
    //   "preferredLanguage": ["Marathi", "English"],
    //   "jobLocation": "Pune",
    //   "linkedin": "https://linkedin.com/in/anitadesai",
    //   "positionApplied": "Product Manager",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "10",
    //   "monthsOfExperience": "3",
    //   "heardAboutUs": "Job Portal",
    //   "skill": "Product Management",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "ProductX Innovations",
    //   "jobRole": "Senior Product Manager",
    //   "employmentStartDate": "2012-01-01",
    //   "employmentEndDate": "2022-04-30",
    //   "duties": "Overseeing product development and strategy",
    //   "reasonForLeaving": "Pursuing higher studies",
    //   "collegeName": "Pune University",
    //   "degree": "MBA in Product Management",
    //   "specialization": "Product Strategy",
    //   "graduationMonth": "June",
    //   "graduationYear": "2011",
    //   "referenceName": "Ravi Kulkarni",
    //   "relationship": "Former Manager",
    //   "referenceMobile": "982-345-6789",
    //   "referenceEmail": "ravi.kulkarni@example.com",
    //   "referenceCompany": "ProductX Innovations",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Ravi Kumar",
    //   "birthDate": "1984-08-19",
    //   "gender": "Male",
    //   "age": "40",
    //   "streetAddress": "432 Hilltop Avenue",
    //   "streetAddress2": "Suite 501",
    //   "city": "Ahmedabad",
    //   "state": "Gujarat",
    //   "postalCode": "380001",
    //   "sameAsCurrent": false,
    //   "permanentStreetAddress": "432 Hilltop Avenue",
    //   "permanentStreetAddress2": "Suite 501",
    //   "permanentCity": "Ahmedabad",
    //   "permanentState": "Gujarat",
    //   "permanentPostalCode": "380001",
    //   "email": "ravi.kumar@example.com",
    //   "phoneNumber": "079-12345678",
    //   "aadharNo": "7890-1234-5678",
    //   "preferredLanguage": ["Gujarati", "English"],
    //   "jobLocation": "Ahmedabad",
    //   "linkedin": "https://linkedin.com/in/ravikumar",
    //   "positionApplied": "Business Analyst",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "11",
    //   "monthsOfExperience": "5",
    //   "heardAboutUs": "Employee Referral",
    //   "skill": "Business Analysis",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Insight Business Solutions",
    //   "jobRole": "Business Analyst",
    //   "employmentStartDate": "2011-01-01",
    //   "employmentEndDate": "2022-06-30",
    //   "duties": "Conducting business analysis and reporting",
    //   "reasonForLeaving": "Looking for new challenges",
    //   "collegeName": "Gujarat University",
    //   "degree": "M.Com",
    //   "specialization": "Business Analysis",
    //   "graduationMonth": "June",
    //   "graduationYear": "2010",
    //   "referenceName": "Sandeep Patel",
    //   "relationship": "Former Manager",
    //   "referenceMobile": "961-234-5678",
    //   "referenceEmail": "sandeep.patel@example.com",
    //   "referenceCompany": "Insight Business Solutions",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Priya Nair",
    //   "birthDate": "1992-12-11",
    //   "gender": "Female",
    //   "age": "31",
    //   "streetAddress": "567 Lakeside Drive",
    //   "streetAddress2": "Flat 404",
    //   "city": "Kochi",
    //   "state": "Kerala",
    //   "postalCode": "682001",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "567 Lakeside Drive",
    //   "permanentStreetAddress2": "Flat 404",
    //   "permanentCity": "Kochi",
    //   "permanentState": "Kerala",
    //   "permanentPostalCode": "682001",
    //   "email": "priya.nair@example.com",
    //   "phoneNumber": "0484-1234567",
    //   "aadharNo": "8901-2345-6789",
    //   "preferredLanguage": ["Malayalam", "English"],
    //   "jobLocation": "Kochi",
    //   "linkedin": "https://linkedin.com/in/priyanair",
    //   "positionApplied": "Content Writer",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "5",
    //   "monthsOfExperience": "9",
    //   "heardAboutUs": "Social Media",
    //   "skill": "Content Creation",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Creative Content Co.",
    //   "jobRole": "Senior Content Writer",
    //   "employmentStartDate": "2017-03-01",
    //   "employmentEndDate": "2023-01-31",
    //   "duties": "Creating and editing content for various platforms",
    //   "reasonForLeaving": "Exploring new opportunities",
    //   "collegeName": "Cochin University of Science and Technology",
    //   "degree": "MA in English Literature",
    //   "specialization": "Content Writing",
    //   "graduationMonth": "May",
    //   "graduationYear": "2016",
    //   "referenceName": "Rita George",
    //   "relationship": "Former Colleague",
    //   "referenceMobile": "999-123-4567",
    //   "referenceEmail": "rita.george@example.com",
    //   "referenceCompany": "Creative Content Co.",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Arun Mehta",
    //   "birthDate": "1982-03-17",
    //   "gender": "Male",
    //   "age": "42",
    //   "streetAddress": "234 Riverside Avenue",
    //   "streetAddress2": "Office 502",
    //   "city": "Jaipur",
    //   "state": "Rajasthan",
    //   "postalCode": "302001",
    //   "sameAsCurrent": false,
    //   "permanentStreetAddress": "234 Riverside Avenue",
    //   "permanentStreetAddress2": "Office 502",
    //   "permanentCity": "Jaipur",
    //   "permanentState": "Rajasthan",
    //   "permanentPostalCode": "302001",
    //   "email": "arun.mehta@example.com",
    //   "phoneNumber": "0141-2345678",
    //   "aadharNo": "9012-3456-7890",
    //   "preferredLanguage": ["Hindi", "English"],
    //   "jobLocation": "Jaipur",
    //   "linkedin": "https://linkedin.com/in/arunmehta",
    //   "positionApplied": "Sales Manager",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "18",
    //   "monthsOfExperience": "2",
    //   "heardAboutUs": "Networking Event",
    //   "skill": "Sales Management",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Sales Pros",
    //   "jobRole": "Sales Director",
    //   "employmentStartDate": "2004-02-01",
    //   "employmentEndDate": "2022-04-30",
    //   "duties": "Managing sales teams and strategies",
    //   "reasonForLeaving": "Pursuing personal business",
    //   "collegeName": "Rajasthan University",
    //   "degree": "MBA in Sales",
    //   "specialization": "Sales and Marketing",
    //   "graduationMonth": "March",
    //   "graduationYear": "2003",
    //   "referenceName": "Sushil Agarwal",
    //   "relationship": "Former Supervisor",
    //   "referenceMobile": "982-345-6789",
    //   "referenceEmail": "sushil.agarwal@example.com",
    //   "referenceCompany": "Sales Pros",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Sunita Rani",
    //   "birthDate": "1986-05-28",
    //   "gender": "Female",
    //   "age": "38",
    //   "streetAddress": "123 Lotus Street",
    //   "streetAddress2": "Bungalow 12",
    //   "city": "Chandigarh",
    //   "state": "Chandigarh",
    //   "postalCode": "160001",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "123 Lotus Street",
    //   "permanentStreetAddress2": "Bungalow 12",
    //   "permanentCity": "Chandigarh",
    //   "permanentState": "Chandigarh",
    //   "permanentPostalCode": "160001",
    //   "email": "sunita.rani@example.com",
    //   "phoneNumber": "0172-1234567",
    //   "aadharNo": "0123-4567-8901",
    //   "preferredLanguage": ["Hindi", "English"],
    //   "jobLocation": "Chandigarh",
    //   "linkedin": "https://linkedin.com/in/sunitarani",
    //   "positionApplied": "Administrative Officer",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "9",
    //   "monthsOfExperience": "10",
    //   "heardAboutUs": "Online Ad",
    //   "skill": "Administrative Management",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Admin Support Services",
    //   "jobRole": "Office Manager",
    //   "employmentStartDate": "2013-04-01",
    //   "employmentEndDate": "2023-02-28",
    //   "duties": "Managing office operations and administration",
    //   "reasonForLeaving": "Looking for career growth",
    //   "collegeName": "Panjab University",
    //   "degree": "M.Com",
    //   "specialization": "Office Management",
    //   "graduationMonth": "June",
    //   "graduationYear": "2012",
    //   "referenceName": "Rajesh Arora",
    //   "relationship": "Former Supervisor",
    //   "referenceMobile": "980-123-4567",
    //   "referenceEmail": "rajesh.arora@example.com",
    //   "referenceCompany": "Admin Support Services",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Deepak Sharma",
    //   "birthDate": "1988-04-15",
    //   "gender": "Male",
    //   "age": "36",
    //   "streetAddress": "678 Seaside Road",
    //   "streetAddress2": "Unit 303",
    //   "city": "Goa",
    //   "state": "Goa",
    //   "postalCode": "403001",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "678 Seaside Road",
    //   "permanentStreetAddress2": "Unit 303",
    //   "permanentCity": "Goa",
    //   "permanentState": "Goa",
    //   "permanentPostalCode": "403001",
    //   "email": "deepak.sharma@example.com",
    //   "phoneNumber": "0832-1234567",
    //   "aadharNo": "1234-5678-9012",
    //   "preferredLanguage": ["Konkani", "English"],
    //   "jobLocation": "Goa",
    //   "linkedin": "https://linkedin.com/in/deepaksharma",
    //   "positionApplied": "Graphic Designer",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "7",
    //   "monthsOfExperience": "11",
    //   "heardAboutUs": "Social Media",
    //   "skill": "Graphic Design",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Creative Designs Studio",
    //   "jobRole": "Senior Graphic Designer",
    //   "employmentStartDate": "2015-06-01",
    //   "employmentEndDate": "2023-05-31",
    //   "duties": "Designing visual content for marketing",
    //   "reasonForLeaving": "Looking for new opportunities",
    //   "collegeName": "Goa University",
    //   "degree": "BFA in Graphic Design",
    //   "specialization": "Digital Art",
    //   "graduationMonth": "May",
    //   "graduationYear": "2014",
    //   "referenceName": "Manoj Kumar",
    //   "relationship": "Former Supervisor",
    //   "referenceMobile": "982-345-6789",
    //   "referenceEmail": "manoj.kumar@example.com",
    //   "referenceCompany": "Creative Designs Studio",
    //   "experienceLetter": null
    // },
    // {
    //   "fullName": "Neelam Gupta",
    //   "birthDate": "1990-09-25",
    //   "gender": "Female",
    //   "age": "33",
    //   "streetAddress": "345 Maple Street",
    //   "streetAddress2": "",
    //   "city": "Noida",
    //   "state": "Uttar Pradesh",
    //   "postalCode": "201301",
    //   "sameAsCurrent": true,
    //   "permanentStreetAddress": "345 Maple Street",
    //   "permanentStreetAddress2": "",
    //   "permanentCity": "Noida",
    //   "permanentState": "Uttar Pradesh",
    //   "permanentPostalCode": "201301",
    //   "email": "neelam.gupta@example.com",
    //   "phoneNumber": "0120-1234567",
    //   "aadharNo": "2345-6789-0123",
    //   "preferredLanguage": ["Hindi", "English"],
    //   "jobLocation": "Noida",
    //   "linkedin": "https://linkedin.com/in/neelamgupta",
    //   "positionApplied": "Data Analyst",
    //   "hasWorkExperience": true,
    //   "yearsOfExperience": "6",
    //   "monthsOfExperience": "4",
    //   "heardAboutUs": "Company Website",
    //   "skill": "Data Analysis",
    //   "shiftType": "Full-time",
    //   "workPlace": "On-site",
    //   "employmentType": "Permanent",
    //   "profilePicture": null,
    //   "signature": null,
    //   "resume": null,
    //   "companyName": "Data Insights Ltd.",
    //   "jobRole": "Senior Data Analyst",
    //   "employmentStartDate": "2017-01-01",
    //   "employmentEndDate": "2023-05-31",
    //   "duties": "Analyzing and interpreting data for business insights",
    //   "reasonForLeaving": "Seeking growth opportunities",
    //   "collegeName": "Delhi University",
    //   "degree": "M.Sc. in Data Science",
    //   "specialization": "Data Analysis",
    //   "graduationMonth": "July",
    //   "graduationYear": "2016",
    //   "referenceName": "Anil Kapoor",
    //   "relationship": "Former Manager",
    //   "referenceMobile": "981-234-5678",
    //   "referenceEmail": "anil.kapoor@example.com",
    //   "referenceCompany": "Data Insights Ltd.",
    //   "experienceLetter": null
    // },
//     // Add more records
//   ]);

//   const handleSearchChange = (e) => setSearchTerm(e.target.value);
//   const handlePositionFilterChange = (e) => setPositionFilter(e.target.value);
//   const handleSkillFilterChange = (e) => setSkillFilter(e.target.value);
//   const handleDegreeFilterChange = (e) => setDegreeFilter(e.target.value);
//   const handleExperienceChange = (e, newValue) => setExperienceRange(newValue);

//   const handleViewDetails = (record) => {
//     setSelectedRecord(record);
//     setIsViewDetailsOpen(true);
//   };

//   const handleCloseDetails = () => {
//     setIsViewDetailsOpen(false);
//     setSelectedRecord(null);
//   };

//   const filteredRecords = jobRecords.filter((record) => {
//     const matchesSearch = Object.values(record).some((value) =>
//       value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
//     );
//     const matchesPosition = positionFilter
//       ? record.positionApplied.toLowerCase() === positionFilter.toLowerCase()
//       : true;
//       const matchesSkill = skillFilter
//       ? record.skill.toLowerCase() === skillFilter.toLowerCase()
//       : true;
//     const matchesDegree = degreeFilter
//       ? record.degree.toLowerCase() === degreeFilter.toLowerCase()
//       : true;
//     const matchesExperience = record.yearsOfExperience >= experienceRange[0] && record.yearsOfExperience <= experienceRange[1];
    
//     return matchesSearch && matchesPosition && matchesSkill && matchesDegree && matchesExperience;
//   });

//   return (
//     <Box sx={{ maxWidth: '1200px', width: '100%', marginLeft: '275px', mt: 7, backgroundColor: '#fff', p: 4, borderRadius: '10px' }}>
//       <Typography variant="h4" gutterBottom>
//         Job Records
//       </Typography>
//       <hr />
//       <Grid container spacing={2} sx={{ mb: 3 }}>
//         <Grid item xs={12} sm={6} md={2}>
//           <TextField
//             fullWidth
//             label="Search job records"
//             value={searchTerm}
//             onChange={handleSearchChange}
//           />
//         </Grid>
//         <Grid item xs={12} sm={6} md={2}>
//           <FormControl fullWidth>
//             <TextField
//               select
//               label="Position"
//               value={positionFilter}
//               onChange={handlePositionFilterChange}
//             >
//               <MenuItem value="">All Positions</MenuItem>
//               {[...new Set(jobRecords.map(record => record.positionApplied))].map((position, index) => (
//                 <MenuItem key={index} value={position}>{position}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} sm={6} md={2}>
//           <FormControl fullWidth>
//             <TextField
//               select
//               label="Skill"
//               value={skillFilter}
//               onChange={handleSkillFilterChange}
//             >
//               <MenuItem value="">All Skills</MenuItem>
//               {[...new Set(jobRecords.map(record => record.skill))].map((skill, index) => (
//                 <MenuItem key={index} value={skill}>{skill}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} sm={6} md={2}>
//           <FormControl fullWidth>
//             <TextField
//               select
//               label="Degree"
//               value={degreeFilter}
//               onChange={handleDegreeFilterChange}
//             >
//               <MenuItem value="">All Degree</MenuItem>
//               {[...new Set(jobRecords.map(record => record.degree))].map((degree, index) => (
//                 <MenuItem key={index} value={degree}>{degree}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} sm={6} md={3}>
//           <Typography gutterBottom>Experience Range (years)</Typography>
//           <Slider
//             value={experienceRange}
//             onChange={handleExperienceChange}
//             valueLabelDisplay="auto"
//             min={0}
//             max={30}
//             step={1}
//           />
//         </Grid>
//       </Grid>
//       <JobTable records={filteredRecords} onViewDetails={handleViewDetails} />
//       {selectedRecord && (
//         <ViewDetails
//           record={selectedRecord}
//           open={isViewDetailsOpen}
//           onClose={handleCloseDetails}
//         />
//       )}
//     </Box>
//   );
// }

// export default JobRecord;

import React, { useState } from 'react';
import { Box, Typography, Grid, TextField, FormControl, MenuItem, Slider, Button, Paper } from '@mui/material';
import { CSVLink } from 'react-csv';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import JobTable from './JobTable';
import ViewDetails from './ViewDetails';

function JobRecord() {
  const [searchTerm, setSearchTerm] = useState('');
  const [positionFilter, setPositionFilter] = useState('');
  const [skillFilter, setSkillFilter] = useState('');
  const [degreeFilter, setDegreeFilter] = useState('');
  const [experienceRange, setExperienceRange] = useState([0, 50]);
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [isViewDetailsOpen, setIsViewDetailsOpen] = useState(false);
  const [jobRecords] = useState([
    // Static data entries
    {
      "fullName": "Rajesh Kumar",
      "birthDate": "1985-09-15",
      "gender": "Male",
      "age": "38",
      "streetAddress": "123 MG Road",
      "streetAddress2": "Apt 101",
      "city": "Bangalore",
      "state": "Karnataka",
      "postalCode": "560001",
      "sameAsCurrent": true,
      "permanentStreetAddress": "123 MG Road",
      "permanentStreetAddress2": "Apt 101",
      "permanentCity": "Bangalore",
      "permanentState": "Karnataka",
      "permanentPostalCode": "560001",
      "email": "rajesh.kumar@example.com",
      "phoneNumber": "080-12345678",
      "aadharNo": "1234-5678-9101",
      "preferredLanguage": ["Hindi", "English"],
      "jobLocation": "Bangalore",
      "linkedin": "https://linkedin.com/in/rajeshkumar",
      "positionApplied": "Software Engineer",
      "hasWorkExperience": true,
      "yearsOfExperience": "12",
      "monthsOfExperience": "4",
      "heardAboutUs": "LinkedIn",
      "skill": "Software Development",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Tech Solutions Pvt Ltd",
      "jobRole": "Senior Developer",
      "employmentStartDate": "2010-06-01",
      "employmentEndDate": "2022-06-30",
      "duties": "Developing and maintaining software applications",
      "reasonForLeaving": "Seeking new opportunities",
      "collegeName": "Indian Institute of Technology",
      "degree": "B.Tech in Computer Science",
      "specialization": "Software Engineering",
      "graduationMonth": "May",
      "graduationYear": "2008",
      "referenceName": "Amit Sharma",
      "relationship": "Former Manager",
      "referenceMobile": "987-654-3210",
      "referenceEmail": "amit.sharma@example.com",
      "referenceCompany": "Tech Solutions Pvt Ltd",
      "experienceLetter": null
    },
    {
      "fullName": "Sonia Patel",
      "birthDate": "1990-11-20",
      "gender": "Female",
      "age": "33",
      "streetAddress": "456 Park Lane",
      "streetAddress2": "Flat 202",
      "city": "Mumbai",
      "state": "Maharashtra",
      "postalCode": "400002",
      "sameAsCurrent": true,
      "permanentStreetAddress": "456 Park Lane",
      "permanentStreetAddress2": "Flat 202",
      "permanentCity": "Mumbai",
      "permanentState": "Maharashtra",
      "permanentPostalCode": "400002",
      "email": "sonia.patel@example.com",
      "phoneNumber": "022-87654321",
      "aadharNo": "2345-6789-0123",
      "preferredLanguage": ["Marathi", "English"],
      "jobLocation": "Mumbai",
      "linkedin": "https://linkedin.com/in/soniapatel",
      "positionApplied": "Marketing Manager",
      "hasWorkExperience": true,
      "yearsOfExperience": "8",
      "monthsOfExperience": "6",
      "heardAboutUs": "Employee Referral",
      "skill": "Marketing Strategy",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Marketing Insights Pvt Ltd",
      "jobRole": "Marketing Head",
      "employmentStartDate": "2014-01-01",
      "employmentEndDate": "2022-07-31",
      "duties": "Developing and implementing marketing strategies",
      "reasonForLeaving": "Exploring new challenges",
      "collegeName": "Mumbai University",
      "degree": "MBA in Marketing",
      "specialization": "Marketing Management",
      "graduationMonth": "July",
      "graduationYear": "2013",
      "referenceName": "Ravi Desai",
      "relationship": "Former Supervisor",
      "referenceMobile": "998-877-6655",
      "referenceEmail": "ravi.desai@example.com",
      "referenceCompany": "Marketing Insights Pvt Ltd",
      "experienceLetter": null
    },
    {
      "fullName": "Amit Singh",
      "birthDate": "1983-06-05",
      "gender": "Male",
      "age": "41",
      "streetAddress": "789 Greenfield Road",
      "streetAddress2": "",
      "city": "Delhi",
      "state": "Delhi",
      "postalCode": "110001",
      "sameAsCurrent": false,
      "permanentStreetAddress": "789 Greenfield Road",
      "permanentStreetAddress2": "",
      "permanentCity": "Delhi",
      "permanentState": "Delhi",
      "permanentPostalCode": "110001",
      "email": "amit.singh@example.com",
      "phoneNumber": "011-23456789",
      "aadharNo": "3456-7890-1234",
      "preferredLanguage": ["Hindi", "English"],
      "jobLocation": "Delhi",
      "linkedin": "https://linkedin.com/in/amitsingh",
      "positionApplied": "Project Manager",
      "hasWorkExperience": true,
      "yearsOfExperience": "15",
      "monthsOfExperience": "8",
      "heardAboutUs": "Job Portal",
      "skill": "Project Management",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Innovate Solutions",
      "jobRole": "Senior Project Manager",
      "employmentStartDate": "2008-09-01",
      "employmentEndDate": "2023-05-31",
      "duties": "Overseeing project execution and team management",
      "reasonForLeaving": "Looking for new opportunities",
      "collegeName": "Delhi College of Engineering",
      "degree": "B.Tech in Civil Engineering",
      "specialization": "Construction Management",
      "graduationMonth": "June",
      "graduationYear": "2006",
      "referenceName": "Pooja Mehta",
      "relationship": "Former Colleague",
      "referenceMobile": "981-234-5678",
      "referenceEmail": "pooja.mehta@example.com",
      "referenceCompany": "Innovate Solutions",
      "experienceLetter": null
    },
    {
      "fullName": "Neha Sharma",
      "birthDate": "1989-02-22",
      "gender": "Female",
      "age": "35",
      "streetAddress": "321 Bluebell Street",
      "streetAddress2": "",
      "city": "Hyderabad",
      "state": "Telangana",
      "postalCode": "500001",
      "sameAsCurrent": true,
      "permanentStreetAddress": "321 Bluebell Street",
      "permanentStreetAddress2": "",
      "permanentCity": "Hyderabad",
      "permanentState": "Telangana",
      "permanentPostalCode": "500001",
      "email": "neha.sharma@example.com",
      "phoneNumber": "040-12345678",
      "aadharNo": "4567-8901-2345",
      "preferredLanguage": ["Telugu", "English"],
      "jobLocation": "Hyderabad",
      "linkedin": "https://linkedin.com/in/nehasharma",
      "positionApplied": "HR Executive",
      "hasWorkExperience": true,
      "yearsOfExperience": "7",
      "monthsOfExperience": "2",
      "heardAboutUs": "Company Website",
      "skill": "Human Resources",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "People First HR Solutions",
      "jobRole": "HR Manager",
      "employmentStartDate": "2015-04-01",
      "employmentEndDate": "2022-06-30",
      "duties": "Managing HR functions and recruitment",
      "reasonForLeaving": "Pursuing further education",
      "collegeName": "University of Hyderabad",
      "degree": "MBA in HR",
      "specialization": "Human Resources Management",
      "graduationMonth": "June",
      "graduationYear": "2014",
      "referenceName": "Ramesh Reddy",
      "relationship": "Former Supervisor",
      "referenceMobile": "944-556-7890",
      "referenceEmail": "ramesh.reddy@example.com",
      "referenceCompany": "People First HR Solutions",
      "experienceLetter": null
    },
    {
      "fullName": "Kiran Reddy",
      "birthDate": "1991-10-10",
      "gender": "Male",
      "age": "32",
      "streetAddress": "654 Orchid Lane",
      "streetAddress2": "Flat 303",
      "city": "Chennai",
      "state": "Tamil Nadu",
      "postalCode": "600003",
      "sameAsCurrent": false,
      "permanentStreetAddress": "654 Orchid Lane",
      "permanentStreetAddress2": "Flat 303",
      "permanentCity": "Chennai",
      "permanentState": "Tamil Nadu",
      "permanentPostalCode": "600003",
      "email": "kiran.reddy@example.com",
      "phoneNumber": "044-56789012",
      "aadharNo": "5678-9012-3456",
      "preferredLanguage": ["Tamil", "English"],
      "jobLocation": "Chennai",
      "linkedin": "https://linkedin.com/in/kiranreddy",
      "positionApplied": "Financial Analyst",
      "hasWorkExperience": true,
      "yearsOfExperience": "6",
      "monthsOfExperience": "0",
      "heardAboutUs": "Job Fair",
      "skill": "Financial Analysis",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "FinServe Solutions",
      "jobRole": "Finance Manager",
      "employmentStartDate": "2016-07-01",
      "employmentEndDate": "2022-07-31",
      "duties": "Analyzing financial data and preparing reports",
      "reasonForLeaving": "Seeking growth opportunities",
      "collegeName": "Madras University",
      "degree": "M.Com",
      "specialization": "Financial Management",
      "graduationMonth": "July",
      "graduationYear": "2015",
      "referenceName": "Suman Raj",
      "relationship": "Former Manager",
      "referenceMobile": "960-234-5678",
      "referenceEmail": "suman.raj@example.com",
      "referenceCompany": "FinServe Solutions",
      "experienceLetter": null
    },
    {
      "fullName": "Anita Desai",
      "birthDate": "1987-07-30",
      "gender": "Female",
      "age": "37",
      "streetAddress": "987 Sunset Boulevard",
      "streetAddress2": "Block B",
      "city": "Pune",
      "state": "Maharashtra",
      "postalCode": "411007",
      "sameAsCurrent": true,
      "permanentStreetAddress": "987 Sunset Boulevard",
      "permanentStreetAddress2": "Block B",
      "permanentCity": "Pune",
      "permanentState": "Maharashtra",
      "permanentPostalCode": "411007",
      "email": "anita.desai@example.com",
      "phoneNumber": "020-12345678",
      "aadharNo": "6789-0123-4567",
      "preferredLanguage": ["Marathi", "English"],
      "jobLocation": "Pune",
      "linkedin": "https://linkedin.com/in/anitadesai",
      "positionApplied": "Product Manager",
      "hasWorkExperience": true,
      "yearsOfExperience": "10",
      "monthsOfExperience": "3",
      "heardAboutUs": "Job Portal",
      "skill": "Product Management",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "ProductX Innovations",
      "jobRole": "Senior Product Manager",
      "employmentStartDate": "2012-01-01",
      "employmentEndDate": "2022-04-30",
      "duties": "Overseeing product development and strategy",
      "reasonForLeaving": "Pursuing higher studies",
      "collegeName": "Pune University",
      "degree": "MBA in Product Management",
      "specialization": "Product Strategy",
      "graduationMonth": "June",
      "graduationYear": "2011",
      "referenceName": "Ravi Kulkarni",
      "relationship": "Former Manager",
      "referenceMobile": "982-345-6789",
      "referenceEmail": "ravi.kulkarni@example.com",
      "referenceCompany": "ProductX Innovations",
      "experienceLetter": null
    },
    {
      "fullName": "Ravi Kumar",
      "birthDate": "1984-08-19",
      "gender": "Male",
      "age": "40",
      "streetAddress": "432 Hilltop Avenue",
      "streetAddress2": "Suite 501",
      "city": "Ahmedabad",
      "state": "Gujarat",
      "postalCode": "380001",
      "sameAsCurrent": false,
      "permanentStreetAddress": "432 Hilltop Avenue",
      "permanentStreetAddress2": "Suite 501",
      "permanentCity": "Ahmedabad",
      "permanentState": "Gujarat",
      "permanentPostalCode": "380001",
      "email": "ravi.kumar@example.com",
      "phoneNumber": "079-12345678",
      "aadharNo": "7890-1234-5678",
      "preferredLanguage": ["Gujarati", "English"],
      "jobLocation": "Ahmedabad",
      "linkedin": "https://linkedin.com/in/ravikumar",
      "positionApplied": "Business Analyst",
      "hasWorkExperience": true,
      "yearsOfExperience": "11",
      "monthsOfExperience": "5",
      "heardAboutUs": "Employee Referral",
      "skill": "Business Analysis",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Insight Business Solutions",
      "jobRole": "Business Analyst",
      "employmentStartDate": "2011-01-01",
      "employmentEndDate": "2022-06-30",
      "duties": "Conducting business analysis and reporting",
      "reasonForLeaving": "Looking for new challenges",
      "collegeName": "Gujarat University",
      "degree": "M.Com",
      "specialization": "Business Analysis",
      "graduationMonth": "June",
      "graduationYear": "2010",
      "referenceName": "Sandeep Patel",
      "relationship": "Former Manager",
      "referenceMobile": "961-234-5678",
      "referenceEmail": "sandeep.patel@example.com",
      "referenceCompany": "Insight Business Solutions",
      "experienceLetter": null
    },
    {
      "fullName": "Priya Nair",
      "birthDate": "1992-12-11",
      "gender": "Female",
      "age": "31",
      "streetAddress": "567 Lakeside Drive",
      "streetAddress2": "Flat 404",
      "city": "Kochi",
      "state": "Kerala",
      "postalCode": "682001",
      "sameAsCurrent": true,
      "permanentStreetAddress": "567 Lakeside Drive",
      "permanentStreetAddress2": "Flat 404",
      "permanentCity": "Kochi",
      "permanentState": "Kerala",
      "permanentPostalCode": "682001",
      "email": "priya.nair@example.com",
      "phoneNumber": "0484-1234567",
      "aadharNo": "8901-2345-6789",
      "preferredLanguage": ["Malayalam", "English"],
      "jobLocation": "Kochi",
      "linkedin": "https://linkedin.com/in/priyanair",
      "positionApplied": "Content Writer",
      "hasWorkExperience": true,
      "yearsOfExperience": "5",
      "monthsOfExperience": "9",
      "heardAboutUs": "Social Media",
      "skill": "Content Creation",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Creative Content Co.",
      "jobRole": "Senior Content Writer",
      "employmentStartDate": "2017-03-01",
      "employmentEndDate": "2023-01-31",
      "duties": "Creating and editing content for various platforms",
      "reasonForLeaving": "Exploring new opportunities",
      "collegeName": "Cochin University of Science and Technology",
      "degree": "MA in English Literature",
      "specialization": "Content Writing",
      "graduationMonth": "May",
      "graduationYear": "2016",
      "referenceName": "Rita George",
      "relationship": "Former Colleague",
      "referenceMobile": "999-123-4567",
      "referenceEmail": "rita.george@example.com",
      "referenceCompany": "Creative Content Co.",
      "experienceLetter": null
    },
    {
      "fullName": "Arun Mehta",
      "birthDate": "1982-03-17",
      "gender": "Male",
      "age": "42",
      "streetAddress": "234 Riverside Avenue",
      "streetAddress2": "Office 502",
      "city": "Jaipur",
      "state": "Rajasthan",
      "postalCode": "302001",
      "sameAsCurrent": false,
      "permanentStreetAddress": "234 Riverside Avenue",
      "permanentStreetAddress2": "Office 502",
      "permanentCity": "Jaipur",
      "permanentState": "Rajasthan",
      "permanentPostalCode": "302001",
      "email": "arun.mehta@example.com",
      "phoneNumber": "0141-2345678",
      "aadharNo": "9012-3456-7890",
      "preferredLanguage": ["Hindi", "English"],
      "jobLocation": "Jaipur",
      "linkedin": "https://linkedin.com/in/arunmehta",
      "positionApplied": "Sales Manager",
      "hasWorkExperience": true,
      "yearsOfExperience": "18",
      "monthsOfExperience": "2",
      "heardAboutUs": "Networking Event",
      "skill": "Sales Management",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Sales Pros",
      "jobRole": "Sales Director",
      "employmentStartDate": "2004-02-01",
      "employmentEndDate": "2022-04-30",
      "duties": "Managing sales teams and strategies",
      "reasonForLeaving": "Pursuing personal business",
      "collegeName": "Rajasthan University",
      "degree": "MBA in Sales",
      "specialization": "Sales and Marketing",
      "graduationMonth": "March",
      "graduationYear": "2003",
      "referenceName": "Sushil Agarwal",
      "relationship": "Former Supervisor",
      "referenceMobile": "982-345-6789",
      "referenceEmail": "sushil.agarwal@example.com",
      "referenceCompany": "Sales Pros",
      "experienceLetter": null
    },
    {
      "fullName": "Sunita Rani",
      "birthDate": "1986-05-28",
      "gender": "Female",
      "age": "38",
      "streetAddress": "123 Lotus Street",
      "streetAddress2": "Bungalow 12",
      "city": "Chandigarh",
      "state": "Chandigarh",
      "postalCode": "160001",
      "sameAsCurrent": true,
      "permanentStreetAddress": "123 Lotus Street",
      "permanentStreetAddress2": "Bungalow 12",
      "permanentCity": "Chandigarh",
      "permanentState": "Chandigarh",
      "permanentPostalCode": "160001",
      "email": "sunita.rani@example.com",
      "phoneNumber": "0172-1234567",
      "aadharNo": "0123-4567-8901",
      "preferredLanguage": ["Hindi", "English"],
      "jobLocation": "Chandigarh",
      "linkedin": "https://linkedin.com/in/sunitarani",
      "positionApplied": "Administrative Officer",
      "hasWorkExperience": true,
      "yearsOfExperience": "9",
      "monthsOfExperience": "10",
      "heardAboutUs": "Online Ad",
      "skill": "Administrative Management",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Admin Support Services",
      "jobRole": "Office Manager",
      "employmentStartDate": "2013-04-01",
      "employmentEndDate": "2023-02-28",
      "duties": "Managing office operations and administration",
      "reasonForLeaving": "Looking for career growth",
      "collegeName": "Panjab University",
      "degree": "M.Com",
      "specialization": "Office Management",
      "graduationMonth": "June",
      "graduationYear": "2012",
      "referenceName": "Rajesh Arora",
      "relationship": "Former Supervisor",
      "referenceMobile": "980-123-4567",
      "referenceEmail": "rajesh.arora@example.com",
      "referenceCompany": "Admin Support Services",
      "experienceLetter": null
    },
    {
      "fullName": "Deepak Sharma",
      "birthDate": "1988-04-15",
      "gender": "Male",
      "age": "36",
      "streetAddress": "678 Seaside Road",
      "streetAddress2": "Unit 303",
      "city": "Goa",
      "state": "Goa",
      "postalCode": "403001",
      "sameAsCurrent": true,
      "permanentStreetAddress": "678 Seaside Road",
      "permanentStreetAddress2": "Unit 303",
      "permanentCity": "Goa",
      "permanentState": "Goa",
      "permanentPostalCode": "403001",
      "email": "deepak.sharma@example.com",
      "phoneNumber": "0832-1234567",
      "aadharNo": "1234-5678-9012",
      "preferredLanguage": ["Konkani", "English"],
      "jobLocation": "Goa",
      "linkedin": "https://linkedin.com/in/deepaksharma",
      "positionApplied": "Graphic Designer",
      "hasWorkExperience": true,
      "yearsOfExperience": "7",
      "monthsOfExperience": "11",
      "heardAboutUs": "Social Media",
      "skill": "Graphic Design",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Creative Designs Studio",
      "jobRole": "Senior Graphic Designer",
      "employmentStartDate": "2015-06-01",
      "employmentEndDate": "2023-05-31",
      "duties": "Designing visual content for marketing",
      "reasonForLeaving": "Looking for new opportunities",
      "collegeName": "Goa University",
      "degree": "BFA in Graphic Design",
      "specialization": "Digital Art",
      "graduationMonth": "May",
      "graduationYear": "2014",
      "referenceName": "Manoj Kumar",
      "relationship": "Former Supervisor",
      "referenceMobile": "982-345-6789",
      "referenceEmail": "manoj.kumar@example.com",
      "referenceCompany": "Creative Designs Studio",
      "experienceLetter": null
    },
    {
      "fullName": "Neelam Gupta",
      "birthDate": "1990-09-25",
      "gender": "Female",
      "age": "33",
      "streetAddress": "345 Maple Street",
      "streetAddress2": "",
      "city": "Noida",
      "state": "Uttar Pradesh",
      "postalCode": "201301",
      "sameAsCurrent": true,
      "permanentStreetAddress": "345 Maple Street",
      "permanentStreetAddress2": "",
      "permanentCity": "Noida",
      "permanentState": "Uttar Pradesh",
      "permanentPostalCode": "201301",
      "email": "neelam.gupta@example.com",
      "phoneNumber": "0120-1234567",
      "aadharNo": "2345-6789-0123",
      "preferredLanguage": ["Hindi", "English"],
      "jobLocation": "Noida",
      "linkedin": "https://linkedin.com/in/neelamgupta",
      "positionApplied": "Data Analyst",
      "hasWorkExperience": true,
      "yearsOfExperience": "0",
      "monthsOfExperience": "4",
      "heardAboutUs": "Company Website",
      "skill": "Data Analysis",
      "shiftType": "Full-time",
      "workPlace": "On-site",
      "employmentType": "Permanent",
      "profilePicture": null,
      "signature": null,
      "resume": null,
      "companyName": "Data Insights Ltd.",
      "jobRole": "Senior Data Analyst",
      "employmentStartDate": "2017-01-01",
      "employmentEndDate": "2023-05-31",
      "duties": "Analyzing and interpreting data for business insights",
      "reasonForLeaving": "Seeking growth opportunities",
      "collegeName": "Delhi University",
      "degree": "M.Sc. in Data Science",
      "specialization": "Data Analysis",
      "graduationMonth": "July",
      "graduationYear": "2016",
      "referenceName": "Anil Kapoor",
      "relationship": "Former Manager",
      "referenceMobile": "981-234-5678",
      "referenceEmail": "anil.kapoor@example.com",
      "referenceCompany": "Data Insights Ltd.",
      "experienceLetter": null
    },
  ]);

  const handleSearchChange = (e) => setSearchTerm(e.target.value);
  const handlePositionFilterChange = (e) => setPositionFilter(e.target.value);
  const handleSkillFilterChange = (e) => setSkillFilter(e.target.value);
  const handleDegreeFilterChange = (e) => setDegreeFilter(e.target.value);
  const handleExperienceChange = (e, newValue) => setExperienceRange(newValue);

  const handleViewDetails = (record) => {
    setSelectedRecord(record);
    setIsViewDetailsOpen(true);
  };

  const handleCloseDetails = () => {
    setIsViewDetailsOpen(false);
    setSelectedRecord(null);
  };

  const filteredRecords = jobRecords.filter((record) => {
    const matchesSearch = Object.values(record).some((value) =>
      value?.toString().toLowerCase().includes(searchTerm.toLowerCase())
    );
    const matchesPosition = positionFilter
      ? record.positionApplied.toLowerCase() === positionFilter.toLowerCase()
      : true;
    const matchesSkill = skillFilter
      ? record.skill.toLowerCase() === skillFilter.toLowerCase()
      : true;
    const matchesDegree = degreeFilter
      ? record.degree.toLowerCase() === degreeFilter.toLowerCase()
      : true;
    const matchesExperience = record.yearsOfExperience >= experienceRange[0] && record.yearsOfExperience <= experienceRange[1];
    
    return matchesSearch && matchesPosition && matchesSkill && matchesDegree && matchesExperience;
  });

  const handleDownloadPDF = () => {
    const doc = new jsPDF({ orientation: 'landscape' });
    const columns = [
      { title: "Sr. No.", dataKey: "index" },
      { title: "Full Name", dataKey: "fullName" },
      { title: "Email", dataKey: "email" },
      { title: "Phone Number", dataKey: "phoneNumber" },
      { title: "Position Applied", dataKey: "positionApplied" },
      { title: "Skill", dataKey: "skill" },
      { title: "Experience", dataKey: "yearsOfExperience" },
      { title: "Degree", dataKey: "degree" }
    ];
    const rows = filteredRecords.map((record, index) => ({
      index: index + 1,
      fullName: record.fullName,
      email: record.email,
      phoneNumber: record.phoneNumber,
      positionApplied: record.positionApplied,
      skill: record.skill,
      yearsOfExperience: record.yearsOfExperience,
      degree: record.degree
    }));

    doc.autoTable(columns, rows);
    doc.save('job_records.pdf');
  };

  return (
    <Box sx={{ maxWidth: '1200px', width: '100%', marginLeft: '275px', mt: 7, backgroundColor: '#fff', p: 4, borderRadius: '10px' }}>
      <Paper sx={{ maxWidth: '1200px', width: '100%', p: 4, borderRadius: '10px', boxShadow: '0px 4px 15px rgba(0, 0, 0, 0.2)' }}>
      <Typography variant="h4" gutterBottom>
        Job Records
      </Typography>
      <hr />
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={2}>
          <TextField
            fullWidth
            label="Search job records"
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth>
            <TextField
              select
              label="Position"
              value={positionFilter}
              onChange={handlePositionFilterChange}
            >
              <MenuItem value="">All Positions</MenuItem>
              {[...new Set(jobRecords.map(record => record.positionApplied))].map((position, index) => (
                <MenuItem key={index} value={position}>{position}</MenuItem>
              ))}
            </TextField>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth>
            <TextField
              select
              label="Skill"
              value={skillFilter}
              onChange={handleSkillFilterChange}
            >
              <MenuItem value="">All Skills</MenuItem>
              {[...new Set(jobRecords.map(record => record.skill))].map((skill, index) => (
                <MenuItem key={index} value={skill}>{skill}</MenuItem>
              ))}
            </TextField>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6} md={2}>
          <FormControl fullWidth>
            <TextField
              select
              label="Degree"
              value={degreeFilter}
              onChange={handleDegreeFilterChange}
            >
              <MenuItem value="">All Degree</MenuItem>
              {[...new Set(jobRecords.map(record => record.degree))].map((degree, index) => (
                <MenuItem key={index} value={degree}>{degree}</MenuItem>
              ))}
            </TextField>
          </FormControl>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Typography gutterBottom>Experience Range (years)</Typography>
          <Slider
            value={experienceRange}
            onChange={handleExperienceChange}
            valueLabelDisplay="auto"
            min={0}
            max={30}
            step={1}
          />
        </Grid>
      </Grid>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
  <Button variant="contained" color="primary" onClick={handleDownloadPDF}>
    Download as PDF
  </Button>
  <CSVLink
    data={filteredRecords.map((record, index) => ({
      SrNo: index + 1,
      FullName: record.fullName,
      Email: record.email,
      PhoneNumber: record.phoneNumber,
      PositionApplied: record.positionApplied,
      Skill: record.skill,
      Experience: record.yearsOfExperience,
      Degree: record.degree
    }))}
    filename="job_records.csv"
  >
    <Button variant="contained" color="primary">
      Download as CSV
    </Button>
  </CSVLink>
</Box>

      <JobTable records={filteredRecords} onViewDetails={handleViewDetails} />
      {selectedRecord && (
        <ViewDetails
          record={selectedRecord}
          open={isViewDetailsOpen}
          onClose={handleCloseDetails}
        />
      )}
      </Paper>
    </Box>
  );
}

export default JobRecord;

