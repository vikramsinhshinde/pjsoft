import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import SideBar from "./SideBar";
import NavBar from "./NavBar";

const Layout = () => {
  const location = useLocation();

  // Check if the current route is the login page
  const isLoginPage = location.pathname === "/";

  return (
    <div className="d-flex">
      {!isLoginPage && <NavBar />}
      {!isLoginPage && <SideBar />}
      <main
        className={`flex-grow-1 p-3 ${!isLoginPage ? 'mt-5' : ''} ${!isLoginPage ? 'ml-5' : ''}`}
        style={{
          marginTop: !isLoginPage ? '64px' : '0', // Adjust top margin for Navbar only if not on login page
          marginLeft: !isLoginPage ? '240px' : '0' // Adjust left margin for Sidebar only if not on login page
        }}
      >
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
