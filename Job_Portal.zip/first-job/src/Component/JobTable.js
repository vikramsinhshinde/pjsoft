import React from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button } from '@mui/material';

function JobTable({ records, onDelete, onViewDetails }) {
  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead style={{ backgroundColor: '#f2f2f2' }}>
          <TableRow>
            <TableCell style={{ fontWeight: 'bold' }}>Sr. No.</TableCell>
            <TableCell style={{ fontWeight: 'bold' }}>Full Name</TableCell>
            <TableCell style={{ fontWeight: 'bold', textAlign: 'center' }}>Email</TableCell>
            <TableCell style={{ fontWeight: 'bold' }}>Phone Number</TableCell>
            <TableCell style={{ fontWeight: 'bold' }}>Position Applied</TableCell>
            <TableCell style={{ fontWeight: 'bold', textAlign: 'center' }}>Skill</TableCell>
            <TableCell style={{fontWeight:'bold', textAlign:'center'}}>Experience</TableCell>
            <TableCell style={{fontWeight:'bold', textAlign:'center'}}>Degree</TableCell>
            <TableCell style={{ fontWeight: 'bold', textAlign: 'center' }}>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {records.map((record, index) => (
            <TableRow key={index}>
              <TableCell>{index + 1}</TableCell>
              <TableCell>{record.fullName}</TableCell>
              <TableCell>{record.email}</TableCell>
              <TableCell>{record.phoneNumber}</TableCell>
              <TableCell>{record.positionApplied}</TableCell>
              <TableCell>{record.skill}</TableCell>
              <TableCell>{record.yearsOfExperience}</TableCell>
              <TableCell>{record.degree}</TableCell>
              <TableCell style={{ textAlign: 'center' }}>
                <Button
                  variant="contained"
                  color="success"
                  size="small"
                  onClick={() => onViewDetails(record)}
                >
                  View
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default JobTable;
