// import React from 'react';
// import { Drawer, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faHome, faFileAlt, faClipboardList } from '@fortawesome/free-solid-svg-icons';
// import '../CSS/SideBar.css';

// const SideBar = () => {
//   return (
//     <Drawer
//       variant="permanent"
//       sx={{
//         width: 240,
//         flexShrink: 0,
//         [`& .MuiDrawer-paper`]: {marginTop:'62px', width: 240, boxSizing: 'border-box' },
//       }}
//     >
//       <List>
//         <ListItem button component="a" href="/">
//           <ListItemIcon>
//             <FontAwesomeIcon icon={faHome} className="icon" />
//           </ListItemIcon>
//           <ListItemText primary="Home" />
//         </ListItem>
//         <ListItem button component="a" href="/JobApplicationForm">
//           <ListItemIcon>
//             <FontAwesomeIcon icon={faFileAlt} className="icon" />
//           </ListItemIcon>
//           <ListItemText primary="Application Form" />
//         </ListItem>
//         <ListItem button component="a" href="/JobRecord">
//           <ListItemIcon>
//             <FontAwesomeIcon icon={faClipboardList} className="icon" />
//           </ListItemIcon>
//           <ListItemText primary="Application Record" />
//         </ListItem>
//       </List>
//     </Drawer>
//   );
// };

// export default SideBar;


import React, { useState } from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, IconButton, Hidden, Box } from '@mui/material';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faFileAlt, faClipboardList, faBars } from '@fortawesome/free-solid-svg-icons';
import '../CSS/SideBar.css';

const SideBar = () => {
  const [open, setOpen] = useState(false);

  const handleDrawerToggle = () => {
    setOpen(!open);
  };

  const drawer = (
    <List>
      <ListItem button component="a" href="/">
        <ListItemIcon>
          <FontAwesomeIcon icon={faHome} className="icon" />
        </ListItemIcon>
        <ListItemText primary="Home" />
      </ListItem>
      <ListItem button component="a" href="/JobApplicationForm">
        <ListItemIcon>
          <FontAwesomeIcon icon={faFileAlt} className="icon" />
        </ListItemIcon>
        <ListItemText primary="Application Form" />
      </ListItem>
      <ListItem button component="a" href="/JobRecord">
        <ListItemIcon>
          <FontAwesomeIcon icon={faClipboardList} className="icon" />
        </ListItemIcon>
        <ListItemText primary="Application Record" />
      </ListItem>
    </List>
  );

  return (
    <Box sx={{ display: 'flex' }}>
      <Hidden mdUp>
        <IconButton
          color="inherit"
          aria-label="open drawer"
          edge="start"
          onClick={handleDrawerToggle}
          sx={{ marginLeft: 1, marginTop: '34px' }} // Adjust margin as necessary
        >
          <FontAwesomeIcon icon={faBars} />
        </IconButton>
      </Hidden>
      <Hidden mdUp>
        <Drawer
          variant="temporary"
          open={open}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            [`& .MuiDrawer-paper`]: {
              width: 240,
            },
          }}
        >
          {drawer}
        </Drawer>
      </Hidden>
      <Hidden mdDown>
        <Drawer
          variant="permanent"
          sx={{
            width: 240,
            flexShrink: 0,
            [`& .MuiDrawer-paper`]: {
              marginTop: '64px', // Ensure alignment with the AppBar
              width: 240,
              boxSizing: 'border-box',
            },
          }}
        >
          {drawer}
        </Drawer>
      </Hidden>
    </Box>
  );
};

export default SideBar;
