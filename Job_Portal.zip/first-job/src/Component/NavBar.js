// import React from 'react';
// import AppBar from '@mui/material/AppBar';
// import Toolbar from '@mui/material/Toolbar';
// import Typography from '@mui/material/Typography';
// import Button from '@mui/material/Button';
// import logo from '../Img/logo.jpg';
// import { Box } from '@mui/material';

// const NavBar = () => {
//   return (
//     <AppBar position="fixed" color="primary">
//       <Toolbar>
//         <Box display="flex" alignItems="center">
//           <img src={logo} alt="Jobify Logo" style={{ width: '60px', marginRight: '15px' }} />
//           <Typography variant="h6" component="div" sx={{ flexGrow: 1, marginRight: 'auto' }}>
//             PJSOFTTECH
//           </Typography>
//         </Box>
//         <Button color="inherit" sx={{ marginLeft: 'auto' }}>
//           Logout
//         </Button>
//       </Toolbar>
//     </AppBar>
//   );
// };

// export default NavBar;



import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import logo from '../Img/logo.jpg';
import { Box } from '@mui/material';

const NavBar = () => {
  return (
    <AppBar position="fixed" color="primary">
      <Toolbar>
        <Box display="flex" alignItems="center">
          <img src={logo} alt="Jobify Logo" style={{ width: '60px', marginRight: '15px' }} />
          <Typography variant="h6" component="div" sx={{ flexGrow: 1, marginRight: 'auto' }}>
            PJSOFTTECH
          </Typography>
        </Box>
        <Box sx={{ marginLeft: 'auto', display: 'flex', alignItems: 'center' }}>
          <Button color="inherit">
            Logout
          </Button>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default NavBar;
