
// import React from 'react';
// import { Grid, Paper, Typography } from '@mui/material';

// const Dashboard = () => {
//   return (
    // <Grid container spacing={3} sx={{ padding: '20px', marginLeft: { xs: '2%', md: '5%' } }}>
    //   {/* Total Applications Card */}
    //   <Grid item xs={12} sm={6} md={3}>
    //     <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#4CAF50', color: 'white' }}>
    //       <Typography variant="h5">Total Applications</Typography>
    //       <Typography variant="h4">1395</Typography>
    //     </Paper>
    //   </Grid> 

    //   {/* Last 7 Days Card */}
    //   <Grid item xs={12} sm={6} md={3}>
    //     <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#2196F3', color: 'white' }}>
    //       <Typography variant="h5">Last 7 Days</Typography>
    //       <Typography variant="h4">45</Typography>
    //     </Paper>
    //   </Grid>

    //   {/* Last 30 Days Card */}
    //   <Grid item xs={12} sm={6} md={3}>
    //     <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#FFC107', color: 'white' }}>
    //       <Typography variant="h5">Last 30 Days</Typography>
    //       <Typography variant="h4">150</Typography>
    //     </Paper>
    //   </Grid>

    //   {/* Last 365 Days Card */}
    //   <Grid item xs={12} sm={6} md={3}>
    //     <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#FF5722', color: 'white' }}>
    //       <Typography variant="h5">Last 365 Days</Typography>
    //       <Typography variant="h4">1200</Typography>
    //     </Paper>
    //   </Grid>
    // </Grid>
//   );
// };

// export default Dashboard;


import React from 'react';
import { Grid, Paper, Typography } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from 'recharts';

const Dashboard = () => {
  const positionData = [
    { name: 'Software Engineer', count: 120 },
    { name: 'Product Manager', count: 80 },
    { name: 'Data Scientist', count: 150 },
    { name: 'Designer', count: 50 },
    { name: 'QA Engineer', count: 70 }
  ];

  const degreeData = [
    { name: 'B.Tech', count: 200 },
    { name: 'M.Tech', count: 100 },
    { name: 'MBA', count: 80 },
    { name: 'PhD', count: 30 },
    { name: 'B.Sc', count: 150 }
  ];

  return (
    <Grid container spacing={3} sx={{marginTop:'5%'}}>
        <Grid container spacing={3} sx={{ padding: '20px', marginLeft: { xs: '2%', md: '15%' } }}>
      {/* Total Applications Card */}
      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#4CAF50', color: 'white' }}>
          <Typography variant="h5">Total Applications</Typography>
          <Typography variant="h4">1395</Typography>
        </Paper>
      </Grid> 

      {/* Last 7 Days Card */}
      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#2196F3', color: 'white' }}>
          <Typography variant="h5">Last 7 Days</Typography>
          <Typography variant="h4">45</Typography>
        </Paper>
      </Grid>

      {/* Last 30 Days Card */}
      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#FFC107', color: 'white' }}>
          <Typography variant="h5">Last 30 Days</Typography>
          <Typography variant="h4">150</Typography>
        </Paper>
      </Grid>

      {/* Last 365 Days Card */}
      <Grid item xs={12} sm={6} md={3}>
        <Paper sx={{ padding: '20px', textAlign: 'center', backgroundColor: '#FF5722', color: 'white' }}>
          <Typography variant="h5">Last 365 Days</Typography>
          <Typography variant="h4">1200</Typography>
        </Paper>
      </Grid>
    </Grid>
      {/* Positions Applied Bar Chart */}
      <Grid item xs={12} sx={{ padding: '20px', marginLeft: { xs: '2%', md: '15%' } }}>
      <Grid item xs={12} sx={{marginBottom:'2%'}}>
        <Paper elevation={3} style={{ padding: '20px', maxWidth: '80%',marginLeft:'20%', margin: '0 auto' }}>
          <Typography variant="h6" gutterBottom>
            Positions Applied
          </Typography>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={positionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>

      {/* Degrees Line Chart */}
      <Grid item xs={12}>
        <Paper elevation={3} style={{ padding: '20px', maxWidth: '80%',marginLeft:'20%', margin: '0 auto' }}>
          <Typography variant="h6" gutterBottom>
            Degrees
          </Typography>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={degreeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="count" stroke="#82ca9d" />
            </LineChart>
          </ResponsiveContainer>
        </Paper>
      </Grid>
    </Grid>
    </Grid>
  );
};

export default Dashboard;
