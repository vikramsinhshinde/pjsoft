// import React, { useState, useEffect } from 'react';
// import { Box, Typography, TextField, Grid, Button, FormControl, MenuItem } from '@mui/material';

// function JobEditForm({ editingIndex, initialFormData, onSubmit, onClose }) {
//   const [formData, setFormData] = useState({
//     fullName: '',
//     birthDate: '',
//     gender: '',
//     age: '',
//     streetAddress: '',
//     streetAddress2: '',
//     state: '',
//     postalCode: '',
//     sameAsCurrent:'',
//     permanentStreetAddress: '',
//     permanentStreetAddress2: '',
//     permanentState: '',
//     permanentPostalCode: '',
//     email: '',
//     preferredLanguage:'',
//     phoneNumber: '',
//     jobLocation: '',
//     linkedin: '',
//     positionApplied: '',
//     heardAboutUs: '',
//     skill: '',
//     shiftType: '',
//     workPlace: '',
//     employmentType: '',
//     profilePicture: null,
//     resume: null,
//     employmentHistory: [{ companyName: '', jobRole: '', startDate: '', endDate: '', duties: '', reasonForLeaving: '' }],
//     educationHistory: [{ collegeName: '', degree: '', specialization: '', graduationMonth: '', graduationYear: '' }],
//     references: [{ name: '', relationship: '', mobile: '', referenceEmail: '' }],
//     experienceLetter: null,
//   });

//   const months = [
//     'January', 'February', 'March', 'April', 'May', 'June',
//     'July', 'August', 'September', 'October', 'November', 'December'
// ];

// const years = Array.from({ length: 50 }, (_, i) => new Date().getFullYear() - i); // Generates last 50 years

// const languages = ['English', 'Hindi', 'Marathi'];

// const skills = [
//     'JavaScript','Photoshop','Project Management','Content Writing','Sales','Human Resources', 'Python', 'Java'
// ];

//   useEffect(() => {
//     if (initialFormData) {
//       setFormData(initialFormData);
//     }
//   }, [initialFormData]);

//   const handleChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData({
//       ...formData,
//       [name]: type === 'checkbox' ? checked : value,
//     });
//   };

//   const handleFileChange = (e) => {
//     const { name, files } = e.target;
//     setFormData({
//       ...formData,
//       [name]: files[0],
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     onSubmit(formData);
//   };

//   return (
//     <Box
//     sx={{
//       position: 'absolute',
//       top: '50%',
//       left: '50%',
//       transform: 'translate(-50%, -50%)',
//       width: 900,
//       maxHeight: '90vh', // Set a maximum height for scrolling
//       overflowY: 'auto', // Enable vertical scrolling
//       bgcolor: 'background.paper',
//       boxShadow: 24,
//       p: 4,
//       borderRadius: 2,
//     }}
//   >
//       <Typography variant="h5" style={{fontWeight:'500', textAlign:'center'}} id="modal-title">
//         {editingIndex !== null ? 'Edit Job Record' : 'Add Job Record'}
//       </Typography>
//       <hr />
//       <Box
//         component="form"
//         onSubmit={handleSubmit}
//         sx={{ mt: 2 }}
//       >
//         <Grid container spacing={2}>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Full Name"
//               name="fullName"
//               value={formData.fullName}
//               onChange={handleChange}

//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Date of Birth"
//               name="birthDate"
//               type="date"
//               value={formData.birthDate}
//               onChange={handleChange}
//               InputLabelProps={{ shrink: true }}
              
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Age"
//               name="age"
//               type="number"
//               value={formData.age}
//               onChange={handleChange}
              
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <FormControl fullWidth>
//               <TextField
//               select 
//               label="Gender"
//                 name="gender"
//                 value={formData.gender}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="Male">Male</MenuItem>
//                 <MenuItem value="Female">Female</MenuItem>
//                 <MenuItem value="Other">Other</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//                         <FormControl fullWidth required>
//                             <TextField
//                             select
//                             label="Preferred Language"
//                                 name="preferredLanguage"
//                                 value={formData.preferredLanguage}
//                                 onChange={handleChange}
//                             >
//                                 <MenuItem value=""><em>Select language</em></MenuItem>
//                                 {languages.map((language, idx) => (
//                                     <MenuItem key={idx} value={language}>{language}</MenuItem>
//                                 ))}
//                             </TextField>
//                         </FormControl>
//                     </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Street Address"
//               name="streetAddress"
//               value={formData.streetAddress}
//               onChange={handleChange}
              
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Street Address 2"
//               name="streetAddress2"
//               value={formData.streetAddress2}
//               onChange={handleChange}
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="State"
//               name="state"
//               value={formData.state}
//               onChange={handleChange}
              
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Postal Code"
//               name="postalCode"
//               value={formData.postalCode}
//               onChange={handleChange}
              
//             />
//           </Grid>
          
//               <Grid item xs={12} sm={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent Street Address"
//                   name="permanentStreetAddress"
//                   value={formData.permanentStreetAddress}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent Street Address 2"
//                   name="permanentStreetAddress2"
//                   value={formData.permanentStreetAddress2}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent State"
//                   name="permanentState"
//                   value={formData.permanentState}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} sm={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent Postal Code"
//                   name="permanentPostalCode"
//                   value={formData.permanentPostalCode}
//                   onChange={handleChange}
//                 />
//               </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Email"
//               name="email"
//               type="email"
//               value={formData.email}
//               onChange={handleChange}
              
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Phone Number"
//               name="phoneNumber"
//               value={formData.phoneNumber}
//               onChange={handleChange}
              
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="Job Location"
//               name="jobLocation"
//               value={formData.jobLocation}
//               onChange={handleChange}
//             />
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <TextField
//               fullWidth
//               label="LinkedIn Profile"
//               name="linkedin"
//               value={formData.linkedin}
//               onChange={handleChange}
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth required>
//               <TextField
//               select
//               label="Position Applied"
//                 name="positionApplied"
//                 value={formData.positionApplied}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select a position</MenuItem>
//                 <MenuItem value="Developer">Developer</MenuItem>
//                 <MenuItem value="Designer">Designer</MenuItem>
//                 <MenuItem value="Manager">Manager</MenuItem>
//                 <MenuItem value="Analyst">Analyst</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth required>
//               <TextField
//               select
//               label="How Did You Hear About Us?"
//                 name="heardAboutUs"
//                 value={formData.heardAboutUs}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select an option</MenuItem>
//                 <MenuItem value="LinkedIn">LinkedIn</MenuItem>
//                 <MenuItem value="Indeed">Indeed</MenuItem>
//                 <MenuItem value="Company Website">Company Website</MenuItem>
//                 <MenuItem value="Referral">Referral</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth required>
//               <TextField
//               select
//               label="Skills"
//                 name="skill"
//                 value={formData.skill}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select an option</MenuItem>
//                 {skills.map((skill, idx) => (
//                   <MenuItem key={idx} value={skill}>{skill}</MenuItem>
//                 ))}
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth required>
//               <TextField
//               select 
//               label="Shift Type"
//                 name="shiftType"
//                 value={formData.shiftType}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select shift type</MenuItem>
//                 <MenuItem value="Day">Day</MenuItem>
//                 <MenuItem value="Night">Night</MenuItem>
//                 <MenuItem value="Rotational">Rotational</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth required>
//               <TextField
//               select
//               label="Workplace"
//                 name="workPlace"
//                 value={formData.workPlace}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select workplace</MenuItem>
//                 <MenuItem value="On-site">On-site</MenuItem>
//                 <MenuItem value="Remote">Remote</MenuItem>
//                 <MenuItem value="Hybrid">Hybrid</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//               select 
//               label="Employment Type"
//                 name="employmentType"
//                 value={formData.employmentType}
//                 onChange={handleChange}
//               >
//                 <MenuItem value="">Select employment type</MenuItem>
//                 <MenuItem value="Full-time">Full-time</MenuItem>
//                 <MenuItem value="Part-time">Part-time</MenuItem>
//                 <MenuItem value="Contract">Contract</MenuItem>
//                 <MenuItem value="Temporary">Temporary</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} sm={12}>
//             <Typography variant="h6">Employment History</Typography>
//             <Grid container spacing={3} className="mb-4">
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Company Name"
//                 name="companyName"
//                 value={formData.companyName}
//                 onChange={handleChange}
                
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Job Role"
//                 name="jobRole"
//                 value={formData.jobRole}
//                 onChange={handleChange}
                
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Reason for Leaving"
//                 name="reasonForLeaving"
//                 value={formData.reasonForLeaving}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Start Date"
//                 type="date"
//                 name="startDate"
//                 value={formData.startDate}
//                 onChange={handleChange}
                
//                 InputLabelProps={{ shrink: true }}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="End Date"
//                 type="date"
//                 name="endDate"
//                 value={formData.endDate}
//                 onChange={handleChange}
//                 InputLabelProps={{ shrink: true }}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Primary Duties"
//                 name="duties"
//                 value={formData.duties}
//                 onChange={handleChange}
                
//               />
//             </Grid>
//           </Grid>
//           </Grid>
//           <Grid item xs={12} sm={12}>
//             <Typography variant="h6">Education History</Typography>
//             <Grid container spacing={2} >
//                         <Grid item xs={12} md={4}>
//                             <TextField
//                                 fullWidth
//                                 label="College Name"
//                                 name="collegeName"
//                                 value={formData.collegeName}
//                                 onChange={handleChange}
                                
//                             />
//                         </Grid>
//                         <Grid item xs={12} md={4}>
//                             <TextField
//                                 fullWidth
//                                 label="Degree"
//                                 name="degree"
//                                 value={formData.degree}
//                                 onChange={handleChange}
                                
//                             />
//                         </Grid>
//                         <Grid item xs={12} md={4}>
//                             <TextField
//                                 fullWidth
//                                 label="Specialization"
//                                 name="specialization"
//                                 value={formData.specialization}
//                                 onChange={handleChange}
                                
//                             />
//                         </Grid>
//                         <Grid item xs={12} md={4}>
//                             <FormControl fullWidth >
//                                 <TextField
//                                 select
//                                 label="Graduation Month"
//                                     name="graduationMonth"
//                                     value={formData.graduationMonth}
//                                     onChange={handleChange}
//                                 >
//                                     <MenuItem value=""><em>Select month</em></MenuItem>
//                                     {months.map((month, idx) => (
//                                         <MenuItem key={idx} value={month}>{month}</MenuItem>
//                                     ))}
//                                 </TextField>
//                             </FormControl>
//                         </Grid>
//                         <Grid item xs={12} md={4}>
//                             <FormControl fullWidth >
//                                 <TextField
//                                 select
//                                 label="Graduation Year"
//                                     name="graduationYear"
//                                     value={formData.graduationYear}
//                                     onChange={handleChange}
//                                 >
//                                     <MenuItem value=""><em>Select year</em></MenuItem>
//                                     {years.map((year, idx) => (
//                                         <MenuItem key={idx} value={year}>{year}</MenuItem>
//                                     ))}
//                                 </TextField>
//                             </FormControl>
//                         </Grid>
//                     </Grid>
//           </Grid>
//           <Grid item xs={12} sm={12}>
//             <Typography variant="h6">References</Typography>
//             <Grid container spacing={3} className="mb-4">
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Name"
//                 name="name"
//                 value={formData.name}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Relationship"
//                 name="relationship"
//                 value={formData.relationship}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Mobile"
//                 name="mobile"
//                 value={formData.mobile}
//                 onChange={handleChange}
//               />
//             </Grid>
//             <Grid item xs={12} md={4}>
//               <TextField
//                 fullWidth
//                 label="Email"
//                 type="email"
//                 name="referenceEmail"
//                 value={formData.referenceEmail}
//                 onChange={handleChange}              />
//             </Grid>
//           </Grid>
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <input
//               type="file"
//               name="profilePicture"
//               onChange={handleFileChange}
//             />
//             <Typography variant="body2">Profile Picture</Typography>
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <input
//               type="file"
//               name="resume"
//               onChange={handleFileChange}
//             />
//             <Typography variant="body2">Resume</Typography>
//           </Grid>
//           <Grid item xs={12} sm={4}>
//             <input
//               type="file"
//               name="experienceLetter"
//               onChange={handleFileChange}
//             />
//             <Typography variant="body2">Experience Letter</Typography>
//           </Grid>
//         </Grid>
//         <Box sx={{ mt: 2, ml:35 }}>
//           <Button variant="contained" color="primary" type="submit">
//             {editingIndex !== null ? 'Update' : 'Add Record'}
//           </Button>
//           <Button variant="contained" color="error" onClick={onClose} sx={{ ml: 2 }}>
//             Cancel
//           </Button>
//         </Box>
//       </Box>
//     </Box>
//   );
// }

// export default JobEditForm;

import React from 'react';
import { Typography, Grid, Button, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';

function ViewDetails({ record, open, onClose }) {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle sx={{ textAlign:"center", fontWeight: 'bold'}}>Job Record Details</DialogTitle>
      <DialogContent dividers>
        <Grid container spacing={2}>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Full Name:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.fullName}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Birth Date:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.birthDate}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Gender:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.gender}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Age:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.age}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Street Address:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.streetAddress}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Street Address 2:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.streetAddress2}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>City:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.city}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>State:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.state}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Postal Code:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.postalCode}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Permanent Street Address:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.permanentStreetAddress}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Permanent Street Address 2:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.permanentStreetAddress2}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Permanent City:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.permanentCity}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Permanent State:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.permanentState}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Permanent Postal Code:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.permanentPostalCode}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Email:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.email}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Phone Number:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.phoneNumber}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Aadhar No:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.aadharNo}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Preferred Language:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">
                {Array.isArray(record.preferredLanguage) ? record.preferredLanguage.join(', ') : record.preferredLanguage}
              </Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Job Location:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.jobLocation}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>LinkedIn:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.linkedin}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Position Applied:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.positionApplied}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Has Work Experience:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.hasWorkExperience ? 'Yes' : 'No'}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Years of Experience:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.yearsOfExperience}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Months of Experience:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.monthsOfExperience}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Heard About Us:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.heardAboutUs}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Skill:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.skill}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Shift Type:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.shiftType}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Work Place:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.workPlace}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Employment Type:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.employmentType}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Company Name:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.companyName}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Job Role:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.jobRole}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Employment Start Date:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.employmentStartDate}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Employment End Date:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.employmentEndDate}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Duties:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.duties}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Reason for Leaving:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.reasonForLeaving}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>College Name:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.collegeName}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Degree:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.degree}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Specialization:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.specialization}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Graduation Month:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.graduationMonth}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Graduation Year:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.graduationYear}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Reference Name:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.referenceName}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Reference Email:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.referenceEmail}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Relationship:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.relationship}</Typography>
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Reference Mobile:</Typography>
            </Grid>
            <Grid item>
              <Typography variant="body1">{record.referenceMobile}</Typography>
            </Grid>
          </Grid>
          {/* <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Profile Picture:</Typography>
            </Grid>
            <Grid item>
              {record.profilePicture ? (
                <img src={record.profilePicture} alt="Profile" width="100" />
              ) : (
                <Typography variant="body1">No profile picture available</Typography>
              )}
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Resume:</Typography>
            </Grid>
            <Grid item>
              {record.resume ? (
                <a href={record.resume} target="_blank" rel="noopener noreferrer">View Resume</a>
              ) : (
                <Typography variant="body1">No resume available</Typography>
              )}
            </Grid>
          </Grid>
          <Grid container item xs={12} sm={6} spacing={2} alignItems="center">
            <Grid item>
              <Typography variant="subtitle2" sx={{ fontWeight: 'bold' }}>Experience Letter:</Typography>
            </Grid>
            <Grid item>
              {record.experienceLetter ? (
                <a href={record.experienceLetter} target="_blank" rel="noopener noreferrer">View Experience Letter</a>
              ) : (
                <Typography variant="body1">No experience letter available</Typography>
              )}
            </Grid>
          </Grid> */}
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose} variant='contained' color="primary">Close</Button>
      </DialogActions>
    </Dialog>
  );
}

export default ViewDetails;

