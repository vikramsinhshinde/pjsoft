// import React, { useState } from 'react';
// import { Container, Row, Col, Button, Form, Card, Pagination, OverlayTrigger, Tooltip } from 'react-bootstrap';
// import { FaTh, FaList, FaMapMarkerAlt, FaDollarSign, FaClock } from 'react-icons/fa';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import '../CSS/job.css';

// const Job = () => {
//   const [selectedSort, setSelectedSort] = useState('Newest');
//   const [searchText, setSearchText] = useState('');
//   const [jobTypes, setJobTypes] = useState({
//     partTime: false,
//     fullTime: false,
//     freelance: false,
//     internship: false,
//   });
//   const [radius, setRadius] = useState(50);
//   const [salaryRange, setSalaryRange] = useState([1000, 10000]);
//   const [viewMode, setViewMode] = useState('list');

//   const handleSortChange = (event) => setSelectedSort(event.target.value);
//   const handleSearchChange = (event) => setSearchText(event.target.value);
//   const handleJobTypeChange = (event) => {
//     const { name, checked } = event.target;
//     setJobTypes((prevTypes) => ({ ...prevTypes, [name]: checked }));
//   };
//   const handleRadiusChange = (event) => setRadius(event.target.value);
//   const handleSalaryChange = (index, value) => {
//     const newRange = [...salaryRange];
//     newRange[index] = value;
//     setSalaryRange(newRange);
//   };
//   const toggleViewMode = (mode) => setViewMode(mode);

//   const jobData = [
//     {
//       company: 'Google',
//       title: 'Web Development',
//       tags: ['Technology', 'WordPress'],
//       location: 'Mountain',
//       salary: '$5000',
//       type: 'Freelance',
//       logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/google.png',
//     },
//     {
//       company: 'Apple',
//       title: 'Software Engineer',
//       tags: ['iOS', 'Swift'],
//       location: 'Cupertino',
//       salary: '$8000',
//       type: 'Full Time',
//       logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/apple.png',
//     },
//     {
//       company: 'Amazon',
//       title: 'Backend Developer',
//       tags: ['Node.js', 'AWS'],
//       location: 'Seattle',
//       salary: '$7500',
//       type: 'Contract',
//       logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/amazon.png',
//     },
//     {
//       company: 'Microsoft',
//       title: 'Frontend Developer',
//       tags: ['React', 'CSS'],
//       location: 'Redmond',
//       salary: '$7000',
//       type: 'Part Time',
//       logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/microsoft.png',
//     },
//     {
//       company: 'Facebook',
//       title: 'Data Scientist',
//       tags: ['Python', 'Machine Learning'],
//       location: 'Menlo Park',
//       salary: '$9000',
//       type: 'Full Time',
//       logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjvzC_QRv6moAhgNb5C6e3yicKgFND1g2RwA&s',
//     },
//     {
//       company: 'Netflix',
//       title: 'DevOps Engineer',
//       tags: ['Docker', 'Kubernetes'],
//       location: 'Los Gatos',
//       salary: '$9500',
//       type: 'Full Time',
//       logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGZhYUrmk6vDmi1-Pj7oI-HzTpQDCi9-IFTA&s',
//     },
//   ];

//   const filteredJobs = jobData.filter(job => {
//     const salary = Number(job.salary.replace('$', ''));
//     return salary >= salaryRange[0] && salary <= salaryRange[1];
//   });

//   return (
//     <Container>
//       <Row>
//         {/* Left Section */}
//         <Col md={7}>
//           <div className="d-flex align-items-center mb-3">
//             <Button variant="light" className="mr-2" onClick={() => toggleViewMode('grid')}>
//               <FaTh />
//             </Button>
//             <Button variant="light" className="mr-2" onClick={() => toggleViewMode('list')}>
//               <FaList />
//             </Button>
//             <div className="text-section mb-3">
//               <p className="mb-0">There are {filteredJobs.length} Products.</p>
//             </div>
//             <div className="sort-by-container ms-auto">
//               <Form.Group className="d-flex align-items-center">
//                 <Form.Label className="mb-0 me-2">Sort by:</Form.Label>
//                 <Form.Control
//                   as="select"
//                   value={selectedSort}
//                   onChange={handleSortChange}
//                   className="me-2"
//                 >
//                   <option>Select Category</option>
//                   <option>Web Development</option>
//                   <option>UI/UX Designer</option>
//                 </Form.Control>
//               </Form.Group>
//             </div>
//           </div>
//           <Row>
//             {viewMode === 'grid' ? (
//               filteredJobs.map((job, index) => (
//                 <Col md={4} className="mb-3" key={index}>
//                   <Card className="job-card">
//                     <Card.Body>
//                       <Card.Img variant="top" src={job.logo} className="job-logo-img mb-3" />
//                       <Card.Title>{job.title}</Card.Title>
//                       <Card.Subtitle className="mb-2 text-muted">{job.company}</Card.Subtitle>
//                       <div className="job-tags mb-2">
//                         {job.tags.map((tag, idx) => (
//                           <Button key={idx} variant="light" size="sm" className="me-2 mb-2">
//                             {tag}
//                           </Button>
//                         ))}
//                       </div>
//                       <div className="job-details">
//                         <div className="mb-2">
//                           <FaMapMarkerAlt /> {job.location}
//                         </div>
//                         <div className="mb-2">
//                           <FaDollarSign /> {job.salary}
//                         </div>
//                         <div>
//                           <FaClock /> {job.type}
//                         </div>
//                       </div>
//                       <Button variant="primary" className="mt-3">Apply</Button>
//                     </Card.Body>
//                   </Card>
//                 </Col>
//               ))
//             ) : (
//               filteredJobs.map((job, index) => (
//                 <Col md={12} className="mb-3" key={index}>
//                   <Card className="job-card">
//                     <Card.Body className="d-flex">
//                       <div className="job-logo me-3">
//                         <Card.Img variant="top" src={job.logo} className="job-logo-img" />
//                       </div>
//                       <div className="job-info flex-grow-1">
//                         <Card.Title>{job.title}</Card.Title>
//                         <Card.Subtitle className="mb-2 text-muted">{job.company}</Card.Subtitle>
//                         <div className="job-tags mb-2">
//                           {job.tags.map((tag, idx) => (
//                             <Button key={idx} variant="light" size="sm" className="me-2">
//                               {tag}
//                             </Button>
//                           ))}
//                         </div>
//                         <div className="vertical-line"></div>
//                         <div className="job-details d-flex">
//                           <div className="me-3">
//                             <FaMapMarkerAlt /> {job.location}
//                           </div>
//                           <div className="me-3">
//                             <FaDollarSign /> {job.salary}
//                           </div>
//                           <div>
//                             <FaClock /> {job.type}
//                           </div>
//                         </div>
//                       </div>
//                       <div className="apply-button">
//                         <Button variant="primary">Apply</Button>
//                       </div>
//                     </Card.Body>
//                   </Card>
//                 </Col>
//               ))
//             )}
//           </Row>
//           <Pagination className="justify-content-center mt-3">
//             <Pagination.Prev />
//             <Pagination.Item active>1</Pagination.Item>
//             <Pagination.Item>2</Pagination.Item>
//             <Pagination.Item>3</Pagination.Item>
//             <Pagination.Next />
//           </Pagination>
//         </Col>

//         {/* Right Section */}
//         <Col md={5}>
//           <div className="right-section">
//             <h4>Keywords</h4>
//             <Form.Control
//               type="text"
//               placeholder="Job Keywords..."
//               value={searchText}
//               onChange={handleSearchChange}
//             />
//             <h4 className="mt-4">Search By Radius</h4>
//             <OverlayTrigger
//               placement="top"
//               overlay={<Tooltip>{radius} </Tooltip>}
//             >
//               <Form.Range value={radius} onChange={handleRadiusChange} />
//             </OverlayTrigger>
//             <h4 className="mt-4">Job Type</h4>
//             <Form.Check
//               type="checkbox"
//               label="Freelance"
//               name="freelance"
//               checked={jobTypes.freelance}
//               onChange={handleJobTypeChange}
//             />
//             <Form.Check
//               type="checkbox"
//               label="Full Time"
//               name="fullTime"
//               checked={jobTypes.fullTime}
//               onChange={handleJobTypeChange}
//             />
//             <Form.Check
//               type="checkbox"
//               label="Part Time"
//               name="partTime"
//               checked={jobTypes.partTime}
//               onChange={handleJobTypeChange}
//             />
//             <Form.Check
//               type="checkbox"
//               label="Internship"
//               name="internship"
//               checked={jobTypes.internship}
//               onChange={handleJobTypeChange}
//             />
//             <h4 className="mt-4">Categories</h4>
//             <Form.Control as="select">
//               <option>All category</option>
//               <option>Health Care</option>
//               <option>Management</option>
//               <option>UI/UX Developer</option>
//               <option>Graphic Designer</option>
//             </Form.Control>
//             <h4 className="mt-4">Filter By Salary</h4>
//             <div className="d-flex justify-content-between">
//               <span>${salaryRange[0]}</span>
//               <span>${salaryRange[1]}</span>
//             </div>
//             <Form.Range
//               value={salaryRange[0]}
//               onChange={(e) => handleSalaryChange(0, Number(e.target.value))}
//               min={0}
//               max={20000}
//               step={100}
//               className="salary-range-slider"
//             />
//             <Form.Range
//               value={salaryRange[1]}
//               onChange={(e) => handleSalaryChange(1, Number(e.target.value))}
//               min={0}
//               max={20000}
//               step={100}
//               className="salary-range-slider"
//             />
//             <h4 className="mt-4">Filter By Tag:</h4>
//             <div className="d-flex flex-wrap">
//               {['Development', 'UI/UX', 'Devops', 'Design', 'Mobile App', 'Programming', 'HTML', 'C++'].map((tag, index) => (
//                 <Button key={index} variant="light" size="sm" className="me-2 mb-2">
//                   {tag}
//                 </Button>
//               ))}
//             </div>
//           </div>
//         </Col>
//       </Row>
//     </Container>
//   );
// };

// export default Job;

import React, { useState } from 'react';
import { Container, Row, Col, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../CSS/job.css';
import JobList from './JobList';
import Filter from './Filter';

const Job = () => {
  const [selectedSort, setSelectedSort] = useState('Newest');
  const [searchText, setSearchText] = useState('');
  const [jobTypes, setJobTypes] = useState({
    partTime: false,
    fullTime: false,
    freelance: false,
    internship: false,
  });
  const [radius, setRadius] = useState(50);
  const [salaryRange, setSalaryRange] = useState([1000, 10000]);
  const [viewMode, setViewMode] = useState('list');

  const handleSortChange = (event) => setSelectedSort(event.target.value);
  const handleSearchChange = (event) => setSearchText(event.target.value);
  const handleJobTypeChange = (event) => {
    const { name, checked } = event.target;
    setJobTypes((prevTypes) => ({ ...prevTypes, [name]: checked }));
  };
  const handleRadiusChange = (event) => setRadius(event.target.value);
  const handleSalaryChange = (index, value) => {
    const newRange = [...salaryRange];
    newRange[index] = value;
    setSalaryRange(newRange);
  };
  const toggleViewMode = (mode) => setViewMode(mode);

  const jobData = [
    {
      company: 'Google',
      title: 'Web Development',
      tags: ['Technology', 'WordPress'],
      location: 'Mountain',
      salary: '$5000',
      type: 'Freelance',
      logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/google.png',
    },
    {
      company: 'Apple',
      title: 'Software Engineer',
      tags: ['iOS', 'Swift'],
      location: 'Cupertino',
      salary: '$8000',
      type: 'Full Time',
      logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/apple.png',
    },
    {
      company: 'Amazon',
      title: 'Backend Developer',
      tags: ['Node.js', 'AWS'],
      location: 'Seattle',
      salary: '$7500',
      type: 'Contract',
      logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/amazon.png',
    },
    {
      company: 'Microsoft',
      title: 'Frontend Developer',
      tags: ['React', 'CSS'],
      location: 'Redmond',
      salary: '$7000',
      type: 'Part Time',
      logo: 'https://jobslab-reactjs.netlify.app/assets/img/job/microsoft.png',
    },
    {
      company: 'Facebook',
      title: 'Data Scientist',
      tags: ['Python', 'Machine Learning'],
      location: 'Menlo Park',
      salary: '$9000',
      type: 'Full Time',
      logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjvzC_QRv6moAhgNb5C6e3yicKgFND1g2RwA&s',
    },
    {
      company: 'Netflix',
      title: 'DevOps Engineer',
      tags: ['Docker', 'Kubernetes'],
      location: 'Los Gatos',
      salary: '$9500',
      type: 'Full Time',
      logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGZhYUrmk6vDmi1-Pj7oI-HzTpQDCi9-IFTA&s',
    },
  ];

  const filteredJobs = jobData.filter(job => {
    const salary = Number(job.salary.replace('$', ''));
    return salary >= salaryRange[0] && salary <= salaryRange[1];
  });

  return (
    <Container>
      <Row>
        <Col md={7}>
          <JobList
            viewMode={viewMode}
            toggleViewMode={toggleViewMode}
            filteredJobs={filteredJobs}
            selectedSort={selectedSort}
            handleSortChange={handleSortChange}
          />
        </Col>
        <Col md={5}>
          <Filter
            searchText={searchText}
            handleSearchChange={handleSearchChange}
            jobTypes={jobTypes}
            handleJobTypeChange={handleJobTypeChange}
            radius={radius}
            handleRadiusChange={handleRadiusChange}
            salaryRange={salaryRange}
            handleSalaryChange={handleSalaryChange}
          />
        </Col>
      </Row>
    </Container>
  );
};

export default Job;
