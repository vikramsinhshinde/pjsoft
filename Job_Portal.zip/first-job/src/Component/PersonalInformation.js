// import React from 'react';
// import {
//     Container,
//     Grid,
//     TextField,
//     FormControl,
//     InputLabel,
//     Select,
//     MenuItem,
//     Checkbox,
//     FormControlLabel,
//     Typography
// } from '@mui/material';

// const months = [
//     'January', 'February', 'March', 'April', 'May', 'June',
//     'July', 'August', 'September', 'October', 'November', 'December'
// ];

// const years = Array.from({ length: 50 }, (_, i) => new Date().getFullYear() - i); // Generates last 50 years

// const languages = ['English', 'Hindi', 'Marathi'];

// function PersonalInformation({ formData, handleChange, handleBirthDateChange, handleAddressCheckboxChange }) {
//     return (
//         <>
//             <Typography variant="h4">Personal Details</Typography>
//             <Container className="mb-4">
//                 <Grid container spacing={2}>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Full Name"
//                             name="fullName"
//                             value={formData.fullName}
//                             onChange={handleChange}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Birth Date"
//                             type="date"
//                             name="birthDate"
//                             value={formData.birthDate}
//                             onChange={handleBirthDateChange}
//                             InputLabelProps={{ shrink: true }}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Age"
//                             name="age"
//                             value={formData.age}
//                             InputProps={{ readOnly: true }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <FormControl fullWidth >
//                             <InputLabel>Gender</InputLabel>
//                             <Select
//                                 name="gender"
//                                 value={formData.gender}
//                                 onChange={handleChange}
//                             >
//                                 <MenuItem value=""><em>Select gender</em></MenuItem>
//                                 <MenuItem value="Male">Male</MenuItem>
//                                 <MenuItem value="Female">Female</MenuItem>
//                                 <MenuItem value="Other">Other</MenuItem>
//                             </Select>
//                         </FormControl>
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <FormControl fullWidth >
//                             <TextField
//                             select
//                             label="Preferred Language"
//                                 name="preferredLanguage"
//                                 value={formData.preferredLanguage}
//                                 onChange={handleChange}
//                             >
//                                 <MenuItem value=""><em>Select language</em></MenuItem>
//                                 {languages.map((language, idx) => (
//                                     <MenuItem key={idx} value={language}>{language}</MenuItem>
//                                 ))}
//                             </TextField>
//                         </FormControl>
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Email"
//                             type="email"
//                             name="email"
//                             value={formData.email}
//                             onChange={handleChange}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Phone Number"
//                             name="phoneNumber"
//                             value={formData.phoneNumber}
//                             onChange={handleChange}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="LinkedIn Profile"
//                             type="url"
//                             name="linkedin"
//                             value={formData.linkedin}
//                             onChange={handleChange}
//                         />
//                     </Grid>
//                 </Grid>
//                 <Typography variant="h5" style={{ marginTop: '20px' }}>Current Address</Typography>
//                 <Grid container spacing={2}>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Street Address"
//                             name="streetAddress"
//                             value={formData.streetAddress}
//                             onChange={handleChange}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Street Address Line 2"
//                             name="streetAddress2"
//                             value={formData.streetAddress2}
//                             onChange={handleChange}
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="State / Province"
//                             name="state"
//                             value={formData.state}
//                             onChange={handleChange}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Postal / Zip Code"
//                             name="postalCode"
//                             value={formData.postalCode}
//                             onChange={handleChange}
//
//                         />
//                     </Grid>
//                     <Grid item xs={12}>
//                         <FormControlLabel
//                             control={
//                                 <Checkbox
//                                     name="sameAsCurrent"
//                                     checked={formData.sameAsCurrent}
//                                     onChange={handleAddressCheckboxChange}
//                                 />
//                             }
//                             label="Permanent address is same as current address"
//                         />
//                     </Grid>
//                 </Grid>
//                 <Typography variant="h5" style={{marginTop: '20px' }}>Permanent Address</Typography>
//                 <Grid container spacing={2}>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Street Address"
//                             name="permanentStreetAddress"
//                             value={formData.permanentStreetAddress}
//                             onChange={handleChange}
//                             ={!formData.sameAsCurrent}
//                             InputProps={{ readOnly: formData.sameAsCurrent }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Street Address Line 2"
//                             name="permanentStreetAddress2"
//                             value={formData.permanentStreetAddress2}
//                             onChange={handleChange}
//                             InputProps={{ readOnly: formData.sameAsCurrent }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="State / Province"
//                             name="permanentState"
//                             value={formData.permanentState}
//                             onChange={handleChange}
//                             ={!formData.sameAsCurrent}
//                             InputProps={{ readOnly: formData.sameAsCurrent }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} md={4}>
//                         <TextField
//                             fullWidth
//                             label="Postal / Zip Code"
//                             name="permanentPostalCode"
//                             value={formData.permanentPostalCode}
//                             onChange={handleChange}
//                             ={!formData.sameAsCurrent}
//                             InputProps={{ readOnly: formData.sameAsCurrent }}
//                         />
//                     </Grid>
//                 </Grid>
// <Typography variant="h5" style={{ marginTop: '20px' }}>Education History</Typography>
//     <Grid container spacing={2}>
//         <Grid item xs={12} md={4}>
//             <TextField
//                 fullWidth
//                 label="College Name"
//                 name="collegeName"
//                 value={formData.collegeName}
//                 onChange={handleChange}
//
//             />
//         </Grid>
//         <Grid item xs={12} md={4}>
//             <TextField
//                 fullWidth
//                 label="Degree"
//                 name="degree"
//                 value={formData.degree}
//                 onChange={handleChange}
//
//             />
//         </Grid>
//         <Grid item xs={12} md={4}>
//             <TextField
//                 fullWidth
//                 label="Specialization"
//                 name="specialization"
//                 value={formData.specialization}
//                 onChange={handleChange}
//
//             />
//         </Grid>
//         <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//                 <TextField
//                 select
//                 label="Graduation Month"
//                     name="graduationMonth"
//                     value={formData.graduationMonth}
//                     onChange={handleChange}
//                 >
//                     <MenuItem value=""><em>Select month</em></MenuItem>
//                     {months.map((month, idx) => (
//                         <MenuItem key={idx} value={month}>{month}</MenuItem>
//                     ))}
//                 </TextField>
//             </FormControl>
//         </Grid>
//         <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//                 <TextField
//                 select
//                 label="Graduation Year"
//                     name="graduationYear"
//                     value={formData.graduationYear}
//                     onChange={handleChange}
//                 >
//                     <MenuItem value=""><em>Select year</em></MenuItem>
//                     {years.map((year, idx) => (
//                         <MenuItem key={idx} value={year}>{year}</MenuItem>
//                     ))}
//                 </TextField>
//             </FormControl>
//         </Grid>
//     </Grid>
//             </Container>
//         </>
//     );
// }

// export default PersonalInformation;

// import React, {useState, useEffect} from 'react';
// import {
//   Container,
//   Grid,
//   TextField,
//   FormControl,
//   MenuItem,
//   Checkbox,
//   FormControlLabel,
//   Typography
// } from '@mui/material';
// import { State, City } from 'country-state-city';

// const months = [
//   'January', 'February', 'March', 'April', 'May', 'June',
//   'July', 'August', 'September', 'October', 'November', 'December'
// ];

// const years = Array.from({ length: 40 }, (_, i) => new Date().getFullYear() - i); // Generates last 50 years

// function PersonalInformation({ formData, handleChange, handleBirthDateChange, handleAddressCheckboxChange, setShowLanguageModal }) {
//   const [states, setStates] = useState([]);
//   const [cities, setCities] = useState([]);
//   const [permanentStates, setPermanentStates] = useState([]);
//   const [permanentCities, setPermanentCities] = useState([]);

//   useEffect(() => {
//     // Update states and cities for current address
//     if (formData.state) {
//       const selectedState = State.getStatesOfCountry('IN').find(state => state.name === formData.state);
//       if (selectedState) {
//         setCities(City.getCitiesOfState('IN', selectedState.isoCode));
//       }
//     } else {
//       setCities([]);
//     }

//     // Update states and cities for permanent address
//     if (formData.permanentState) {
//       const selectedPermanentState = State.getStatesOfCountry('IN').find(state => state.name === formData.permanentState);
//       if (selectedPermanentState) {
//         setPermanentCities(City.getCitiesOfState('IN', selectedPermanentState.isoCode));
//       }
//     } else {
//       setPermanentCities([]);
//     }
//   }, [formData.state, formData.permanentState]);

//   useEffect(() => {
//     // Load states when component mounts
//     setStates(State.getStatesOfCountry('IN'));
//     setPermanentStates(State.getStatesOfCountry('IN'));
//   }, []);
//   return (
//     <>
//       <Typography variant="h4">Personal Details</Typography>
//       <Container className="mb-4">
//         <Grid container spacing={2}>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Full Name"
//               name="fullName"
//               value={formData.fullName}
//               onChange={handleChange}
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Birth Date"
//               type="date"
//               name="birthDate"
//               value={formData.birthDate}
//               onChange={handleBirthDateChange}
//               InputLabelProps={{ shrink: true }}
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Age"
//               name="age"
//               value={formData.age}
//               InputProps={{ readOnly: true }}
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//                 select
//                 label="Gender"
//                 name="gender"
//                 value={formData.gender}
//                 onChange={handleChange}
//               >
//                 <MenuItem value=""><em>Select gender</em></MenuItem>
//                 <MenuItem value="Male">Male</MenuItem>
//                 <MenuItem value="Female">Female</MenuItem>
//                 <MenuItem value="Other">Other</MenuItem>
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Aadhar Number"
//               name="aadharNo"
//               value={formData.aadharNo}
//               onChange={handleChange}
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Preferred Language"
//               name="preferredLanguage"
//               value={formData.preferredLanguage.join(', ')}
//               onClick={() => setShowLanguageModal(true)} // Open modal on click
//               readOnly
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Email"
//               type="email"
//               name="email"
//               value={formData.email}
//               onChange={handleChange}
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Phone Number"
//               name="phoneNumber"
//               value={formData.phoneNumber}
//               onChange={handleChange}
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="LinkedIn Profile"
//               type="url"
//               name="linkedin"
//               value={formData.linkedin}
//               onChange={handleChange}
//             />
//           </Grid>
//         </Grid>
//         <Typography variant="h5" style={{ marginTop: '20px' }}>Current Address</Typography>
//         <Grid container spacing={2}>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Street Address"
//               name="streetAddress"
//               value={formData.streetAddress}
//               onChange={handleChange}
//
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Street Address 2"
//               name="streetAddress2"
//               value={formData.streetAddress2}
//               onChange={handleChange}
//             />
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//                 select
//                 label="State"
//                 name="state"
//                 value={formData.state}
//                 onChange={handleChange}
//               >
//                 <MenuItem value=""><em>Select state</em></MenuItem>
//                 {states.map((state) => (
//                   <MenuItem key={state.isoCode} value={state.name}>{state.name}</MenuItem>
//                 ))}
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <FormControl fullWidth >
//               <TextField
//                 select
//                 label="City"
//                 name="city"
//                 value={formData.city}
//                 onChange={handleChange}
//               >
//                 <MenuItem value=""><em>Select city</em></MenuItem>
//                 {cities.map((city) => (
//                   <MenuItem key={city.name} value={city.name}>{city.name}</MenuItem>
//                 ))}
//               </TextField>
//             </FormControl>
//           </Grid>
//           <Grid item xs={12} md={4}>
//             <TextField
//               fullWidth
//               label="Postal Code"
//               name="postalCode"
//               value={formData.postalCode}
//               onChange={handleChange}
//
//             />
//           </Grid>
//         </Grid>
//         <FormControlLabel style={{ marginTop: '20px' }}
//           control={
//             <Checkbox
//               name="sameAsCurrent"
//               checked={formData.sameAsCurrent}
//               onChange={handleAddressCheckboxChange}
//             />
//           }
//           label="Permanent Address Same as Current Address"
//         />
//         {!formData.sameAsCurrent && (
//           <>
//             <Typography variant="h5" style={{ marginTop: '20px' }}>Permanent Address</Typography>
//             <Grid container spacing={2}>
//               <Grid item xs={12} md={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent Street Address"
//                   name="permanentStreetAddress"
//                   value={formData.permanentStreetAddress}
//                   onChange={handleChange}
//
//                 />
//               </Grid>
//               <Grid item xs={12} md={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent Street Address 2"
//                   name="permanentStreetAddress2"
//                   value={formData.permanentStreetAddress2}
//                   onChange={handleChange}
//                 />
//               </Grid>
//               <Grid item xs={12} md={4}>
//                 <FormControl fullWidth >
//                   <TextField
//                     select
//                     label="Permanent State"
//                     name="permanentState"
//                     value={formData.permanentState}
//                     onChange={handleChange}
//                   >
//                     <MenuItem value=""><em>Select state</em></MenuItem>
//                     {permanentStates.map((state) => (
//                       <MenuItem key={state.isoCode} value={state.name}>{state.name}</MenuItem>
//                     ))}
//                   </TextField>
//                 </FormControl>
//               </Grid>
//               <Grid item xs={12} md={4}>
//                 <FormControl fullWidth >
//                   <TextField
//                     select
//                     label="Permanent City"
//                     name="permanentCity"
//                     value={formData.permanentCity}
//                     onChange={handleChange}
//                   >
//                     <MenuItem value=""><em>Select city</em></MenuItem>
//                     {permanentCities.map((city) => (
//                       <MenuItem key={city.name} value={city.name}>{city.name}</MenuItem>
//                     ))}
//                   </TextField>
//                 </FormControl>
//               </Grid>
//               <Grid item xs={12} md={4}>
//                 <TextField
//                   fullWidth
//                   label="Permanent Postal Code"
//                   name="permanentPostalCode"
//                   value={formData.permanentPostalCode}
//                   onChange={handleChange}
//
//                 />
//               </Grid>
//             </Grid>
//           </>
//         )}
//           {/* Move Education History outside the conditional rendering */}
//       <Typography variant="h5" style={{ marginTop: '20px' }}>Education History</Typography>
//       <Grid container spacing={2}>
//         <Grid item xs={12} md={4}>
//           <TextField
//             fullWidth
//             label="College Name"
//             name="collegeName"
//             value={formData.collegeName}
//             onChange={handleChange}
//
//           />
//         </Grid>
//         <Grid item xs={12} md={4}>
//           <TextField
//             fullWidth
//             label="Degree"
//             name="degree"
//             value={formData.degree}
//             onChange={handleChange}
//
//           />
//         </Grid>
//         <Grid item xs={12} md={4}>
//           <TextField
//             fullWidth
//             label="Specialization"
//             name="specialization"
//             value={formData.specialization}
//             onChange={handleChange}
//
//           />
//         </Grid>
//         <Grid item xs={12} md={4}>
//           <FormControl fullWidth >
//             <TextField
//               select
//               label="Graduation Month"
//               name="graduationMonth"
//               value={formData.graduationMonth}
//               onChange={handleChange}
//             >
//               <MenuItem value=""><em>Select month</em></MenuItem>
//               {months.map((month, idx) => (
//                 <MenuItem key={idx} value={month}>{month}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//         <Grid item xs={12} md={4}>
//           <FormControl fullWidth >
//             <TextField
//               select
//               label="Graduation Year"
//               name="graduationYear"
//               value={formData.graduationYear}
//               onChange={handleChange}
//             >
//               <MenuItem value=""><em>Select year</em></MenuItem>
//               {years.map((year, idx) => (
//                 <MenuItem key={idx} value={year}>{year}</MenuItem>
//               ))}
//             </TextField>
//           </FormControl>
//         </Grid>
//       </Grid>
//       </Container>
//     </>
//   );
// }

// export default PersonalInformation;

import React, { useState, useEffect } from "react";
import {
  Container,
  Grid,
  TextField,
  FormControl,
  MenuItem,
  Checkbox,
  FormControlLabel,
  Typography,
} from "@mui/material";
import { State, City } from "country-state-city";

// Sample degrees and their specializations
const degreeOptions = {
  Engineering: [
    "Computer Science",
    "Mechanical",
    "Electrical",
    "Civil",
    "Chemical",
    "Aerospace",
    "Biomedical",
    "Environmental",
    "Industrial",
    "Robotics",
  ],
  "Business Administration": [
    "Finance",
    "Marketing",
    "Human Resources",
    "Operations",
    "International Business",
    "Supply Chain Management",
    "Entrepreneurship",
    "Business Analytics",
    "Project Management",
  ],
  Science: [
    "Physics",
    "Chemistry",
    "Biology",
    "Mathematics",
    "Geology",
    "Astronomy",
    "Environmental Science",
    "Biotechnology",
    "Microbiology",
    "Genetics",
  ],
  Arts: [
    "History",
    "Sociology",
    "Psychology",
    "Literature",
    "Philosophy",
    "Political Science",
    "Anthropology",
    "Linguistics",
    "Fine Arts",
    "Performing Arts",
  ],
  Medicine: [
    "General Medicine",
    "Pediatrics",
    "Dermatology",
    "Psychiatry",
    "Surgery",
    "Gynecology",
    "Ophthalmology",
    "Orthopedics",
    "Anesthesiology",
    "Radiology",
  ],
  Law: [
    "Corporate Law",
    "Criminal Law",
    "International Law",
    "Human Rights Law",
    "Environmental Law",
    "Intellectual Property Law",
    "Family Law",
    "Labor Law",
    "Tax Law",
    "Cyber Law",
  ],
  "Information Technology": [
    "Software Development",
    "Data Science",
    "Cybersecurity",
    "Artificial Intelligence",
    "Cloud Computing",
    "Network Administration",
    "Web Development",
    "Mobile App Development",
    "Database Management",
    "IT Project Management",
  ],
  Education: [
    "Early Childhood Education",
    "Elementary Education",
    "Secondary Education",
    "Special Education",
    "Educational Leadership",
    "Curriculum Development",
    "Counseling",
    "Adult Education",
    "Instructional Technology",
    "Education Policy",
  ],
  Architecture: [
    "Urban Planning",
    "Interior Design",
    "Landscape Architecture",
    "Sustainable Architecture",
    "Architectural Engineering",
    "Historic Preservation",
    "Building Technology",
    "Design Computation",
    "Project Management",
    "Real Estate Development",
  ],
  "Health Sciences": [
    "Public Health",
    "Nutrition",
    "Health Informatics",
    "Occupational Therapy",
    "Physical Therapy",
    "Speech-Language Pathology",
    "Medical Laboratory Science",
    "Radiologic Technology",
    "Health Administration",
    "Epidemiology",
  ],
  "Environmental Studies": [
    "Environmental Policy",
    "Sustainability",
    "Conservation Biology",
    "Renewable Energy",
    "Environmental Chemistry",
    "Climate Change",
    "Water Resources",
    "Ecology",
    "Wildlife Management",
    "Environmental Justice",
  ],
};

const months = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const years = Array.from(
  { length: 40 },
  (_, i) => new Date().getFullYear() - i
); // Generates last 40 years

function PersonalInformation({
  formData,
  handleLanguageChange,
  handleChange,
  handleArrayChange,
  handleBirthDateChange,
  handleAddressCheckboxChange,
  setShowLanguageModal,
}) {
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [permanentStates, setPermanentStates] = useState([]);
  const [permanentCities, setPermanentCities] = useState([]);
  const [specializations, setSpecializations] = useState([]);

  useEffect(() => {
    // Update states and cities for current address
    if (formData.state) {
      const selectedState = State.getStatesOfCountry("IN").find(
        (state) => state.name === formData.state
      );
      if (selectedState) {
        setCities(City.getCitiesOfState("IN", selectedState.isoCode));
      }
    } else {
      setCities([]);
    }

    // Update states and cities for permanent address
    if (formData.permanentState) {
      const selectedPermanentState = State.getStatesOfCountry("IN").find(
        (state) => state.name === formData.permanentState
      );
      if (selectedPermanentState) {
        setPermanentCities(
          City.getCitiesOfState("IN", selectedPermanentState.isoCode)
        );
      }
    } else {
      setPermanentCities([]);
    }
  }, [formData.state, formData.permanentState]);

  useEffect(() => {
    // Load states when component mounts
    setStates(State.getStatesOfCountry("IN"));
    setPermanentStates(State.getStatesOfCountry("IN"));
  }, []);

  useEffect(() => {
    // Update specializations based on selected degree
    if (formData.degree) {
      setSpecializations(degreeOptions[formData.degree] || []);
    } else {
      setSpecializations([]);
    }
  }, [formData.degree]);

  return (
    <>
      <Container className="mb-4">
        <br />
        <Typography variant="h4" style={{ textAlign: "center" }}>
          Personal Details
        </Typography>
        <br />
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Full Name"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Birth Date"
              type="date"
              name="birthDate"
              value={formData.birthDate}
              onChange={handleBirthDateChange}
              InputLabelProps={{ shrink: true }}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Age"
              name="age"
              value={formData.age}
              InputProps={{ readOnly: true }}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <TextField
                select
                label="Gender"
                name="gender"
                value={formData.gender}
                onChange={handleChange}
              >
                <MenuItem value="">
                  <em>Select gender</em>
                </MenuItem>
                <MenuItem value="Male">Male</MenuItem>
                <MenuItem value="Female">Female</MenuItem>
                <MenuItem value="Other">Other</MenuItem>
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Aadhar Number"
              name="aadharNo"
              value={formData.aadharNo}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Preferred Language"
              name="preferredLanguage"
              value={formData.preferredLanguage.join(", ")}
              onClick={() => setShowLanguageModal(true)} // Open modal on click
              InputProps={{
                readOnly: true, // Make the field read-only
              }}
            />
          </Grid>

          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Phone Number"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="LinkedIn Profile"
              type="url"
              name="linkedin"
              value={formData.linkedin}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
        <Typography variant="h5" style={{ marginTop: "20px" }}>
          Current Address
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Street Address"
              name="streetAddress"
              value={formData.streetAddress}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Street Address 2"
              name="streetAddress2"
              value={formData.streetAddress2}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <TextField
                select
                label="State"
                name="state"
                value={formData.state}
                onChange={handleChange}
              >
                <MenuItem value="">
                  <em>Select state</em>
                </MenuItem>
                {states.map((state) => (
                  <MenuItem key={state.isoCode} value={state.name}>
                    {state.name}
                  </MenuItem>
                ))}
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <TextField
                select
                label="City"
                name="city"
                value={formData.city}
                onChange={handleChange}
              >
                <MenuItem value="">
                  <em>Select city</em>
                </MenuItem>
                {cities.map((city) => (
                  <MenuItem key={city.name} value={city.name}>
                    {city.name}
                  </MenuItem>
                ))}
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="Postal Code"
              name="postalCode"
              value={formData.postalCode}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
        <FormControlLabel
          style={{ marginTop: "20px" }}
          control={
            <Checkbox
              name="sameAsCurrent"
              checked={formData.sameAsCurrent}
              onChange={handleAddressCheckboxChange}
            />
          }
          label="Permanent Address Same as Current Address"
        />
        {!formData.sameAsCurrent && (
          <>
            <Typography variant="h5" style={{ marginTop: "20px" }}>
              Permanent Address
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Permanent Street Address"
                  name="permanentStreetAddress"
                  value={formData.permanentStreetAddress}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Permanent Street Address 2"
                  name="permanentStreetAddress2"
                  value={formData.permanentStreetAddress2}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <TextField
                    select
                    label="Permanent State"
                    name="permanentState"
                    value={formData.permanentState}
                    onChange={handleChange}
                  >
                    <MenuItem value="">
                      <em>Select state</em>
                    </MenuItem>
                    {permanentStates.map((state) => (
                      <MenuItem key={state.isoCode} value={state.name}>
                        {state.name}
                      </MenuItem>
                    ))}
                  </TextField>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <FormControl fullWidth>
                  <TextField
                    select
                    label="Permanent City"
                    name="permanentCity"
                    value={formData.permanentCity}
                    onChange={handleChange}
                  >
                    <MenuItem value="">
                      <em>Select city</em>
                    </MenuItem>
                    {permanentCities.map((city) => (
                      <MenuItem key={city.name} value={city.name}>
                        {city.name}
                      </MenuItem>
                    ))}
                  </TextField>
                </FormControl>
              </Grid>
              <Grid item xs={12} md={4}>
                <TextField
                  fullWidth
                  label="Permanent Postal Code"
                  name="permanentPostalCode"
                  value={formData.permanentPostalCode}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        )}
        <Typography variant="h5" style={{ marginTop: "20px" }}>
          Education History
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              label="College Name"
              name="collegeName"
              value={formData.collegeName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              select
              label="Degree"
              name="degree"
              value={formData.degree}
              onChange={handleChange}
            >
              <MenuItem value="">
                <em>Select degree</em>
              </MenuItem>
              {Object.keys(degreeOptions).map((degree, idx) => (
                <MenuItem key={idx} value={degree}>
                  {degree}
                </MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid item xs={12} md={4}>
            <TextField
              fullWidth
              select
              label="Specialization"
              name="specialization"
              value={formData.specialization}
              onChange={handleChange}
              disabled={!formData.degree} // Disable until a degree is selected
            >
              <MenuItem value="">
                <em>Select specialization</em>
              </MenuItem>
              {specializations.map((specialization, idx) => (
                <MenuItem key={idx} value={specialization}>
                  {specialization}
                </MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <TextField
                select
                label="Graduation Month"
                name="graduationMonth"
                value={formData.graduationMonth}
                onChange={handleChange}
              >
                <MenuItem value="">
                  <em>Select month</em>
                </MenuItem>
                {months.map((month, idx) => (
                  <MenuItem key={idx} value={month}>
                    {month}
                  </MenuItem>
                ))}
              </TextField>
            </FormControl>
          </Grid>
          <Grid item xs={12} md={4}>
            <FormControl fullWidth>
              <TextField
                select
                label="Graduation Year"
                name="graduationYear"
                value={formData.graduationYear}
                onChange={handleChange}
              >
                <MenuItem value="">
                  <em>Select year</em>
                </MenuItem>
                {years.map((year, idx) => (
                  <MenuItem key={idx} value={year}>
                    {year}
                  </MenuItem>
                ))}
              </TextField>
            </FormControl>
          </Grid>
        </Grid>
      </Container>
    </>
  );
}

export default PersonalInformation;
