import React from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';

function Sidebar() {
  const openGoogle = () => {
    window.open('https://www.google.com', '_blank');
  };

  const openFacebook = () => {
    window.open('https://www.facebook.com', '_blank');
  };

  return (
    <aside className="main-sidebar">
      <section className="sidebar">
        <ul className="sidebar-menu">
          <li className="header">DASHBOARD</li>

          {/* Fees Management System */}
          <li className="external-link" onClick={openGoogle}>
            <span>
              <i className="fa fa-money"></i> <span>Fees Management System</span>
            </span>
          </li>

          {/* School Management System */}
          <li className="external-link" onClick={openFacebook}>
            <span>
              <i className="fa fa-graduation-cap"></i> <span>School Management System</span>
            </span>
          </li>

          {/* Inquiry Management System */}
          <li className="external-link" onClick={openGoogle}>
            <span>
              <i className="fa fa-question-circle"></i> <span>Inquiry Management System</span>
            </span>
          </li>

          {/* Employee Management System */}
          <li className="external-link" onClick={openFacebook}>
            <span>
              <i className="fa fa-id-badge"></i> <span>Employee Management System</span>
            </span>
          </li>

          {/* Salary Management System */}
          <li className="external-link" onClick={openGoogle}>
            <span>
              <i className="fa fa-credit-card"></i> <span>Salary Management System</span>
            </span>
          </li>

          {/* Attendance Management System */}
          <li className="external-link" onClick={openFacebook}>
            <span>
              <i className="fa fa-calendar-check-o"></i> <span>Attendance Management System</span>
            </span>
          </li>
        </ul>
      </section>
    </aside>
  );
}

export default Sidebar;
