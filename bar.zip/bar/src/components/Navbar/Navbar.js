import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar, Nav, NavDropdown } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Navbar.css';
import logo from './logo.png';

function NavbarComponent({ username }) {
  return (
    <Navbar bg="dark" variant="dark" expand="lg" fixed="top" className="main-header">
      <Navbar.Brand as={Link} to="/" className="navbar-left">
        <img src={logo} alt="PjSoftTech Logo" className="navbar-logo" />
      </Navbar.Brand>
      <div className="navbar-center">
        <h1 className="navbar-title">CRM</h1>
      </div>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ms-auto navbar-right">
          <NavDropdown
            align={{ lg: 'end' }} // This is used to align the dropdown
            title={<img src="https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-image-182145777.jpg" alt="Profile" className="profile-icon" />}
            id="basic-nav-dropdown"
            className="custom-dropdown"
          >
            <NavDropdown.Item as={Link} to="/user-edit?id=2">Edit Profile</NavDropdown.Item>
            <NavDropdown.Item as={Link} to="/user-manage">Manage Account</NavDropdown.Item>
            <NavDropdown.Item as={Link} to="/logout">Log out</NavDropdown.Item>
          </NavDropdown>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
}

export default NavbarComponent;
