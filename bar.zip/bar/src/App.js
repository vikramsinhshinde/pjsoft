import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar/Navbar';
import Sidebar from './components/Sidebar/sidebar';

const UserEdit = () => <div>Edit User Page</div>;
const Logout = () => <div>Logout Page</div>;

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar username="Your Username" />
        <Sidebar/>
        <Routes>
          <Route path="/user-edit" element={<UserEdit />} />
          <Route path="/logout" element={<Logout />} />
          {/* Add other routes as needed */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
